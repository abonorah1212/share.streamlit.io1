"""
Equity Intelligence — professional web terminal
Built on the ta_scanner analysis engine. Each user supplies their own API key.
Run:  python3 -m streamlit run app.py
"""
import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import ta_scanner as ta
import os

# Auto-write a light-theme config next to this file (no manual file handling needed).
try:
    _here = os.path.dirname(os.path.abspath(__file__))
    _cfgdir = os.path.join(_here, ".streamlit"); _cfg = os.path.join(_cfgdir, "config.toml")
    if not os.path.exists(_cfg):
        os.makedirs(_cfgdir, exist_ok=True)
        with open(_cfg, "w") as _f:
            _f.write('[theme]\nbase="light"\nprimaryColor="#2563eb"\n'
                     'backgroundColor="#ffffff"\nsecondaryBackgroundColor="#f6f8fb"\n'
                     'textColor="#1a2233"\nfont="sans serif"\n')
except Exception:
    pass

st.set_page_config(page_title="Equity Intelligence", page_icon="📊", layout="wide",
                   initial_sidebar_state="expanded")
ta.LANG = "en"   # engine outputs in English

# ──────────── optional password gate (demo protection) ────────────
# Set APP_PASSWORD in .streamlit/secrets.toml or as an env var to lock the demo.
# If unset, the app runs open (e.g. local development).
def _demo_gate():
    _pw = None
    try: _pw = st.secrets.get("APP_PASSWORD")
    except Exception: _pw = None
    if not _pw: _pw = os.environ.get("APP_PASSWORD")
    if not _pw: return                      # no password configured → open
    if st.session_state.get("_authed"): return
    st.markdown("<div style='max-width:440px;margin:7vh auto 0;text-align:center'>"
                "<div style='font-size:34px'>📊</div>"
                "<h2 style='margin:4px 0'>Equity Intelligence</h2>"
                "<p style='color:#64748b;margin-top:0'>Private demo — enter your access code · ديمو خاص — أدخل رمز الدخول</p></div>",
                unsafe_allow_html=True)
    mid = st.columns([1,2,1])[1]
    with mid:
        _entered = st.text_input("Access code", type="password", key="_pw_in", label_visibility="collapsed",
                                 placeholder="Access code · رمز الدخول")
        if st.button("Enter · دخول", use_container_width=True, type="primary"):
            if _entered == _pw:
                st.session_state["_authed"] = True; st.rerun()
            else:
                st.error("Incorrect access code · رمز غير صحيح")
    st.stop()
_demo_gate()

# ════════════════════════ state persistence (alerts + watchlist) ════════════════════════
import json as _json
def _state_path():
    try: return os.path.join(os.path.dirname(os.path.abspath(__file__)), ".ei_state.json")
    except Exception: return ".ei_state.json"
def load_state():
    try:
        with open(_state_path()) as f: return _json.load(f)
    except Exception: return {}
def save_state(watchlist=None, alerts=None, log=None):
    data=load_state()
    if watchlist is not None: data["watchlist"]=watchlist
    if alerts is not None: data["alerts"]=alerts
    if log is not None: data["log"]=log[-100:]
    try:
        with open(_state_path(),"w") as f: _json.dump(data,f)
    except Exception: pass

def evaluate_alerts(rules, quotes, now):
    """Pure, testable: marks newly-met rules as triggered; returns list of fired rules."""
    fired=[]
    for r in rules:
        if (not r.get("active",True)) or r.get("triggered_at"): continue
        q=quotes.get(r["symbol"]);
        if not q: continue
        price=q.get("price"); chg=q.get("chg")
        if price is None: continue
        c=r["cond"]; v=r["value"]; ok=False
        if   c=="price_above": ok = price >= v
        elif c=="price_below": ok = price <= v
        elif c=="chg_above":   ok = (chg is not None) and chg >= v
        elif c=="chg_below":   ok = (chg is not None) and chg <= v
        if ok:
            r["triggered_at"]=now; r["trigger_price"]=round(price,4)
            fired.append(r)
    return fired

def send_telegram(token, chat_id, text):
    import urllib.request, urllib.parse
    try:
        url=f"https://api.telegram.org/bot{token}/sendMessage"
        data=urllib.parse.urlencode({"chat_id":chat_id,"text":text}).encode()
        urllib.request.urlopen(url, data=data, timeout=8)
        return True
    except Exception:
        return False

ACC, UP, DN, CARD, LINE = "#2563eb", "#16a34a", "#dc2626", "#f6f8fb", "#e3e8ee"
TEXT, MUTED, BG = "#1a2233", "#64748b", "#ffffff"

# ════════════════════════ styling (light theme) ════════════════════════
st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"], .stApp, .stMarkdown, input, button, textarea, select {{
    font-family:'Inter', system-ui, sans-serif !important;
}}
.stApp {{ background:{BG}; }}
:root {{ color-scheme: light; }}
[data-testid="stAppViewContainer"], [data-testid="stMain"], .main, .block-container {{ background:{BG} !important; }}
[data-baseweb="menu"], [role="listbox"], [data-baseweb="popover"] > div {{ background:#fff !important; }}
[data-baseweb="menu"] li, [role="option"] {{ color:{TEXT} !important; }}
.stApp, .stMarkdown, p, span, label, li, td, th {{ color:{TEXT}; }}
.block-container {{ padding-top:2rem; max-width:1240px; }}
header[data-testid="stHeader"] {{ display:none !important; }}
[data-testid="stToolbar"] {{ display:none !important; }}
[data-testid="stDecoration"] {{ display:none !important; }}
#MainMenu {{ visibility:hidden; }}
footer {{ visibility:hidden; }}
.hero {{
    display:flex; align-items:center; gap:15px; padding:6px 2px 4px; margin-bottom:14px;
    border-bottom:1px solid {LINE};
}}
.hero .logo {{ flex:0 0 auto; display:flex; align-items:center; }}
.hero h1 {{ margin:0; font-size:26px; font-weight:800; color:#0f1b33; letter-spacing:-.6px; }}
.hero p  {{ margin:4px 0 0; color:{MUTED}; font-size:13px; }}
[data-testid="stMetric"] {{
    background:{CARD}; border:1px solid {LINE}; border-radius:14px; padding:14px 16px;
    box-shadow:0 1px 3px rgba(15,27,51,.05); transition:.15s;
}}
[data-testid="stMetric"]:hover {{ box-shadow:0 4px 14px rgba(15,27,51,.10); transform:translateY(-1px); }}
[data-testid="stMetricValue"] {{ font-weight:800; font-size:24px; color:{TEXT}; }}
[data-testid="stMetricLabel"] {{ color:{MUTED}; font-weight:600; text-transform:uppercase; letter-spacing:.5px; font-size:11px; }}
.stTabs [data-baseweb="tab-list"] {{ gap:6px; border-bottom:1px solid {LINE}; }}
.stTabs [data-baseweb="tab"] {{ background:transparent; padding:9px 18px; font-weight:600; color:{MUTED}; }}
.stTabs [aria-selected="true"] {{ color:{ACC} !important; border-bottom:2.5px solid {ACC}; }}
.stButton>button {{
    background:{ACC}; color:#fff; font-weight:700; border:none; border-radius:10px;
    padding:9px 26px; transition:.15s; box-shadow:0 4px 12px rgba(37,99,235,.28);
}}
.stButton>button:hover {{ background:#1d4fd0; transform:translateY(-1px); box-shadow:0 6px 18px rgba(37,99,235,.38); }}
[data-testid="stDataFrame"] {{ border:1px solid {LINE}; border-radius:13px; overflow:hidden; box-shadow:0 1px 3px rgba(15,27,51,.05); }}
.news-item {{ padding:11px 0; border-bottom:1px solid {LINE}; }}
.news-title {{ color:#0f1b33 !important; font-weight:600; font-size:15px; text-decoration:none; line-height:1.45; }}
.news-title:hover {{ color:{ACC} !important; text-decoration:underline; }}
.news-meta {{ color:{MUTED}; font-size:12px; margin-top:3px; }}
section[data-testid="stSidebar"] {{ background:#fff !important; border-right:1px solid {LINE}; }}
section[data-testid="stSidebar"] .block-container {{ padding-top:1.4rem; }}
.wl-head {{ font-weight:800; font-size:16px; color:#0f1b33; margin:2px 0 4px; display:flex; align-items:center; gap:6px; }}
.wl-list {{ margin-top:6px; }}
.wl-row {{ display:flex; justify-content:space-between; align-items:center; padding:9px 2px; border-bottom:1px solid {LINE}; }}
.wl-row:hover {{ background:{CARD}; }}
.wl-sym {{ font-weight:700; color:#0f1b33; font-size:14px; }}
.wl-px {{ text-align:right; font-size:13px; color:#334155; font-weight:600; line-height:1.35; }}
[data-testid="stExpander"], [data-testid="stPopover"] {{ border-color:{LINE}; }}
div[data-testid="stExpander"] details {{ background:{CARD}; border:1px solid {LINE}; border-radius:10px; }}
h1, h2, h3, h4 {{ color:#0f1b33; font-weight:700; }}
hr {{ border-color:{LINE}; }}
.stTextInput input, .stTextArea textarea, [data-baseweb="input"], [data-baseweb="select"] > div {{
    background:#fff !important; color:{TEXT} !important; border-color:{LINE} !important;
}}
[data-testid="stMarkdownContainer"] code {{ background:{CARD}; color:#0f1b33; }}
[data-baseweb="popover"] {{ background:#fff; }}
</style>
""", unsafe_allow_html=True)

# ════════════════════════ engine helpers ════════════════════════
def _set_keys(fk, ak, asec):
    ta.FINNHUB_KEY=(fk or "").strip(); ta.ALPACA_KEY=(ak or "").strip(); ta.ALPACA_SECRET=(asec or "").strip()

@st.cache_data(ttl=120, show_spinner=False)
def cached_analyze(sym, lang="en"): return ta.analyze(sym, silent=True)
@st.cache_data(ttl=600, show_spinner=False)
def cached_info(sym): return ta.get_company_info(sym)
@st.cache_data(ttl=300, show_spinner=False)
def fetch_ohlc(sym, period="6mo", interval="1d"):
    df = yf.Ticker(sym).history(period=period, interval=interval, auto_adjust=False)
    return df.dropna()

@st.cache_data(ttl=600, show_spinner=False)
def fetch_movers(universe):
    data = yf.download(list(universe), period="1y", interval="1d",
                       group_by="ticker", auto_adjust=True, progress=False, threads=True)
    multi = isinstance(data.columns, pd.MultiIndex); rows=[]
    for t in universe:
        try:
            close=(data[t]["Close"] if multi else data["Close"]).dropna()
            if len(close)<2: continue
            last=float(close.iloc[-1])
            def r(n):
                if len(close)>n:
                    p=float(close.iloc[-1-n]); return round((last/p-1)*100,2) if p>0 else None
                return None
            first=float(close.iloc[0])
            rows.append({"Symbol":t,"Price":round(last,2),"1D %":r(1),"5D %":r(5),
                         "1M %":r(21),"1Y %":round((last/first-1)*100,2) if first>0 else None})
        except Exception: continue
    return rows

@st.cache_data(ttl=300, show_spinner=False)
def yahoo_day_gainers(n=40):
    FOREIGN=(".TW",".TWO",".HK",".L",".T",".KS",".KQ",".SS",".SZ",".DE",".PA",".AX",".TO",
             ".V",".SI",".BO",".NS",".MI",".MC",".AS",".BR",".ST",".HE",".OL",".SW",".VI",
             ".LS",".IS",".SA",".MX",".JK",".BK",".F",".SR",".QA",".AE")
    us=lambda s:(s or "").upper() and not any((s or "").upper().endswith(x) for x in FOREIGN)
    out=[]
    try:
        from yfinance import EquityQuery
        base=[EquityQuery('gt',['percentchange',3]),EquityQuery('gt',['dayvolume',100000]),
              EquityQuery('gt',['intradayprice',1])]
        res=None
        for extra in ([EquityQuery('eq',['region','us'])],[]):
            try:
                res=yf.screen(EquityQuery('and',base+extra),sortField='percentchange',sortAsc=False,size=max(n*2,60))
                if res and res.get("quotes"): break
            except Exception: res=None
        for x in (res.get("quotes",[]) if isinstance(res,dict) else []):
            sym=x.get("symbol","")
            if not us(sym): continue
            chg=x.get("regularMarketChangePercent")
            if chg is None: continue
            nm=x.get("shortName") or x.get("longName") or ""
            out.append({"Symbol":sym,"Company":(nm or "")[:28],"Price":round(x.get("regularMarketPrice",0) or 0,2),
                        "Today %":round(chg,2),"Volume":ta._fmt_big(x.get("regularMarketVolume",0))})
            if len(out)>=n: break
    except Exception: pass
    return out

def pct(x,d=1): return f"{x*100:.{d}f}%" if x is not None else "—"
def money(x):   return f"${x:,.2f}" if isinstance(x,(int,float)) and x else "—"

# ── home dashboard data ──
US_INDICES = [("^GSPC","S&P 500"),("^DJI","Dow Jones"),("^IXIC","Nasdaq"),("^RUT","Russell 2000"),("^VIX","VIX")]
COMMODITIES = [("GC=F","Gold"),("SI=F","Silver"),("CL=F","WTI Crude"),("BTC-USD","Bitcoin")]

@st.cache_data(ttl=120, show_spinner=False)
@st.cache_data(ttl=120, show_spinner=False)
def quote_one(sym):
    """سعر وتغيّر موثوق لرمز واحد، مستقل عن أي رمز آخر (لا يتأثّر برمز فاشل)."""
    sym=(sym or "").strip().upper()
    if not sym: return None
    # 1) fast_info — سريع وموثوق
    try:
        fi=getattr(yf.Ticker(sym),"fast_info",None)
        if fi is not None:
            def _g(k):
                try: return fi[k]
                except Exception: return getattr(fi,k,None)
            last=_g("last_price") or _g("lastPrice")
            prev=_g("previous_close") or _g("previousClose") or _g("regular_market_previous_close")
            if last and prev and float(prev)>0:
                return {"price":float(last),"chg":(float(last)/float(prev)-1)*100}
            if last:
                return {"price":float(last),"chg":0.0}
    except Exception: pass
    # 2) history — احتياطي
    try:
        h=yf.Ticker(sym).history(period="5d",interval="1d",auto_adjust=False)
        c=h["Close"].dropna()
        if len(c)>=2: return {"price":float(c.iloc[-1]),"chg":(float(c.iloc[-1])/float(c.iloc[-2])-1)*100}
        if len(c)==1: return {"price":float(c.iloc[-1]),"chg":0.0}
    except Exception: pass
    return None

@st.cache_data(ttl=120, show_spinner=False)
def market_quotes(tickers):
    """جلب دفعة واحدة للسرعة، مع سقوط احتياطي لكل رمز ناقص (فلا يُفسد رمزٌ فاشل البقية)."""
    out={}
    try:
        data = yf.download(list(tickers), period="5d", interval="1d",
                           group_by="ticker", auto_adjust=False, progress=False, threads=True)
        multi = isinstance(data.columns, pd.MultiIndex)
        for t in tickers:
            try:
                close = (data[t]["Close"] if multi else data["Close"]).dropna()
                if len(close) >= 2:
                    last=float(close.iloc[-1]); prev=float(close.iloc[-2])
                    out[t]={"price":last,"chg":(last/prev-1)*100 if prev>0 else 0.0}
                elif len(close)==1:
                    out[t]={"price":float(close.iloc[-1]),"chg":0.0}
            except Exception:
                continue
    except Exception:
        pass
    # per-symbol fallback for anything the batch missed
    for t in tickers:
        if not out.get(t):
            q=quote_one(t)
            if q: out[t]=q
    return out

@st.cache_data(ttl=300, show_spinner=False)
def market_news(limit=14):
    from datetime import datetime, timezone
    items=[]
    for sym in ("SPY","^GSPC","^DJI","QQQ"):
        try:
            for n in (yf.Ticker(sym).news or []):
                c = n.get("content") if isinstance(n.get("content"), dict) else None
                if c:
                    title=c.get("title"); pub=(c.get("provider") or {}).get("displayName","")
                    url=((c.get("canonicalUrl") or c.get("clickThroughUrl") or {}) or {}).get("url","")
                    ts=c.get("pubDate") or c.get("displayTime")
                else:
                    title=n.get("title"); pub=n.get("publisher",""); url=n.get("link","")
                    ts=n.get("providerPublishTime")
                if not (title and url): continue
                when=""
                try:
                    if isinstance(ts,(int,float)): when=datetime.fromtimestamp(ts,tz=timezone.utc).strftime("%b %d, %H:%M")
                    elif isinstance(ts,str): when=ts[:10]
                except Exception: when=""
                items.append({"title":title,"publisher":pub,"url":url,"when":when})
        except Exception:
            continue
    seen=set(); uniq=[]
    for it in items:
        if it["title"] in seen: continue
        seen.add(it["title"]); uniq.append(it)
    return uniq[:limit]

@st.cache_data(ttl=300, show_spinner=False)
def stock_news(sym, limit=8):
    from datetime import datetime, timezone
    items=[]
    try:
        for n in (yf.Ticker(sym).news or []):
            c = n.get("content") if isinstance(n.get("content"), dict) else None
            if c:
                title=c.get("title"); pub=(c.get("provider") or {}).get("displayName","")
                url=((c.get("canonicalUrl") or c.get("clickThroughUrl") or {}) or {}).get("url","")
                ts=c.get("pubDate") or c.get("displayTime")
            else:
                title=n.get("title"); pub=n.get("publisher",""); url=n.get("link","")
                ts=n.get("providerPublishTime")
            if not (title and url): continue
            when=""
            try:
                if isinstance(ts,(int,float)): when=datetime.fromtimestamp(ts,tz=timezone.utc).strftime("%b %d, %H:%M")
                elif isinstance(ts,str): when=ts[:10]
            except Exception: when=""
            items.append({"title":title,"publisher":pub,"url":url,"when":when})
    except Exception:
        pass
    seen=set(); uniq=[]
    for it in items:
        if it["title"] in seen: continue
        seen.add(it["title"]); uniq.append(it)
    return uniq[:limit]

@st.cache_data(ttl=600, show_spinner=False)
def momentum_metrics(sym):
    """قوة الزخم اليومي نسبةً لآخر ٣ أشهر + التذبذب (ATR٪)."""
    try:
        df=fetch_ohlc(sym,"3mo","1d")
        c=df["Close"].values.astype(float)
        if len(c)<10: return {}
        hi=df["High"].values.astype(float); lo=df["Low"].values.astype(float)
        rets=np.diff(c)/c[:-1]
        std=rets.std() or 1e-9
        z=(rets[-1]-rets.mean())/std
        roc3m=c[-1]/c[0]-1
        roc5=c[-1]/c[-6]-1 if len(c)>6 else 0.0
        up21=float((rets[-21:]>0).mean()) if len(rets)>=21 else float((rets>0).mean())
        tr=(hi-lo); atr=tr[-14:].mean() if len(tr)>=14 else tr.mean()
        atr_pct=float(atr/c[-1]*100) if c[-1]>0 else 0.0
        zc=max(0,min(1,(z+2)/4)); r5=max(0,min(1,(roc5+0.10)/0.20)); r3=max(0,min(1,(roc3m+0.30)/0.60))
        score=max(0,min(1,0.40*zc+0.25*r5+0.20*up21+0.15*r3))
        return {"z":z,"roc3m":roc3m,"roc5":roc5,"up21":up21,"score":score,"chg":float(rets[-1]*100),"atr_pct":atr_pct}
    except Exception:
        return {}

@st.cache_data(ttl=600, show_spinner=False)
def market_roc3m():
    """عائد S&P 500 لآخر ٣ أشهر — مرجع القوة النسبية."""
    try:
        df=fetch_ohlc("SPY","3mo","1d"); c=df["Close"].values.astype(float)
        return float(c[-1]/c[0]-1) if len(c)>2 else 0.0
    except Exception:
        return 0.0

@st.cache_data(ttl=600, show_spinner=False)
def cached_inst_activity(sym):
    try: return ta.institutional_activity(sym)
    except Exception: return {}

def index_line(df, name):
    up = df["Close"].iloc[-1] >= df["Close"].iloc[0]
    col = UP if up else DN
    fig=go.Figure(go.Scatter(x=df.index,y=df["Close"],line=dict(color=col,width=2),
                  fill='tozeroy',fillcolor=f'rgba({"22,199,132" if up else "234,57,67"},0.08)'))
    fig.update_layout(template="plotly_white",height=240,margin=dict(l=6,r=6,t=32,b=6),
                      title=dict(text=name,x=0.01,font=dict(size=14)),paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)",font=dict(family="Inter",color="#334155"))
    fig.update_yaxes(gridcolor=LINE); fig.update_xaxes(gridcolor=LINE)
    return fig

def flow_bias(info):
    """انحياز تدفق [-1..1] من ملكية المؤسسات والداخل والبيع المكشوف + وصف المحرّكات."""
    fb=0.0; drv=[]
    inst=info.get("institutions"); ins=info.get("insiders"); short=info.get("short_pct")
    if inst is not None:
        if inst>=0.70: fb+=0.40; drv.append(f"Institutions {inst*100:.0f}% (high)")
        elif inst<=0.40: fb-=0.20; drv.append(f"Institutions {inst*100:.0f}% (low)")
        else: drv.append(f"Institutions {inst*100:.0f}%")
    if ins is not None and ins>=0.05:
        fb+=0.25; drv.append(f"Insider ownership {ins*100:.0f}%")
    if short is not None and short>=0.15:
        fb-=0.35; drv.append(f"Short interest {short*100:.0f}% (bearish)")
    return max(-1.0,min(1.0,fb)), drv

TF_MAP = {"Daily":("1y","1d"), "Weekly":("5y","1wk"), "Hourly":("1mo","1h"), "15-Min":("5d","15m")}

def price_chart(df, sym, indicators, tf_label="Daily", overlays=None):
    close=df["Close"]
    panels=["price"]
    if "Volume" in indicators: panels.append("vol")
    if "MACD" in indicators:   panels.append("macd")
    if "RSI" in indicators:    panels.append("rsi")
    if "Stoch RSI" in indicators: panels.append("stoch")
    heights=[0.52 if p=="price" else (0.13 if p=="vol" else 0.18) for p in panels]
    s=sum(heights); heights=[h/s for h in heights]
    fig=make_subplots(rows=len(panels),cols=1,shared_xaxes=True,row_heights=heights,vertical_spacing=0.03)

    fig.add_trace(go.Candlestick(x=df.index,open=df["Open"],high=df["High"],low=df["Low"],close=df["Close"],
                  name="Price",increasing_line_color=UP,decreasing_line_color=DN,
                  increasing_fillcolor=UP,decreasing_fillcolor=DN),row=1,col=1)
    if "EMAs" in indicators:
        for span,clr in [(9,"#f0b90b"),(21,ACC),(50,"#a855f7")]:
            fig.add_trace(go.Scatter(x=df.index,y=close.ewm(span=span).mean(),
                          line=dict(color=clr,width=1.2),name=f"EMA {span}"),row=1,col=1)
    if "Bollinger Bands" in indicators:
        mid=close.rolling(20).mean(); sd=close.rolling(20).std()
        fig.add_trace(go.Scatter(x=df.index,y=mid+2*sd,line=dict(color="#64748b",width=1,dash="dot"),name="BB Upper"),row=1,col=1)
        fig.add_trace(go.Scatter(x=df.index,y=mid-2*sd,line=dict(color="#64748b",width=1,dash="dot"),
                      fill='tonexty',fillcolor='rgba(100,116,139,0.07)',name="BB Lower"),row=1,col=1)
        fig.add_trace(go.Scatter(x=df.index,y=mid,line=dict(color="#64748b",width=1),name="BB Mid"),row=1,col=1)

    row=2
    if "Volume" in indicators:
        vc=[UP if c>=o else DN for o,c in zip(df["Open"],df["Close"])]
        fig.add_trace(go.Bar(x=df.index,y=df["Volume"],marker_color=vc,opacity=0.6,name="Volume"),row=row,col=1)
        fig.update_yaxes(title_text="Vol",row=row,col=1); row+=1
    if "MACD" in indicators:
        e12=close.ewm(span=12).mean(); e26=close.ewm(span=26).mean()
        macd=e12-e26; sigl=macd.ewm(span=9).mean(); hist=macd-sigl
        hc=[UP if v>=0 else DN for v in hist]
        fig.add_trace(go.Bar(x=df.index,y=hist,marker_color=hc,name="Hist"),row=row,col=1)
        fig.add_trace(go.Scatter(x=df.index,y=macd,line=dict(color=ACC,width=1),name="MACD"),row=row,col=1)
        fig.add_trace(go.Scatter(x=df.index,y=sigl,line=dict(color="#f0b90b",width=1),name="Signal"),row=row,col=1)
        fig.update_yaxes(title_text="MACD",row=row,col=1); row+=1
    if "RSI" in indicators:
        delta=close.diff(); gain=delta.clip(lower=0).rolling(14).mean(); loss=(-delta.clip(upper=0)).rolling(14).mean()
        rsi=100-100/(1+gain/loss.replace(0,np.nan))
        fig.add_trace(go.Scatter(x=df.index,y=rsi,line=dict(color="#22d3ee",width=1.2),name="RSI"),row=row,col=1)
        fig.add_hline(y=70,line=dict(color=DN,dash="dot",width=1),row=row,col=1)
        fig.add_hline(y=30,line=dict(color=UP,dash="dot",width=1),row=row,col=1)
        fig.update_yaxes(title_text="RSI",range=[0,100],row=row,col=1); row+=1
    if "Stoch RSI" in indicators:
        d=close.diff(); g=d.clip(lower=0).rolling(14).mean(); l=(-d.clip(upper=0)).rolling(14).mean()
        rsi=100-100/(1+g/l.replace(0,np.nan))
        mn=rsi.rolling(14).min(); mx=rsi.rolling(14).max()
        srsi=(rsi-mn)/(mx-mn).replace(0,np.nan)*100
        k=srsi.rolling(3).mean(); dd=k.rolling(3).mean()
        fig.add_hrect(y0=20,y1=80,fillcolor="rgba(59,130,246,0.06)",line_width=0,row=row,col=1)
        fig.add_trace(go.Scatter(x=df.index,y=k,line=dict(color="#3b82f6",width=1.3),name="%K"),row=row,col=1)
        fig.add_trace(go.Scatter(x=df.index,y=dd,line=dict(color="#f0b90b",width=1.3),name="%D"),row=row,col=1)
        fig.add_hline(y=80,line=dict(color="#64748b",dash="dash",width=1),row=row,col=1)
        fig.add_hline(y=20,line=dict(color="#64748b",dash="dash",width=1),row=row,col=1)
        fig.update_yaxes(title_text="Stoch RSI",range=[0,100],row=row,col=1); row+=1

    # ── auto-draw levels & patterns on the price panel ──
    if overlays:
        def hline(y,color,dash,label,width=1.2):
            if y and np.isfinite(y):
                fig.add_hline(y=float(y),line=dict(color=color,dash=dash,width=width),row=1,col=1,
                              annotation_text=label,annotation_position="top left",
                              annotation_font=dict(size=10,color=color))
        if overlays.get("show_levels"):
            _px=float(close.iloc[-1]) if len(close) else None
            _atr=(overlays.get("atr") or (_px*0.03 if _px else 0))
            _maxd=max(_atr*6, (_px*0.12 if _px else 0))   # نطاق قريب فقط
            res=[z for z in (overlays.get("resistances") or []) if _px and 0<z["level"]-_px<=_maxd][:2]
            sup=[z for z in (overlays.get("supports") or []) if _px and 0<_px-z["level"]<=_maxd][:2]
            for z in res:
                hline(z["level"],DN,"dot",f"R ${z['level']:.2f} · {z['touches']}× {z['methods'][0] if z['methods'] else ''}")
            for z in sup:
                hline(z["level"],UP,"dot",f"S ${z['level']:.2f} · {z['touches']}× {z['methods'][0] if z['methods'] else ''}")
        if overlays.get("show_plan"):
            pl=overlays.get("plan") or {}
            hline(pl.get("entry"),ACC,"dash","ENTRY")
            hline(pl.get("stop"),DN,"dash","STOP",1.4)
            for i,tp in enumerate([pl.get("tp1"),pl.get("tp2"),pl.get("tp3")],1):
                hline(tp,UP,"dash",f"TP{i}")
        if overlays.get("show_patterns"):
            for p in (overlays.get("patterns") or []):
                clr = UP if p.get("dir")=="BULLISH" else (DN if p.get("dir")=="BEARISH" else "#a855f7")
                if p.get("brk"):    hline(p["brk"], clr, "solid", f"⚑ {p['name']} ({p.get('type','')})", 1.4)
                if p.get("target"): hline(p["target"], UP, "dashdot", f"{p['name']} → target")
                if p.get("stop"):   hline(p["stop"], DN, "dashdot", f"{p['name']} stop")

    fig.update_layout(template="plotly_white",height=360+120*(len(panels)-1),margin=dict(l=8,r=8,t=30,b=8),
                      xaxis_rangeslider_visible=False,paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                      legend=dict(orientation="h",y=1.03,x=0,bgcolor="rgba(0,0,0,0)"),
                      font=dict(family="Inter",color="#334155"),
                      title=dict(text=f"{sym} · {tf_label}",x=0.01,font=dict(size=15)))
    fig.update_yaxes(gridcolor=LINE,zeroline=False); fig.update_xaxes(gridcolor=LINE)
    return fig

# ════════════════════════ language toggle ════════════════════════
_lc = st.columns([8,1])
with _lc[1]:
    lang = st.radio(" ", ["EN","ع"], horizontal=True, label_visibility="collapsed", key="lang")
ar = (lang == "ع")
ta.LANG = "ar" if ar else "en"
def L(en, a): return a if ar else en
if ar:
    st.markdown("<style>.block-container, .stTabs [data-baseweb='tab-list'], "
                "[data-testid='stMarkdownContainer'] { direction:rtl; }</style>",
                unsafe_allow_html=True)

# ════════════════════════ ticker tape + watchlist (all pages) ════════════════════════
if "_state_loaded" not in st.session_state:
    _saved=load_state()
    st.session_state["watchlist"]=_saved.get("watchlist") or ["AAPL","NVDA","TSLA","AMD","MSFT"]
    st.session_state["alerts"]=_saved.get("alerts") or []
    st.session_state["alert_log"]=_saved.get("log") or []
    st.session_state["_state_loaded"]=True
if "watchlist" not in st.session_state:
    st.session_state["watchlist"] = ["AAPL","NVDA","TSLA","AMD","MSFT"]
_namemap = {t:n for t,n in US_INDICES+COMMODITIES}
_alert_syms = [a["symbol"] for a in st.session_state.get("alerts",[]) if a.get("active",True) and not a.get("triggered_at")]
_tape_syms = [t for t,_ in US_INDICES+COMMODITIES] + st.session_state["watchlist"] + _alert_syms
_tape_syms = list(dict.fromkeys(_tape_syms))
try: _tape_q = market_quotes(tuple(_tape_syms))
except Exception: _tape_q = {}

# evaluate alerts on every run
import datetime as _dt
_fired = evaluate_alerts(st.session_state.get("alerts",[]), _tape_q, _dt.datetime.now().strftime("%Y-%m-%d %H:%M"))
if _fired:
    _tg = st.session_state.get("tg") or {}
    for r in _fired:
        line=f"🔔 {r['symbol']}: {r.get('_label','')} @ ${r.get('trigger_price')}"
        st.session_state["alert_log"].insert(0, {"when":r["triggered_at"],"text":line,"symbol":r["symbol"]})
        try: st.toast(line, icon="🔔")
        except Exception: pass
        if _tg.get("token") and _tg.get("chat"):
            send_telegram(_tg["token"], _tg["chat"], line)
    save_state(alerts=st.session_state["alerts"], log=st.session_state["alert_log"])
_items=[]
for t in _tape_syms:
    q=_tape_q.get(t)
    if not q: continue
    nm=_namemap.get(t,t); up=q["chg"]>=0; col=UP if up else DN; arr="▲" if up else "▼"
    _items.append(f"<span class='ti'>{nm} <b style='color:{col}'>{q['price']:,.2f} {arr}{abs(q['chg']):.2f}%</b></span>")
if _items:
    _content="".join(_items)
    st.markdown(f"""
    <style>
    .tk-wrap{{overflow:hidden;white-space:nowrap;border-top:1px solid {LINE};border-bottom:1px solid {LINE};
             background:#f6f8fb;padding:7px 0;margin:0 0 12px;border-radius:8px;}}
    .tk{{display:inline-block;padding-left:100%;animation:tkscroll 60s linear infinite;}}
    .tk:hover{{animation-play-state:paused;}}
    .tk .ti{{margin:0 22px;font-size:13px;color:#334155;font-weight:600;}}
    @keyframes tkscroll{{0%{{transform:translateX(0)}}100%{{transform:translateX(-100%)}}}}
    </style>
    <div class="tk-wrap"><div class="tk">{_content}{_content}</div></div>
    """, unsafe_allow_html=True)

# ════════════════════════ persistent watchlist sidebar (all pages) ════════════════════════
with st.sidebar:
    st.markdown(f'<div class="wl-head">⭐ {L("Watchlist","قائمة المتابعة")}</div>', unsafe_allow_html=True)
    st.caption(L("Symbols you follow — shown on every page.","رموزك المختارة — تظهر في كل الصفحات."))
    wl_txt=st.text_input(L("Edit symbols","تعديل الرموز"),value=" ".join(st.session_state["watchlist"]),
                         key="wl_edit",label_visibility="collapsed",placeholder="AAPL NVDA TSLA")
    _new_wl=[x.upper() for x in wl_txt.replace(","," ").split() if x.strip()][:25]
    if _new_wl!=st.session_state.get("watchlist"):
        st.session_state["watchlist"]=_new_wl; save_state(watchlist=_new_wl)
    else:
        st.session_state["watchlist"]=_new_wl
    _rows=""
    for t in st.session_state["watchlist"]:
        q=_tape_q.get(t)
        if q:
            up=q["chg"]>=0; col=UP if up else DN; arr="▲" if up else "▼"
            _rows+=(f'<div class="wl-row"><span class="wl-sym">{t}</span>'
                    f'<span class="wl-px">${q["price"]:,.2f}<br>'
                    f'<span style="color:{col}">{arr} {q["chg"]:+.2f}%</span></span></div>')
        else:
            _rows+=(f'<div class="wl-row"><span class="wl-sym">{t}</span>'
                    f'<span class="wl-px" style="color:{MUTED};font-weight:500;font-size:12px;">'
                    f'{L("no data","لا بيانات")}</span></div>')
    st.markdown(f'<div class="wl-list">{_rows}</div>',unsafe_allow_html=True)

# ════════════════════════ header + API keys ════════════════════════
hcol1, hcol2 = st.columns([4,1])
with hcol1:
    st.markdown(f"""
    <div class="hero">
      <div class="logo">
        <svg width="50" height="50" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="eiB" x1="0" y1="48" x2="48" y2="0">
              <stop stop-color="#1d4ed8"/><stop offset="1" stop-color="#3b82f6"/>
            </linearGradient>
          </defs>
          <!-- rising candlesticks -->
          <line x1="9"  y1="27" x2="9"  y2="40" stroke="#cbd5e1" stroke-width="2.4" stroke-linecap="round"/>
          <rect x="5.5" y="29" width="7" height="8"  rx="2" fill="#cbd5e1"/>
          <line x1="22" y1="17" x2="22" y2="36" stroke="#93c5fd" stroke-width="2.4" stroke-linecap="round"/>
          <rect x="18.5" y="21" width="7" height="11" rx="2" fill="#93c5fd"/>
          <line x1="35" y1="8"  x2="35" y2="31" stroke="url(#eiB)" stroke-width="2.4" stroke-linecap="round"/>
          <rect x="31.5" y="13" width="7" height="14" rx="2" fill="url(#eiB)"/>
          <!-- upward arrow (سهم) of growth -->
          <path d="M7 39 L20 30 L29 34 L42 16" stroke="#16a34a" stroke-width="3" fill="none"
                stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M35 15 L43 15 L43 23" stroke="#16a34a" stroke-width="3" fill="none"
                stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
      <div>
        <h1>{L('Equity Intelligence','محلّل الأسهم الذكي')}</h1>
        <p>{L('Technical · Fundamental · Quantitative research terminal',
              'منصّة بحث: تحليل فنّي · أساسي · كمّي')}</p>
      </div>
    </div>
    """, unsafe_allow_html=True)
with hcol2:
    st.write("")
    try: keybox = st.popover(L("🔑 API Keys","🔑 المفاتيح"), use_container_width=True)
    except Exception: keybox = st.expander(L("🔑 API Keys","🔑 المفاتيح"))
    with keybox:
        st.caption(L("Your key — never stored server-side, used only for live quotes.",
                     "مفتاحك — لا يُحفظ على الخادم، يُستعمل لجلب السعر اللحظي فقط."))
        finnhub_key=st.text_input("Finnhub API Key",type="password",key="fk",help="Free at finnhub.io")
        alpaca_key=st.text_input("Alpaca Key",type="password",key="ak")
        alpaca_sec=st.text_input("Alpaca Secret",type="password",key="asec")
        if not finnhub_key and not alpaca_key:
            st.caption(L("No key → yfinance data (~15-min delayed).",
                         "بدون مفتاح ← بيانات yfinance المؤخّرة ~15 دقيقة."))
_set_keys(finnhub_key, alpaca_key, alpaca_sec)

t0,t1,t2,t3,t4,t5,t6 = st.tabs([
    L("🏠 Markets","🏠 الأسواق"), L("📈 Analysis","📈 التحليل"),
    L("⚖️ Portfolio","⚖️ المحفظة"), L("🏛 Sectors","🏛 القطاعات"),
    L("🚀 Top Movers","🚀 الأكثر حركة"), L("🔔 Alerts","🔔 التنبيهات"),
    L("🔮 Outlook","🔮 النظرة المستقبلية")])

# ───────────────── Markets (home) ─────────────────
with t0:
    def _cards(title, pairs, quotes, fmt):
        st.markdown(f"#### {title}")
        cols = st.columns(len(pairs))
        for col,(tk,nm) in zip(cols,pairs):
            q = quotes.get(tk)
            if q: col.metric(nm, fmt(q["price"]), f"{q['chg']:+.2f}%")
            else: col.metric(nm, "—")
    with st.spinner(L("Loading markets…","تحميل الأسواق…")):
        q_all = {}
        try: q_all = market_quotes(tuple([t for t,_ in US_INDICES+COMMODITIES]))
        except Exception as e: st.error(f"{L('Market data unavailable','بيانات السوق غير متاحة')}: {e}")
    _cards(L("US Indices","المؤشرات الأمريكية"), US_INDICES, q_all, lambda p: f"{p:,.2f}")
    _cards(L("Commodities & Crypto","السلع والعملات الرقمية"), COMMODITIES, q_all,
           lambda p: (f"${p:,.0f}" if p >= 100 else f"${p:,.2f}"))

    c1,c2 = st.columns([2,1])
    with c1:
        try:
            spx = fetch_ohlc("^GSPC","6mo")
            if len(spx) > 5: st.plotly_chart(index_line(spx,L("S&P 500 · 6-Month","S&P 500 · ٦ أشهر")),use_container_width=True)
        except Exception: pass
    with c2:
        try:
            btc = fetch_ohlc("BTC-USD","6mo")
            if len(btc) > 5: st.plotly_chart(index_line(btc,L("Bitcoin · 6-Month","بيتكوين · ٦ أشهر")),use_container_width=True)
        except Exception: pass

    st.markdown(f"#### 📰 {L('Latest Market News','آخر أخبار السوق')}")
    st.caption(L("Aggregated from Yahoo Finance (Reuters, Bloomberg, CNBC and other publishers).",
                 "مجمّعة من Yahoo Finance (رويترز، بلومبرغ، CNBC ومصادر أخرى)."))
    with st.spinner(L("Loading news…","تحميل الأخبار…")):
        news = []
        try: news = market_news(14)
        except Exception: news = []
    if news:
        for it in news:
            meta = " · ".join([x for x in [it.get("publisher",""), it.get("when","")] if x])
            st.markdown(f"**[{it['title']}]({it['url']})**  \n<span style='color:#64748b;font-size:12px'>{meta}</span>",
                        unsafe_allow_html=True)
            st.markdown("<hr style='margin:6px 0'>", unsafe_allow_html=True)
    else:
        st.info(L("News feed unavailable right now. Try again shortly.","تعذّر جلب الأخبار الآن. حاول لاحقاً."))

# ───────────────── Analysis ─────────────────
with t1:
    sym=st.text_input(L("Ticker","الرمز"),value="AAPL",key="single").strip().upper()
    if st.button(L("Analyze","حلّل"),key="b1") and sym:
        st.session_state["sym_a"]=sym
    sym_a=st.session_state.get("sym_a")
    if sym_a:
        _set_keys(finnhub_key, alpaca_key, alpaca_sec)
        with st.spinner(L(f"Analyzing {sym_a}…",f"يحلّل {sym_a}…")):
            try: r=cached_analyze(sym_a, ta.LANG)
            except Exception as e: st.error(f"{L('Analysis failed','فشل التحليل')}: {e}"); r=None
        if not r or r.get("entry",0)<=0:
            st.error(L("Insufficient data for this ticker.","بيانات غير كافية لهذا الرمز."))
        else:
            tr=r.get("_trader",{}); inv=r.get("_investor",{}); det=r.get("details",{})
            with st.spinner("…"): info=cached_info(sym_a)
            def big(x): return ta._fmt_big(x) if x else "—"
            ff=info.get("float_sh"); px0=r["entry"]; chg=r.get("chg",0)
            pe=info.get("pe_fwd") or info.get("pe_trail")
            def num(x,f="{:.2f}"): return f.format(x) if isinstance(x,(int,float)) else "—"
            cells=[
                (L("Market Cap","القيمة السوقية"), big(info.get("mktcap"))),
                (L("Sector","القطاع"), (info.get("sector") or "—")),
                (L("Industry","النشاط"), (info.get("industry") or "—")),
                (L("52W High","الأعلى سنوياً"), money(info.get("high52"))),
                (L("52W Low","الأدنى سنوياً"), money(info.get("low52"))),
                (L("Volume","الحجم"), big(info.get("volume"))),
                (L("Avg Volume","متوسط الحجم"), big(info.get("avg_vol"))),
                (L("Free Float","الأسهم الحرة"), big(ff)),
                (L("Float Cap","قيمة الأسهم الحرة"), big(ff*px0) if ff else "—"),
                (L("Shares","عدد الأسهم"), big(info.get("shares"))),
                (L("Prev Close","الإغلاق السابق"), money(info.get("prev_close"))),
                (L("Day Range","مدى اليوم"), f"{money(info.get('day_low'))} – {money(info.get('day_high'))}"),
                ("P/E", num(pe,"{:.1f}")), ("P/B", num(info.get("pb"))),
                ("P/S", num(info.get("ps"))), ("EPS", num(info.get("eps_trail"))),
                ("Beta", num(info.get("beta"))),
            ]
            grid="".join(f'<div class="qcell"><div class="qlbl">{l}</div><div class="qval">{v}</div></div>' for l,v in cells)
            chg_color = UP if chg>=0 else DN
            st.markdown(f"""
            <style>
            .qhead{{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap;margin:2px 0 10px;}}
            .qhead .qsym{{font-size:22px;font-weight:800;color:{ACC};letter-spacing:.5px;}}
            .qhead .qpx{{font-size:30px;font-weight:800;color:#0f1b33;}}
            .qhead .qchg{{font-size:15px;font-weight:700;color:{chg_color};}}
            .qhead .qnm{{color:#64748b;font-size:14px;}}
            .qgrid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(135px,1fr));gap:8px;margin-bottom:14px;}}
            .qcell{{background:{CARD};border:1px solid {LINE};border-radius:11px;padding:8px 12px;box-shadow:0 1px 2px rgba(15,27,51,.04);}}
            .qlbl{{color:#64748b;font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}}
            .qval{{color:#1a2233;font-size:15px;font-weight:700;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}}
            </style>
            <div class="qhead">
              <span class="qsym">{sym_a}</span>
              <span class="qpx">{money(r['entry'])}</span>
              <span class="qchg">{chg:+.2f}%</span>
              <span class="qnm">{(info.get('name','') or sym_a)}</span>
            </div>
            <div class="qgrid">{grid}</div>
            """, unsafe_allow_html=True)
            dq=info.get("data_quality",{})
            if dq and (dq.get("flags") or dq.get("score",100)<100):
                sc=dq.get("score",100); flg=dq.get("flags",[])
                bc = UP if sc>=80 else ("#d97706" if sc>=50 else DN)
                msg=f"<span style='color:{bc};font-weight:700'>● {L('Data quality','جودة البيانات')}: {sc}%</span>"
                if flg: msg+=" &nbsp;·&nbsp; "+L("unreliable / missing","غير موثوق/مفقود")+": "+", ".join(flg[:8])
                st.markdown(f"<div style='font-size:12px;color:#64748b;margin:-6px 0 12px'>{msg}</div>",unsafe_allow_html=True)

            # ── chart controls (timeframe + optional indicators) ──
            cc1,cc2=st.columns([1,3])
            tf_label=cc1.selectbox(L("Timeframe","الفاصل الزمني"),list(TF_MAP.keys()),key="tf")
            inds=cc2.multiselect(L("Indicators","المؤشرات"),["EMAs","Bollinger Bands","Volume","MACD","RSI","Stoch RSI"],
                                 default=["Volume","Stoch RSI"],key="inds")
            oc1,oc2,oc3=st.columns(3)
            ov_levels=oc1.checkbox(L("Draw S/R levels","رسم الدعم/المقاومة"),value=True,key="ovL")
            ov_pat=oc2.checkbox(L("Draw patterns","رسم النماذج"),value=True,key="ovP")
            ov_plan=oc3.checkbox(L("Draw trade plan","رسم خطة الصفقة"),value=False,key="ovT")
            overlays={
                "show_levels":ov_levels,"show_patterns":ov_pat,"show_plan":ov_plan,
                "resistances":det.get("res_zones",[]),"supports":det.get("sup_zones",[]),
                "patterns":[p for p in det.get("pattern_detail",[]) if p.get("type") in ("Chart","شارت","Harmonic","هارمونيك") and (p.get("brk") or p.get("target"))],
                "plan":{"entry":r["entry"],"stop":tr.get("stop"),"tp1":tr.get("tp1"),"tp2":tr.get("tp2"),"tp3":inv.get("tp3")},
                "atr":det.get("indicators",{}).get("atr"),
            }
            period,interval=TF_MAP[tf_label]
            dfp=None
            try: dfp=fetch_ohlc(sym_a,period,interval)
            except Exception: dfp=None
            if dfp is not None and len(dfp)>10:
                try: st.plotly_chart(price_chart(dfp,sym_a,inds,tf_label,overlays),use_container_width=True)
                except Exception as e: st.caption(f"Chart unavailable: {e}")

            # daily series for the forecast (independent of chart timeframe)
            dff = dfp if interval=="1d" and dfp is not None else None
            if dff is None:
                try: dff=fetch_ohlc(sym_a,"1y","1d")
                except Exception: dff=None
            fb,fb_drv=flow_bias(info); fc_t=fc_i={}
            if dff is not None and len(dff)>=30:
                cl=dff["Close"].values; vl=dff["Volume"].values
                try:
                    fc_t=ta.forecast_probabilistic(cl,r["entry"],tr.get("stop",0),tr.get("tp1",0),10,v=vl,flow_bias=fb)
                    fc_i=ta.forecast_probabilistic(cl,r["entry"],inv.get("stop",0),inv.get("tp1",0),35,v=vl,flow_bias=fb)
                except Exception: pass
            if not fc_t.get("ok"): fc_t=tr.get("forecast",{})
            if not fc_i.get("ok"): fc_i=inv.get("forecast",{})

            # ── risk management inputs (account + risk per trade) ──
            vpf_pl=det.get("volume_profile")
            def _vp_zone(level):
                if not vpf_pl or not isinstance(level,(int,float)): return ""
                tol=0.012
                def near(b): return isinstance(b,(int,float)) and b>0 and abs(level/b-1)<=tol
                if near(vpf_pl.get("poc")): return L("at VPOC — max-liquidity wall","عند VPOC — جدار سيولة")
                if near(vpf_pl.get("vah")): return L("at value-area high","عند قمة منطقة القيمة")
                if near(vpf_pl.get("val")): return L("at value-area low","عند قاع منطقة القيمة")
                for nd in (vpf_pl.get("hvn") or []):
                    if near(nd.get("level")): return L("at HVN — liquidity wall","عند HVN — جدار سيولة")
                for nd in (vpf_pl.get("lvn") or []):
                    if near(nd.get("level")): return L("at LVN — thin, fast move","عند LVN — رقيق وعبور سريع")
                return ""
            def _rr_line(rr):
                if not isinstance(rr,(int,float)) or rr<1.0:
                    st.markdown(f"<span style='color:{DN};font-weight:700'>⚠️ "
                                + L(f"No valid setup now — R:R {rr:.1f}:1 below 1:1 (loses mathematically)",
                                    f"لا إعداد صالح حالياً — R:R {rr:.1f}:1 أقل من 1:1 (يخسر رياضياً)")
                                + "</span>",unsafe_allow_html=True)
                    return
                clr=UP if rr>=2 else ("#d97706" if rr>=1.5 else MUTED)
                st.markdown(f"**{L('R:R','المخاطرة/العائد')}:** <span style='color:{clr};font-weight:700'>1:{rr:.1f}</span>",unsafe_allow_html=True)

            # ── compute Quant Factor Scorecard (drives conviction + the dials below) ──
            _ind=det.get("indicators",{}); _mtf=det.get("mtf",{}); _vp=det.get("volume_profile")
            _px=r.get("entry",0) or 0
            _e9,_e21,_e50,_e200=_ind.get("ema9"),_ind.get("ema21"),_ind.get("ema50"),_ind.get("ema200")
            _rsi=_ind.get("rsi",50); _mh=_ind.get("macd_h",0); _atr=_ind.get("atr")
            def _num(x): return isinstance(x,(int,float)) and x==x
            _tc=[_num(_e200) and _px>_e200, _num(_e50) and _px>_e50,
                 _num(_e9) and _num(_e21) and _e9>_e21, _num(_e50) and _num(_e200) and _e50>_e200]
            f_trend=sum(1 for x in _tc if x)/len(_tc)*100
            ev_trend=L(f"Price above {sum(1 for x in _tc[:2] if x)}/2 key EMAs"+("; EMA50>EMA200 (golden)" if _tc[3] else "; no golden cross"),
                       f"السعر فوق {sum(1 for x in _tc[:2] if x)}/2 من المتوسطات الرئيسية"+("؛ EMA50>EMA200 (ذهبي)" if _tc[3] else "؛ لا تقاطع ذهبي"))
            _rsi_sc=max(0,min(100,(_rsi-40)/0.30)) if _num(_rsi) else 50
            if _num(_rsi) and _rsi>78: _rsi_sc*=0.7
            f_mom=( _rsi_sc*0.6 + (85 if _mh>0 else 25)*0.4 )
            ev_mom=L(f"RSI {_rsi:.0f}; MACD histogram {'positive' if _mh>0 else 'negative'}",
                     f"RSI {_rsi:.0f}؛ هيستوجرام MACD {'موجب' if _mh>0 else 'سالب'}")
            _tf=[d.get("bull",0)/5 for d in _mtf.values()] if _mtf else []
            f_mtf=(sum(_tf)/len(_tf)*100) if _tf else 50
            ev_mtf=L(f"{len(_tf)} timeframes; avg bull {f_mtf:.0f}%" if _tf else "single timeframe",
                     f"{len(_tf)} أطر زمنية؛ متوسط صعودي {f_mtf:.0f}%" if _tf else "إطار واحد")
            if _vp and _num(_vp.get("val")) and _num(_vp.get("vah")):
                if _px>_vp["vah"]: f_vol=72; _vl=L("above value area (demand in control)","فوق منطقة القيمة (الطلب مسيطر)")
                elif _px<_vp["val"]: f_vol=40; _vl=L("below value area (discounted/weak)","تحت منطقة القيمة (مخفّض/ضعيف)")
                else: f_vol=58; _vl=L("inside value area (balanced)","داخل منطقة القيمة (متوازن)")
            else: f_vol=50; _vl=L("no volume profile","لا ملف حجم")
            ev_vol=_vl
            _bull=det.get("bull_pts",0); _bear=det.get("bear_pts",0)
            f_struct=(_bull/(_bull+_bear)*100) if (_bull+_bear)>0 else 50
            ev_struct=L(f"{_bull} bullish vs {_bear} bearish structural signals",
                        f"{_bull} إشارة هيكلية صاعدة مقابل {_bear} هابطة")
            _atrp=(_atr/_px*100) if (_num(_atr) and _px>0) else None
            if _atrp is None: f_volreg=50; _rl=L("unknown","غير معروف")
            elif _atrp<=5: f_volreg=78; _rl=L("normal","طبيعي")
            elif _atrp<=8: f_volreg=55; _rl=L("elevated","مرتفع")
            else: f_volreg=35; _rl=L("high (wide stops)","عالٍ (وقف واسع)")
            ev_volreg=L(f"ATR {_atrp:.1f}% of price — {_rl}" if _atrp is not None else "n/a",
                        f"ATR {_atrp:.1f}% من السعر — {_rl}" if _atrp is not None else "غير متاح")
            factors=[
                (L("Trend","الاتجاه"),f_trend,0.25,ev_trend),
                (L("Momentum","الزخم"),f_mom,0.20,ev_mom),
                (L("Timeframe alignment","توافق الأطر"),f_mtf,0.20,ev_mtf),
                (L("Volume / liquidity","الحجم والسيولة"),f_vol,0.15,ev_vol),
                (L("Structure","الهيكل"),f_struct,0.12,ev_struct),
                (L("Volatility regime","نظام التذبذب"),f_volreg,0.08,ev_volreg)]
            composite=sum(s*w for _,s,w,_ in factors)
            if composite>=66: c_lbl,c_clr=L("Strong alignment","توافق قوي"),UP
            elif composite>=45: c_lbl,c_clr=L("Mixed / neutral","مختلط / محايد"),"#d97706"
            else: c_lbl,c_clr=L("Weak alignment","توافق ضعيف"),DN
            def _conviction(rr):
                # combine R:R (trade geometry) with factor quality (probability) into one honest verdict
                if not _num(rr) or rr<1.0: return  # already flagged by _rr_line
                good_rr=rr>=2.0; strong=composite>=60; weak=composite<45
                if good_rr and strong: ic,clr,msg="✅",UP,L("High conviction — reward and setup quality align.","قناعة عالية — العائد وجودة الإعداد متوافقان.")
                elif good_rr and weak: ic,clr,msg="⚠️",DN,L(f"Attractive reward (R:R 1:{rr:.1f}) but weak setup ({composite:.0f}/100) → low probability. Reward alone isn't enough — avoid or size down.",f"عائد جذّاب (R:R 1:{rr:.1f}) لكن إعداد ضعيف ({composite:.0f}/100) → احتمال منخفض. العائد وحده لا يكفي — تجنّب أو صغّر الحجم.")
                elif (not good_rr) and strong: ic,clr,msg="🟡","#d97706",L(f"Good setup ({composite:.0f}/100) but modest reward (R:R 1:{rr:.1f}).","إعداد جيّد ({composite:.0f}/100) لكن مكافأة متواضعة (R:R 1:{rr:.1f}).")
                elif weak: ic,clr,msg="❌",DN,L(f"Weak setup ({composite:.0f}/100) — avoid.",f"إعداد ضعيف ({composite:.0f}/100) — تجنّب.")
                else: ic,clr,msg="🟡","#d97706",L(f"Mixed — reward 1:{rr:.1f}, setup {composite:.0f}/100. Wait for confirmation.",f"مختلط — العائد 1:{rr:.1f}، الإعداد {composite:.0f}/100. انتظر التأكيد.")
                st.markdown(f"<div style='border-{('right' if ar else 'left')}:3px solid {clr};background:rgba(0,0,0,.02);"
                            f"border-radius:6px;padding:7px 10px;margin-top:4px;font-size:12.5px'>"
                            f"<b style='color:{clr}'>{ic} {L('Conviction','الحكم المدمج')}:</b> {msg}</div>",unsafe_allow_html=True)

            a,b=st.columns(2)
            with a:
                st.subheader(L("⚡ Day-Trader Setup","⚡ خطة المضارب")+f" · {tr.get('score',0)}/10")
                st.write(f"**{L('Entry zone','منطقة الدخول')}:** {money(tr.get('entry_lo'))} – {money(tr.get('entry_hi'))}")
                _sz=_vp_zone(tr.get('stop'))
                st.write(f"**{L('Stop','الوقف')}:** {money(tr.get('stop'))} ({tr.get('stop_pct',0):.1f}%-) · {tr.get('stop_method','')}"
                         + (f" · _{_sz}_" if _sz else ""))
                _tz=_vp_zone(tr.get('tp1'))
                st.write(f"**{L('Targets','الأهداف')}:** {money(tr.get('tp1'))} / {money(tr.get('tp2'))}"
                         + (f" · _{L('T1','هـ١')} {_tz}_" if _tz else ""))
                _rr_line(tr.get('rr',0))
                _conviction(tr.get('rr',0))
                _tr_entry=tr.get('entry_ref') or (((tr.get('entry_lo') or 0)+(tr.get('entry_hi') or 0))/2 if tr.get('entry_hi') else r.get('entry'))
                if isinstance(_tr_entry,(int,float)):
                    st.caption(L(f"R:R measured from a single entry ref ${_tr_entry:.2f}",
                                 f"R:R محسوب من نقطة دخول واحدة ${_tr_entry:.2f}"))
                if tr.get("bt_trades"):
                    st.caption(f"📚 {L('Backtest','اختبار تاريخي')}: {tr['bt_trades']} {L('trades','صفقة')} · "
                               f"{L('win','نجاح')} {tr.get('bt_winrate',0):.0f}% · {L('avg R','متوسط R')} {tr.get('bt_avgR',0):+.2f}")
            with b:
                st.subheader(L("📈 Long-Term Investor Thesis","📈 رؤية المستثمر")+f" · {inv.get('score',0)}/10")
                st.write(f"**{L('Entry','الدخول')}:** {inv.get('entry_note','—')}")
                _isz=_vp_zone(inv.get('stop'))
                st.write(f"**{L('Stop','الوقف')}:** {money(inv.get('stop'))} ({inv.get('stop_pct',0):.1f}%-)"
                         + (f" · _{_isz}_" if _isz else ""))
                _itz=_vp_zone(inv.get('tp1'))
                st.write(f"**{L('Targets','الأهداف')}:** {money(inv.get('tp1'))} / {money(inv.get('tp2'))} / {money(inv.get('tp3'))}"
                         + (f" · _{L('T1','هـ١')} {_itz}_" if _itz else ""))
                _rr_line(inv.get('rr',0))
                _conviction(inv.get('rr',0))

            # ── Quant Factor Scorecard: transparent, weighted factor attribution (explainable, not black-box) ──
            st.subheader(L("🧮 Quant Factor Scorecard","🧮 بطاقة العوامل الكمّية"))
            st.caption(L("A transparent decomposition of the rating into institutional factor families — each with its weight, score, and the evidence behind it. Explainable by design, not a black box.",
                         "تفكيك شفّاف للتقييم إلى عائلات عوامل مؤسسية — لكلٍّ وزنه ودرجته والدليل خلفه. قابل للتفسير بالتصميم، لا صندوق أسود."))
            import math as _math
            def _ring(score, size, stroke, color, big=False):
                r=(size-stroke)/2.0; C=2*_math.pi*r; off=C*(1-max(0,min(100,score))/100.0)
                fs=int(size*0.34)
                return (f"<svg width='{size}' height='{size}' viewBox='0 0 {size} {size}' style='display:block;margin:0 auto'>"
                        f"<circle cx='{size/2}' cy='{size/2}' r='{r:.1f}' fill='none' stroke='{LINE}' stroke-width='{stroke}'/>"
                        f"<circle cx='{size/2}' cy='{size/2}' r='{r:.1f}' fill='none' stroke='{color}' stroke-width='{stroke}' "
                        f"stroke-dasharray='{C:.1f}' stroke-dashoffset='{off:.1f}' stroke-linecap='round' "
                        f"transform='rotate(-90 {size/2} {size/2})'/>"
                        f"<text x='50%' y='50%' text-anchor='middle' dominant-baseline='central' "
                        f"font-size='{fs}' font-weight='800' fill='{color}'>{score:.0f}</text></svg>")
            def _fclr(s): return UP if s>=66 else ("#d97706" if s>=45 else DN)
            # composite dial + verdict
            st.markdown(
                f"<div style='display:flex;align-items:center;gap:18px;justify-content:center;flex-wrap:wrap;margin:4px 0 14px'>"
                f"<div>{_ring(composite,140,14,c_clr,big=True)}"
                f"<div style='text-align:center;font-size:11px;color:{MUTED};margin-top:-4px'>/100</div></div>"
                f"<div style='text-align:{'right' if ar else 'left'}'>"
                f"<div style='font-size:17px;font-weight:800;color:{c_clr}'>{c_lbl}</div>"
                f"<div style='font-size:12.5px;color:{MUTED};max-width:240px'>"
                f"{L('Weighted composite (0–100) of the six factors below — each ring is that factor’s score.','مركّب مرجّح (0–100) للعوامل الستّة أدناه — كل دائرة تمثّل درجة عاملها.')}</div>"
                f"</div></div>", unsafe_allow_html=True)
            # six factor mini-dials in a grid
            _cols=st.columns(3)
            for _i,(nm,sc_f,w,ev) in enumerate(factors):
                with _cols[_i%3]:
                    fc=_fclr(sc_f)
                    st.markdown(
                        f"<div style='text-align:center;padding:8px 4px'>"
                        f"{_ring(sc_f,84,9,fc)}"
                        f"<div style='font-size:12.5px;font-weight:700;margin-top:4px'>{nm}</div>"
                        f"<div dir='ltr' style='font-size:11px;color:{MUTED}'>{L('weight','وزن')} {w*100:.0f}% · +{sc_f*w:.1f}</div>"
                        f"<div style='font-size:10.5px;color:{MUTED};line-height:1.4;margin-top:3px'>{ev}</div></div>",
                        unsafe_allow_html=True)
            st.caption(L("Each ring is a factor scored 0–100 from live indicators; ×weight = its contribution (+x); the sum is the composite. Every input is inspectable — the rating can always be explained.",
                         "كل دائرة عامل مُقيَّم 0–100 من مؤشّرات حيّة؛ ×الوزن = مساهمته (الـ+x)؛ والمجموع هو المركّب. كل مُدخَل قابل للفحص — والتقييم قابل للتفسير دائماً."))

            # ── detailed technical analysis (full depth, like the CLI) ──
            with st.expander(L("🔬 Detailed Technical Analysis","🔬 التحليل الفني المفصّل"), expanded=True):
                px = r["entry"]; ind = det.get("indicators",{})
                # ── deep quant "Stock Strength" (0-100): timeframes + indicators + momentum + internal model agreement ──
                bull = det.get("bull_pts",0); bear = det.get("bear_pts",0); sc = r.get("score",0)
                mtf = det.get("mtf",{}); _sch = det.get("schools",{})
                def _dirv(s):
                    s=str(s)
                    up = any(t in s for t in ["📈","✅","🟢","صاعد","Uptrend","Bullish","Markup","ترقّي","Accumulation","تراكم","Golden","BOS صاعد"])
                    dn = any(t in s for t in ["📉","🔴","هابط","Downtrend","Bearish","Markdown","Distribution","توزيع"])
                    return 1 if (up and not dn) else (-1 if (dn and not up) else 0)
                tf_vals=[d.get("bull",0)/5 for d in mtf.values()] if mtf else []
                tf_s=sum(tf_vals)/len(tf_vals) if tf_vals else 0.5
                ic=itot=0
                if ind:
                    checks=[px>ind.get("ema200",px), px>ind.get("ema50",px), ind.get("ema9",0)>ind.get("ema21",0),
                            ind.get("macd_h",0)>0, 45<=ind.get("rsi",50)<=72]
                    ic=sum(1 for c in checks if c); itot=len(checks)
                ind_s=ic/itot if itot else 0.5
                sigs=[_dirv(_sch[k]) for k in ("dow","wyckoff","ichimoku") if _sch.get(k)]
                sigs+=[_dirv(x) for x in _sch.get("smc",[])]
                sch_s=(sum(1 for x in sigs if x>0)/len(sigs)) if sigs else 0.5
                bb_s=bull/(bull+bear) if (bull+bear)>0 else 0.5
                strength=max(0,min(100,round(100*(0.30*tf_s + 0.30*ind_s + 0.25*sch_s + 0.15*bb_s))))
                lab=(L("Very Strong","قوي جداً") if strength>=75 else L("Strong","قوي") if strength>=60
                     else L("Moderate","متوسط") if strength>=45 else L("Weak","ضعيف") if strength>=30 else L("Very Weak","ضعيف جداً"))
                dot="🟢" if strength>=60 else ("🟡" if strength>=45 else "🔴")
                st.markdown(f"### {dot} {L('Stock Strength','قوة السهم')}: {strength}/100 · {lab}")
                st.progress(strength/100)
                st.caption(L("Composite quant strength — multi-timeframe alignment, indicator confluence, momentum and model agreement.",
                             "قوة كمّية مركّبة — توافق الأطر الزمنية والتقاء المؤشرات والزخم وتوافق النماذج."))

                # multi-timeframe
                mtf=det.get("mtf",{})
                if mtf:
                    st.markdown(f"**⏱ {L('Timeframes','الأطر الزمنية')}**")
                    def _tr(t): return L("🟢 Up","🟢 صاعد") if "🟢" in str(t) else (L("🔴 Down","🔴 هابط") if "🔴" in str(t) else L("🟡 Neutral","🟡 محايد"))
                    st.dataframe(pd.DataFrame([{
                        L("Timeframe","الإطار"):k,L("Trend","الاتجاه"):_tr(d.get("trend","")),"RSI":f"{d.get('rsi',0):.0f}",
                        "EMA":"▲ Gold" if d.get("ema9",0)>d.get("ema21",0) else "▼ Death",
                        "MACD":"▲ Pos" if d.get("macd_h",0)>0 else "▼ Neg",L("Strength","القوة"):f"{d.get('bull',0)}/5",
                    } for k,d in mtf.items()]),hide_index=True,use_container_width=True)

                # indicators with Signal + Note (matches the CLI)
                if ind:
                    def _rsi(x):
                        if x>75: return "🔴 Overbought","70+ sell zone"
                        if x<30: return "🟢 Oversold","30- buy zone"
                        if x>55: return "🟢 Strong","bullish momentum"
                        if x<45: return "🔴 Weak","bearish"
                        return "🟡 Neutral","—"
                    rs,rn=_rsi(ind["rsi"])
                    bbu_near = px>ind["bb_u"]*0.97; bbl_near = px<ind["bb_lo"]*1.03; atr_hi = ind["atr"]/px>0.04 if px else False
                    st.markdown(f"**📊 {L('Indicators','المؤشرات')}**")
                    st.dataframe(pd.DataFrame([
                        {"Indicator":"RSI (14)","Value":f"{ind['rsi']:.1f}","Signal":rs,"Note":rn},
                        {"Indicator":"EMA 9 / 21","Value":f"{ind['ema9']:.2f} / {ind['ema21']:.2f}",
                         "Signal":"🟢 Golden Cross" if ind['ema9']>ind['ema21'] else "🔴 Death Cross","Note":"short-term trend"},
                        {"Indicator":"EMA 50","Value":f"${ind['ema50']:.2f}",
                         "Signal":"🟢 Price Above" if px>ind['ema50'] else "🔴 Below","Note":"mid-term trend"},
                        {"Indicator":"EMA 200","Value":f"${ind['ema200']:.2f}",
                         "Signal":"🟢 Uptrend" if px>ind['ema200'] else "🔴 Downtrend","Note":"long-term trend"},
                        {"Indicator":"MACD","Value":f"{ind['macd_h']:+.4f}",
                         "Signal":"🟢 Positive" if ind['macd_h']>0 else "🔴 Negative","Note":"momentum"},
                        {"Indicator":"BB Upper","Value":f"${ind['bb_u']:.2f}",
                         "Signal":"⚠️ Near top" if bbu_near else "Normal","Note":f"{(ind['bb_u']-px)/px*100:.1f}% away"},
                        {"Indicator":"BB Lower","Value":f"${ind['bb_lo']:.2f}",
                         "Signal":"🟢 Near bottom" if bbl_near else "Normal","Note":f"{(px-ind['bb_lo'])/px*100:.1f}% away"},
                        {"Indicator":"ATR (14)","Value":f"${ind['atr']:.2f}",
                         "Signal":"⚠️ High" if atr_hi else "Normal","Note":f"{ind['atr']/px*100:.1f}% of price"},
                    ]),hide_index=True,use_container_width=True)

                # (Analysis schools are computed internally and feed the strength score — intentionally not displayed.)

                # support / resistance with distance, strength, and confluent methods
                rz=det.get("res_zones",[]); sz=det.get("sup_zones",[])
                if rz or sz:
                    st.markdown(f"**🧱 {L('Support & Resistance','الدعم والمقاومة')}**")
                    st.caption(L("Institutional method: swing pivots + volume nodes + Fibonacci + pivots + EMAs + round numbers, clustered and ranked by touches & confluence.",
                                 "طريقة مؤسسية: قمم/قيعان + مناطق حجم + فيبوناتشي + بيفوت + متوسطات + أرقام مستديرة، مجمّعة ومرتّبة بعدد اللمسات والتقاء المدارس."))
                    srrows=[]
                    cL=L("Level","المستوى"); pL=L("Price","السعر"); dL=L("Distance","البُعد"); tL=L("Touches","اللمسات"); fL=L("Confluence","تقاطع المدارس")
                    for i,z in enumerate(rz,1):
                        srrows.append({cL:f"R{i}",pL:f"${z['level']:.2f}",dL:f"+{z['dist']:.1f}%",
                                       tL:str(z["touches"]),fL:" + ".join(z["methods"])})
                    srrows.append({cL:L("▶ Current","▶ الحالي"),pL:f"${px:.2f}",dL:"—",tL:"—",fL:"—"})
                    for i,z in enumerate(sz,1):
                        srrows.append({cL:f"S{i}",pL:f"${z['level']:.2f}",dL:f"{z['dist']:.1f}%",
                                       tL:str(z["touches"]),fL:" + ".join(z["methods"])})
                    st.dataframe(pd.DataFrame(srrows),hide_index=True,use_container_width=True)
                else:
                    res=det.get("resistances",[]); sup=det.get("supports",[])
                    if res or sup:
                        st.markdown(f"**🧱 {L('Support & Resistance','الدعم والمقاومة')}**")
                        st.markdown(f"🔴 {L('Resistance','مقاومة')}: "+(" · ".join(f"${x:.2f}" for x in res) if res else "—"))
                        st.markdown(f"🟢 {L('Support','دعم')}: "+(" · ".join(f"${x:.2f}" for x in sup) if sup else "—"))

                # ── Volume Profile (liquidity-based levels) ──
                vpf=det.get("volume_profile")
                if vpf and vpf.get("profile"):
                    st.markdown(f"**📊 {L('Volume Profile (liquidity)','ملف الحجم (السيولة)')}**")
                    st.caption(L("Where real volume traded — institutional support/resistance. VPOC = fairest price (strongest magnet); Value Area = where 70% of volume changed hands.",
                                 "حيث تداول حجم حقيقي — دعم/مقاومة مؤسسي. VPOC = أعدل سعر (أقوى مغناطيس)؛ منطقة القيمة = حيث تداول ٧٠٪ من الحجم."))
                    vc1,vc2,vc3=st.columns(3)
                    vc1.metric("VPOC",f"${vpf['poc']:.2f}")
                    vc2.metric(L("Value Area High","أعلى منطقة القيمة"),f"${vpf['vah']:.2f}")
                    vc3.metric(L("Value Area Low","أدنى منطقة القيمة"),f"${vpf['val']:.2f}")
                    levels=[p["level"] for p in vpf["profile"]]; vols=[p["vol"] for p in vpf["profile"]]
                    bar_cols=[]
                    for lv in levels:
                        if abs(lv-vpf["poc"])<1e-6 or lv==min(levels,key=lambda x:abs(x-vpf["poc"])): bar_cols.append(ACC)
                        elif vpf["val"]<=lv<=vpf["vah"]: bar_cols.append("#93b4f5")
                        else: bar_cols.append("#d7dee8")
                    vfig=go.Figure(go.Bar(x=vols,y=levels,orientation="h",marker=dict(color=bar_cols),
                                          hovertemplate="$%{y:.2f} · "+L("vol","حجم")+" %{x:.0%}<extra></extra>"))
                    vfig.add_hline(y=vpf["poc"],line=dict(color=ACC,width=1.4,dash="solid"))
                    vfig.add_hline(y=vpf["vah"],line=dict(color=MUTED,width=1,dash="dot"))
                    vfig.add_hline(y=vpf["val"],line=dict(color=MUTED,width=1,dash="dot"))
                    vfig.add_hline(y=px,line=dict(color=DN,width=1.2,dash="dash"))
                    vfig.update_layout(template="plotly_white",height=300,margin=dict(l=8,r=8,t=10,b=8),
                                       paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",showlegend=False,
                                       font=dict(family="Inter",color="#334155"),bargap=0.05)
                    vfig.update_xaxes(visible=False); vfig.update_yaxes(title=L("Price","السعر"),gridcolor=LINE)
                    st.plotly_chart(vfig,use_container_width=True)
                    hv=vpf.get("hvn",[]); lv=vpf.get("lvn",[])
                    if hv:
                        st.markdown("**"+L("High-volume nodes (strong S/R)","عقد عالية الحجم (دعم/مقاومة قوي)")+":** "+
                                    " · ".join(f"${x['level']:.2f}" for x in hv[:4]))
                    if lv:
                        st.markdown("**"+L("Low-volume nodes (price moves fast)","عقد منخفضة الحجم (يتحرّك السعر بسرعة)")+":** "+
                                    " · ".join(f"${x['level']:.2f}" for x in lv[:4]))
                    st.caption(L(f"Current price ${px:.2f} is "+("inside the value area (balanced/fair)." if vpf['val']<=px<=vpf['vah'] else "above the value area (extended up)." if px>vpf['vah'] else "below the value area (discounted)."),
                                 f"السعر الحالي ${px:.2f} "+("داخل منطقة القيمة (متوازن/عادل)." if vpf['val']<=px<=vpf['vah'] else "فوق منطقة القيمة (ممتدّ صعوداً)." if px>vpf['vah'] else "تحت منطقة القيمة (مخصوم).")))

                # detected patterns
                pats=det.get("pattern_detail",[])
                if pats:
                    st.markdown(f"**🕯 {L('Detected Patterns','النماذج المكتشفة')}**")
                    st.dataframe(pd.DataFrame([{
                        L("Pattern","النموذج"):p["name"],L("Type","النوع"):p["type"],
                        L("Direction","الاتجاه"):(L("🟢 Bullish","🟢 صاعد") if p["dir"]=="BULLISH" else (L("🔴 Bearish","🔴 هابط") if p["dir"]=="BEARISH" else L("🟡 Neutral","🟡 محايد"))),
                        L("Strength","القوة"):"★"*int(p.get("strength",0) or 0),L("Meaning","المعنى"):p.get("desc","")[:40],
                    } for p in pats]),hide_index=True,use_container_width=True)

                # reasons / signals
                cs1,cs2=st.columns(2)
                with cs1:
                    st.markdown(f"**⚡ {L('Trader signals','إشارات المضارب')}**")
                    for s in (tr.get("signals") or [])[:8]: st.markdown(f"- {s}")
                with cs2:
                    st.markdown(f"**📈 {L('Investor signals','إشارات المستثمر')}**")
                    for s in (inv.get("signals") or [])[:8]: st.markdown(f"- {s}")

            # ── ownership & institutional activity (replaces fundamentals; basics are in the top grid) ──
            st.subheader(f"🏛 {L('Ownership','التملّك')}")
            act=cached_inst_activity(sym_a)
            inst=act.get("inst_pct"); ins=act.get("insider_pct")
            if inst is None: inst=info.get("institutions")
            if ins is None: ins=info.get("insiders")
            oc1,oc2,oc3=st.columns(3)
            oc1.metric(L("Institutional","ملكية المؤسسات"),pct(inst))
            oc2.metric(L("Closely-held*","ملكية مقرّبة*"),pct(ins))
            d=act.get("direction")
            if d=="increase":
                chg_txt=L("▲ Increase","▲ زيادة"); chg_clr=UP
            elif d=="decrease":
                chg_txt=L("▼ Decrease","▼ نقصان"); chg_clr=DN
            else:
                chg_txt=L("→ Flat","→ ثبات"); chg_clr=MUTED
            avg=act.get("avg_change")
            sub=f" ({avg*100:+.1f}%)" if isinstance(avg,(int,float)) else ""
            oc3.markdown(f"<div style='padding-top:6px'><div style='color:{MUTED};font-size:11px;font-weight:600;"
                         f"text-transform:uppercase;letter-spacing:.5px'>{L('Last-Quarter Change','تغيّر الربع الأخير')}</div>"
                         f"<div style='color:{chg_clr};font-size:22px;font-weight:800;margin-top:4px'>{chg_txt}{sub}</div></div>",
                         unsafe_allow_html=True)
            # controlled-company flag: a high "closely-held" % is usually a controlling parent/affiliate, NOT individual insider buying
            if isinstance(ins,(int,float)) and ins>=0.50:
                st.warning(L(f"🏢 Controlled company: ~{ins*100:.0f}% is closely held — typically a controlling parent or founder block, **not** individual insider buying. Treat it as control/float, not a bullish insider signal.",
                             f"🏢 شركة مُسيطَر عليها: ~{ins*100:.0f}% ملكية مقرّبة — غالباً شركة أمّ مسيطرة أو كتلة مؤسِّسين، **وليست** شراء مطّلعين أفراد. اعتبرها سيطرة/تعويم لا إشارة شراء صعودية.")
                         )
            st.caption(L("*Closely-held = insiders + affiliates/controlling shareholders (free data merges them; a controlling parent shows here, not as a separate line).",
                         "*الملكية المقرّبة = المطّلعون + المقرّبون/المساهمون المسيطرون (البيانات المجانية تدمجهم؛ فالشركة الأمّ المسيطرة تظهر هنا لا في سطر منفصل)."))
            inc=act.get("increased",0); dec=act.get("decreased",0); net=act.get("net_shares")
            if inc or dec:
                parts=[L(f"{inc} holders increased",f"{inc} مالكاً زادوا"),
                       L(f"{dec} reduced",f"{dec} خفّضوا")]
                if isinstance(net,(int,float)) and abs(net)>0:
                    sign=L("net added","صافي مضاف") if net>0 else L("net reduced","صافي مخفّض")
                    parts.append(f"{sign}: {ta._fmt_big(abs(net))} {L('shares','سهم')}")
                cap=" · ".join(parts)
                if act.get("as_of"): cap+=f" · {L('as of','حتى')} {act['as_of']}"
                st.caption(cap)
            else:
                st.caption(L("Quarterly holder-level change data not available for this ticker.",
                             "تفاصيل تغيّر الملّاك ربعياً غير متوفّرة لهذا الرمز."))

            # ── latest news on this stock ──
            st.markdown("")
            st.markdown(f"#### 📰 {L('Latest News','آخر الأخبار')} · {sym_a}")
            news=stock_news(sym_a, limit=8)
            if news:
                for n in news:
                    meta=" · ".join([x for x in [n.get("publisher",""),n.get("when","")] if x])
                    st.markdown(
                        f"""<div class="news-item">
                        <a href="{n['url']}" target="_blank" class="news-title">{n['title']}</a>
                        <div class="news-meta">{meta}</div></div>""",
                        unsafe_allow_html=True)
            else:
                st.caption(L("No recent news available for this ticker.",
                             "لا تتوفّر أخبار حديثة لهذا الرمز حالياً."))

# ───────────────── Portfolio ─────────────────
with t2:
    txt=st.text_input(L("Tickers (space-separated)","الرموز (مفصولة بمسافة)"),value="NVDA AMD AVGO",key="port")
    st.caption(L("🧠 Ranked by a composite: 30% technical (above the EMAs) + 25% fundamentals + 15% today's move + 20% institutional ownership + 10% insider buying.",
                 "🧠 مرتّب حسب مركّب: ٣٠٪ فني (فوق المتوسطات الأسية) + ٢٥٪ مالي + ١٥٪ نسبة اليوم + ٢٠٪ اهتمام مؤسسي + ١٠٪ شراء المطّلعين."))
    if st.button(L("Compare","قارن"),key="b2") and txt:
        _set_keys(finnhub_key, alpaca_key, alpaca_sec)
        syms=[t.upper() for t in txt.replace(","," ").split() if t.strip()][:10]
        rows=[]; prog=st.progress(0.0)
        for i,s in enumerate(syms,1):
            try:
                r=cached_analyze(s, ta.LANG); info=cached_info(s)
                if r and r.get("entry",0)>0:
                    px=r["entry"]; ind=(r.get("details",{}) or {}).get("indicators",{}) or {}
                    emas=[ind.get("ema9"),ind.get("ema21"),ind.get("ema50"),ind.get("ema200")]
                    emas=[e for e in emas if isinstance(e,(int,float)) and e>0]
                    above=sum(1 for e in emas if px>e); tot_e=len(emas) or 1
                    tech_n=above/tot_e
                    fin=ta.score_financials(info); fin_n=(fin or 0)/10.0
                    chg=r.get("chg",0.0); today_n=max(0.0,min(1.0,(chg+5)/10.0))
                    inst=info.get("institutions"); insid=info.get("insiders")
                    inst_v=float(inst) if isinstance(inst,(int,float)) else None
                    insid_v=float(insid) if isinstance(insid,(int,float)) else None
                    inst_n=max(0.0,min(1.0,inst_v)) if inst_v is not None else 0.0
                    insid_n=max(0.0,min(1.0,(insid_v/0.10))) if insid_v is not None else 0.0
                    score=round(100*(0.30*tech_n + 0.25*fin_n + 0.15*today_n + 0.20*inst_n + 0.10*insid_n))
                    rows.append({"Symbol":s,"Price":round(px,2),"Score":score,
                                 "AboveEMA":f"{above}/{tot_e}","Financial":fin,"Today":round(chg,1),
                                 "Inst":round(inst_v*100,1) if inst_v is not None else None,
                                 "Insider":round(insid_v*100,1) if insid_v is not None else None})
            except Exception: pass
            prog.progress(i/len(syms))
        prog.empty()
        if rows:
            df=pd.DataFrame(rows).sort_values(["Score","Financial"],ascending=False).reset_index(drop=True)
            df.index=df.index+1
            order=["Symbol","Price","Score","AboveEMA","Financial","Today","Inst","Insider"]
            df=df[order]
            colmap={"Symbol":L("Symbol","الرمز"),"Price":L("Price","السعر"),"Score":L("Score","الأفضلية"),
                    "AboveEMA":L("Above EMAs","فوق المتوسطات"),"Financial":L("Financial","مالي"),
                    "Today":L("Today %","اليوم٪"),"Inst":L("Institutional %","مؤسسي٪"),"Insider":L("Closely-held %","مقرّبون٪")}
            def _sc_bg(v):
                try: t=max(0.0,min(1.0,float(v)/100.0))
                except Exception: return ""
                return f"background-color: rgba(37,99,235,{0.06+0.34*t:.3f}); font-weight:700;"
            sty=(df.rename(columns=colmap).style
                   .format({colmap["Price"]:"${:.2f}", colmap["Financial"]:"{:.0f}/10",
                            colmap["Today"]:"{:+.1f}", colmap["Inst"]:"{:.1f}%", colmap["Insider"]:"{:.1f}%"},na_rep="—")
                   .map(_sc_bg, subset=[colmap["Score"]]))
            st.dataframe(sty,use_container_width=True)

            with st.expander(L("ℹ️ What do the columns mean?","ℹ️ ماذا تعني الأعمدة؟")):
                st.markdown(L(
"""- **Score** — composite (0-100): **30% technical (how many EMAs the price trades above) + 25% fundamentals + 15% today's move + 20% institutional ownership + 10% insider buying**.
- **Above EMAs** — how many of EMA 9/21/50/200 the price is above (4/4 = a clean uptrend on every horizon).
- **Financial** — fundamentals (ROE, growth, margins, valuation).
- **Today %** — today's price change. **Institutional %** — share held by institutions/funds. **Closely-held %** — insiders + affiliates/controlling shareholders (a high value usually means a controlling parent, not insider buying).""",
"""- **الأفضلية (Score)** — مركّب (٠-١٠٠): **٣٠٪ فني (كم متوسطاً أسياً يتداول السعر فوقه) + ٢٥٪ مالي + ١٥٪ نسبة اليوم + ٢٠٪ ملكية مؤسسية + ١٠٪ شراء المطّلعين**.
- **فوق المتوسطات** — فوق كم من EMA ٩/٢١/٥٠/٢٠٠ يتداول السعر (٤/٤ = اتجاه صاعد نظيف على كل الآفاق).
- **مالي** — الأساسيات (العائد على الملكية، النمو، الهوامش، التقييم).
- **اليوم٪** — تغيّر السعر اليوم. **مؤسسي٪** — حصّة المؤسسات/الصناديق. **مقرّبون٪** — المطّلعون + المقرّبون/المساهمون المسيطرون (القيمة العالية غالباً شركة أمّ مسيطرة لا شراء مطّلعين)."""))

            be=df.iloc[0]
            inst_txt = f"{be['Inst']:.1f}%" if pd.notna(be['Inst']) else "—"
            st.success(f"🏆 {L('Strongest overall','الأقوى إجمالاً')}: **{be['Symbol']}** · "
                       f"{L('Score','أفضلية')} {be['Score']}/100 · {L('Above EMAs','فوق المتوسطات')} {be['AboveEMA']} · "
                       f"{L('Financial','مالي')} {be['Financial']}/10 · {L('Institutional','مؤسسي')} {inst_txt}")
            st.caption(L(f"#1 = **{be['Symbol']}**. The score rewards a clean uptrend (above all EMAs), solid fundamentals, positive daily momentum, and strong institutional/insider backing.",
                         f"الأول = **{be['Symbol']}**. الأفضلية تكافئ الاتجاه الصاعد النظيف (فوق كل المتوسطات) والأساسيات المتينة وزخم اليوم الإيجابي ودعم المؤسسات والمطّلعين."))
        else: st.error(L("No tickers could be analyzed.","تعذّر تحليل الرموز."))

# ───────────────── Sectors ─────────────────
with t3:
    c1,c2=st.columns(2)
    sector=c1.selectbox(L("Sector","القطاع"),sorted(ta.SECTORS.keys()),key="sec_sel")
    # industry options derived from the last screen of THIS sector
    prev_rows=st.session_state.get("sector_rows",[]) if st.session_state.get("sector_name")==sector else []
    inds=sorted({(x["info"].get("industry") or "—") for x in prev_rows})
    ind_choice=c2.selectbox(L("Industry","النشاط / الصناعة"),[L("Any","الكل")]+inds,key="ind_sel")
    if st.button(L("Screen Sector","حلّل القطاع"),key="b3") and sector:
        _set_keys(finnhub_key, alpaca_key, alpaca_sec)
        tickers=ta.SECTORS[sector]; rows=[]; prog=st.progress(0.0)
        for i,s in enumerate(tickers,1):
            try:
                r=cached_analyze(s, ta.LANG); info=cached_info(s)
                if info and not info.get("error"):
                    px=info.get("price") or (r.get("entry") if r else 0)
                    if px and px>0:
                        sc,_=ta.analyst_score(info,r.get("score",0) if r else 0)
                        rows.append({"info":info,"sym":s,"score":sc,"tech":r.get("score",0) if r else 0})
            except Exception: pass
            prog.progress(i/len(tickers))
        prog.empty()
        st.session_state["sector_rows"]=rows; st.session_state["sector_name"]=sector
        st.rerun()
    rows=st.session_state.get("sector_rows",[]) if st.session_state.get("sector_name")==sector else []
    if rows:
        any_lbl=L("Any","الكل")
        view=[x for x in rows if ind_choice==any_lbl or (x["info"].get("industry") or "—")==ind_choice]
        view.sort(key=lambda x:x["score"],reverse=True)
        st.caption(L(f"{len(view)} names · sector **{sector}**" + ("" if ind_choice==any_lbl else f" · industry **{ind_choice}**"),
                     f"{len(view)} سهم · قطاع **{sector}**" + ("" if ind_choice==any_lbl else f" · نشاط **{ind_choice}**")))
        if view:
            df=pd.DataFrame([{
                L("Symbol","الرمز"):x["sym"],L("Company","الشركة"):(x["info"].get("name","") or "")[:24],
                L("Industry","النشاط"):(x["info"].get("industry","") or "—")[:26],
                L("Mkt Cap","القيمة"):ta._fmt_big(x["info"].get("mktcap")),
                "P/E":(lambda p:f"{p:.0f}" if p and p>0 else "—")(x["info"].get("pe_fwd") or x["info"].get("pe_trail")),
                L("Rev Growth","نمو الإيراد"):pct(x["info"].get("rev_growth"),0),"ROE":pct(x["info"].get("roe"),0),
                L("Op Margin","هامش التشغيل"):pct(x["info"].get("op_m"),0),L("Technical","فني"):f"{x['tech']}/10",
                L("Analyst","محلّل"):f"{x['score']}/100",
            } for x in view]); df.index=df.index+1
            st.dataframe(df,use_container_width=True)
            st.subheader(L("🥇 Analyst Takeaway — Top Names","🥇 خلاصة المحلّل — الأقوى"))
            for rank,x in enumerate(view[:3],1):
                medal={1:"🥇",2:"🥈",3:"🥉"}[rank]; s_notes,risks=ta._company_notes(x["info"])
                with st.container(border=True):
                    st.markdown(f"### {medal} {x['sym']} — {x['score']}/100")
                    st.caption(f"{(x['info'].get('name','') or '')[:46]} · {(x['info'].get('industry','') or '')[:30]}")
                    if s_notes: st.markdown(f"**✅ {L('Strengths','نقاط القوة')}:** "+" · ".join(s_notes[:4]))
                    if risks:   st.markdown(f"**⚠️ {L('Risks','المخاطر')}:** "+" · ".join(risks[:4]))
        else:
            st.info(L("No names in this industry.","لا أسهم ضمن هذا النشاط."))

# ───────────────── Top Movers ─────────────────
with t4:
    st.caption(L("Today: real-time US market gainers via Yahoo screener. Longer windows: computed across a broad active universe (~240 US names).",
                 "اليوم: أعلى الرابحين في السوق الأمريكي عبر فلتر Yahoo. الفترات الأطول: محسوبة على ~240 سهماً نشطاً."))
    period=st.radio(L("Window","الفترة"),["Today %","5D %","1M %","1Y %"],horizontal=True,key="mv")
    pcols=["1D %","5D %","1M %","1Y %"]
    def clr(v): return "" if pd.isna(v) else (f"color:{UP};font-weight:700;" if v>=0 else f"color:{DN};font-weight:700;")
    if st.button(L("🚀 Show Top Gainers","🚀 اعرض الأكثر ارتفاعاً"),key="b4"):
        if period=="Today %":
            with st.spinner(L("Fetching US market gainers…","جلب أعلى الرابحين…")): rows=yahoo_day_gainers(40)
            if rows:
                df=pd.DataFrame(rows).sort_values("Today %",ascending=False).reset_index(drop=True); df.index=df.index+1
                styled=(df.style.format({"Today %":"{:+.1f}%","Price":"${:.2f}"},na_rep="—").map(clr,subset=["Today %"]))
                st.dataframe(styled,use_container_width=True,height=560)
                tp=df.iloc[0]; st.success(f"🔥 {L('Top US gainer today','أعلى رابح اليوم')}: **{tp['Symbol']}**  {tp['Today %']:+.1f}%  ({tp['Company']})")
            else: st.warning(L("Yahoo screener returned nothing right now (market closed or API changed). Try a longer window.",
                               "لا نتائج من فلتر Yahoo الآن (السوق مغلق أو تغيّرت الواجهة). جرّب فترة أطول."))
        else:
            with st.spinner(L("Fetching market data…","جلب بيانات السوق…")):
                try: rows=fetch_movers(tuple(ta.SCAN_UNIVERSE))
                except Exception as e: st.error(f"{L('Fetch failed','فشل الجلب')}: {e}"); rows=[]
            if rows:
                df=pd.DataFrame(rows).dropna(subset=[period]).sort_values(period,ascending=False).head(25).reset_index(drop=True)
                df.index=df.index+1
                styled=(df.style.format({c:"{:+.1f}%" for c in pcols},na_rep="—").format({"Price":"${:.2f}"}).map(clr,subset=pcols))
                st.dataframe(styled,use_container_width=True,height=560)
                tp=df.iloc[0]; st.success(f"🔥 {L('Top gainer','أعلى رابح')} ({period.replace(' %','')}): **{tp['Symbol']}**  {tp[period]:+.1f}%")
            else: st.error(L("No data fetched. Try again shortly.","لم تُجلب بيانات. حاول لاحقاً."))

# ───────────────── Alerts ─────────────────
with t5:
    st.subheader(L("🔔 Price Alerts","🔔 تنبيهات الأسعار"))
    st.caption(L("Alerts are checked every time this page refreshes. Keep the app open, or enable auto-refresh below. "
                 "Rules are saved to disk and survive restarts.",
                 "تُفحص التنبيهات عند كل تحديث للصفحة. أبقِ التطبيق مفتوحاً أو فعّل التحديث التلقائي أدناه. "
                 "القواعد تُحفظ على القرص وتبقى بعد إعادة التشغيل."))

    # create a rule
    with st.container(border=True):
        st.markdown("**"+L("Create alert","إنشاء تنبيه")+"**")
        a1,a2,a3=st.columns([1,1.3,1])
        a_sym=a1.text_input(L("Symbol","الرمز"),value="AAPL",key="al_sym").upper().strip()
        cond_map={L("Price ≥","السعر ≥"):"price_above", L("Price ≤","السعر ≤"):"price_below",
                  L("Change% ≥","التغيّر٪ ≥"):"chg_above", L("Change% ≤","التغيّر٪ ≤"):"chg_below"}
        a_cond_lbl=a2.selectbox(L("Condition","الشرط"),list(cond_map.keys()),key="al_cond")
        a_val=a3.number_input(L("Value","القيمة"),value=200.0,step=0.5,key="al_val")
        a_note=st.text_input(L("Note (optional)","ملاحظة (اختياري)"),key="al_note",placeholder=L("e.g. breakout entry","مثال: دخول كسر"))
        if st.button(L("➕ Add alert","➕ أضف التنبيه"),key="al_add") and a_sym:
            rid=str(int(_dt.datetime.now().timestamp()*1000))
            lbl=f"{a_cond_lbl} {a_val:g}"+(f" — {a_note}" if a_note else "")
            st.session_state["alerts"].append({"id":rid,"symbol":a_sym,"cond":cond_map[a_cond_lbl],
                                               "value":float(a_val),"note":a_note,"_label":lbl,
                                               "active":True,"triggered_at":None})
            save_state(alerts=st.session_state["alerts"])
            st.success(L(f"Alert added for {a_sym}.",f"أُضيف تنبيه لـ {a_sym}.")); st.rerun()

    # controls
    cR1,cR2=st.columns([1,1])
    if cR1.button(L("🔄 Check now","🔄 افحص الآن"),key="al_check"): st.rerun()
    refresh=cR2.selectbox(L("Auto-refresh","تحديث تلقائي"),["Off","30s","60s","120s"],key="al_refresh")
    if refresh!="Off":
        import streamlit.components.v1 as _cmp
        _ms={"30s":30000,"60s":60000,"120s":120000}[refresh]
        _cmp.html(f"<script>setTimeout(()=>window.parent.location.reload(), {_ms});</script>",height=0)

    # active rules
    active=[a for a in st.session_state["alerts"] if not a.get("triggered_at")]
    st.markdown("**"+L("Active alerts","التنبيهات النشطة")+f"** ({len(active)})")
    if active:
        for a in active:
            q=_tape_q.get(a["symbol"]); now_px=f"${q['price']:,.2f}" if q else "—"
            c1,c2=st.columns([6,1])
            c1.markdown(f"**{a['symbol']}** · {a.get('_label','')}  \n"
                        f"<span style='color:#64748b;font-size:12px'>{L('now','الآن')}: {now_px}</span>",unsafe_allow_html=True)
            if c2.button(L("Delete","حذف"),key="del_"+a["id"]):
                st.session_state["alerts"]=[x for x in st.session_state["alerts"] if x["id"]!=a["id"]]
                save_state(alerts=st.session_state["alerts"]); st.rerun()
    else:
        st.caption(L("No active alerts. Create one above.","لا تنبيهات نشطة. أنشئ واحداً بالأعلى."))

    # triggered log
    log=st.session_state.get("alert_log",[])
    if log:
        st.markdown("**"+L("🔴 Triggered","🔴 تنبيهات أُطلقت")+f"** ({len(log)})")
        for e in log[:15]:
            st.markdown(f"<div style='padding:7px 0;border-bottom:1px solid {LINE}'>"
                        f"{e['text']} <span style='color:#64748b;font-size:12px'>· {e['when']}</span></div>",unsafe_allow_html=True)
        if st.button(L("Clear triggered + re-arm all","مسح المُطلَقة وإعادة التسليح"),key="al_clear"):
            for a in st.session_state["alerts"]: a["triggered_at"]=None; a.pop("trigger_price",None)
            st.session_state["alert_log"]=[]
            save_state(alerts=st.session_state["alerts"],log=[]); st.rerun()

    # telegram (optional real phone push)
    with st.expander(L("📲 Telegram push (optional)","📲 إشعار تيليجرام (اختياري)")):
        st.caption(L("Get alerts on your phone. Create a bot via @BotFather, get its token, then your chat id via @userinfobot.",
                     "استقبل التنبيهات على جوّالك. أنشئ بوتاً عبر @BotFather واحصل على التوكن، ثم رقم محادثتك عبر @userinfobot."))
        tg=st.session_state.get("tg") or {}
        tg_tok=st.text_input("Bot Token",value=tg.get("token",""),type="password",key="tg_tok")
        tg_chat=st.text_input("Chat ID",value=tg.get("chat",""),key="tg_chat")
        bb1,bb2=st.columns(2)
        if bb1.button(L("Save","حفظ"),key="tg_save"):
            st.session_state["tg"]={"token":tg_tok.strip(),"chat":tg_chat.strip()}; st.success(L("Saved.","حُفظ."))
        if bb2.button(L("Send test","إرسال تجربة"),key="tg_test"):
            ok=send_telegram(tg_tok.strip(),tg_chat.strip(),"✅ Equity Intelligence test alert")
            st.success(L("Sent!","أُرسل!")) if ok else st.error(L("Failed — check token/chat id.","فشل — تحقّق من التوكن/المعرّف."))

# ───────────────── Future Outlook (scenario valuation) ─────────────────
with t6:
    st.subheader(L("🔮 Future Outlook — Scenario Valuation","🔮 النظرة المستقبلية — تقييم بالسيناريوهات"))
    st.caption(L("Not a price prediction — a fair-value range under conservative / base / optimistic assumptions. "
                 "Growth is sourced from analyst consensus where available (labeled), and every assumption is adjustable.",
                 "ليس تنبؤاً بالسعر — بل نطاق قيمة عادلة وفق افتراضات متحفّظة / أساسية / متفائلة. "
                 "النمو مأخوذ من إجماع المحلّلين حيثما توفّر (مع تسمية المصدر)، وكل افتراض قابل للتعديل."))
    ov_sym=st.text_input(L("Ticker","الرمز"),value="AAPL",key="ov_sym").upper().strip()
    if st.button(L("▶ Build Outlook","▶ ابنِ النظرة"),key="ov_run") and ov_sym:
        _set_keys(finnhub_key, alpaca_key, alpaca_sec)
        with st.spinner(L("Fetching analyst data…","جلب بيانات المحلّلين…")):
            ff=ta.forward_fundamentals(ov_sym)
        if not ff.get("ok") or not ff.get("price"):
            st.error(L("Forward data unavailable for this ticker.","المعطيات المستقبلية غير متوفّرة لهذا الرمز."))
        else:
            st.session_state["ff"]=ff; st.session_state["ff_sym"]=ov_sym
            # reset assumption widgets so they re-default to THIS stock (avoid stale values from a prior ticker)
            for _k in ("ov_years","ov_spread","ov_mult","ov_gc","ov_gb","ov_go","ov_pc","ov_pb","ov_po","ov_sec"):
                st.session_state.pop(_k, None)
    ff=st.session_state.get("ff") if st.session_state.get("ff_sym")==ov_sym else None
    if ff:
        price=float(ff["price"]); eps=ff.get("eps"); rev=ff.get("revenue"); shares=ff.get("shares")
        use_eps = isinstance(eps,(int,float)) and eps>0 and isinstance(ff.get("exit_multiple"),(int,float))
        method = L("Earnings (P/E)","الأرباح (P/E)") if use_eps else L("Revenue (P/S)","الإيراد (P/S)")
        base_g=float(ff["base_growth"])
        tgt=ff.get("target")
        # top row
        i1,i2,i3,i4=st.columns(4)
        i1.metric(L("Current price","السعر الحالي"),f"${price:.2f}")
        i2.metric(L("Base growth","النمو الأساسي"),f"{base_g*100:.1f}%")
        if isinstance(tgt,(int,float)) and price>0:
            i3.metric(L("12-mo consensus","هدف الإجماع ١٢ش"),f"${tgt:.2f}",f"{(tgt/price-1)*100:+.1f}%")
        else: i3.metric(L("12-mo consensus","هدف الإجماع ١٢ش"),"—")
        i4.metric(L("Valuation method","طريقة التقييم"),method)
        # valuation context: only show sane multiples
        petr=ff.get("pe_trail"); pefw=ff.get("pe_fwd")
        vc_bits=[]
        if isinstance(petr,(int,float)) and 0<petr<200: vc_bits.append(L(f"Trailing P/E {petr:.1f}",f"P/E حالي {petr:.1f}"))
        if isinstance(pefw,(int,float)) and 0<pefw<200: vc_bits.append(L(f"Forward P/E {pefw:.1f}",f"P/E آجل {pefw:.1f}"))
        st.caption(L(f"Growth source: {ff['growth_src']}",f"مصدر النمو: {ff['growth_src']}")
                   + (f" · {ff['n_analysts']} " + L("analysts","محلّلاً") if ff.get('n_analysts') else "")
                   + (" · " + " · ".join(vc_bits) if vc_bits else ""))

        with st.expander(L("⚙️ Assumptions (adjustable)","⚙️ الافتراضات (قابلة للتعديل)"),expanded=False):
            a1,a2,a3=st.columns(3)
            years=a1.slider(L("Horizon (years)","الأفق (سنوات)"),1,10,5,key="ov_years")
            spread=a2.slider(L("Scenario spread (±pp)","فارق السيناريو (±نقطة)"),2,15,6,key="ov_spread")/100
            # sane exit multiple: cap P/E to [5,60], P/S to [0.5,25] (rich multiples compress over time)
            if use_eps:
                raw_m=ff.get("exit_multiple") or ff.get("pe_trail") or 20
                default_mult=max(5.0,min(60.0,float(raw_m)))
            else:
                raw_m=ff.get("ps") or 3.0
                default_mult=max(0.5,min(25.0,float(raw_m)))
            exit_mult=a3.number_input(L("Exit multiple","مضاعف الخروج"),value=round(default_mult,1),step=0.5,key="ov_mult")
            b1,b2,b3=st.columns(3)
            g_cons=b1.number_input(L("Conservative growth %","نمو متحفّظ٪"),value=round((base_g-spread)*100,1),step=0.5,key="ov_gc")/100
            g_base=b2.number_input(L("Base growth %","نمو أساسي٪"),value=round(base_g*100,1),step=0.5,key="ov_gb")/100
            g_opt=b3.number_input(L("Optimistic growth %","نمو متفائل٪"),value=round((base_g+spread)*100,1),step=0.5,key="ov_go")/100
            p1,p2,p3=st.columns(3)
            pr_cons=p1.number_input(L("Conservative prob %","احتمال متحفّظ٪"),value=25,step=5,key="ov_pc")
            pr_base=p2.number_input(L("Base prob %","احتمال أساسي٪"),value=50,step=5,key="ov_pb")
            pr_opt=p3.number_input(L("Optimistic prob %","احتمال متفائل٪"),value=25,step=5,key="ov_po")
            sector_cagr=st.number_input(L("Sector growth CAGR % (reference)","نمو القطاع CAGR٪ (مرجعي)"),value=0.0,step=0.5,key="ov_sec")

        def _fv(g):
            if use_eps: return eps*((1+g)**years)*exit_mult
            if isinstance(rev,(int,float)) and isinstance(shares,(int,float)) and shares>0:
                return (rev*((1+g)**years)*exit_mult)/shares
            return None
        scen=[(L("Conservative","متحفّظ"),g_cons,pr_cons,DN),(L("Base","أساسي"),g_base,pr_base,ACC),(L("Optimistic","متفائل"),g_opt,pr_opt,UP)]
        results=[(nm,g,pp,clr,_fv(g)) for nm,g,pp,clr in scen]
        if any(r[4] is None or r[4]<=0 for r in results):
            st.error(L("Insufficient data to project (need positive EPS+multiple, or revenue+shares).",
                       "بيانات غير كافية للإسقاط (تحتاج ربح موجب+مضاعف، أو إيراد+أسهم)."))
        else:
            # scenario cards: fair value + upside% + annual return
            cc=st.columns(3)
            for col,(nm,g,pp,clr,fv) in zip(cc,results):
                up=(fv/price-1)*100; ann=((fv/price)**(1/years)-1)*100
                col.markdown(f"<div style='border:1px solid {LINE};border-radius:12px;padding:12px;text-align:center'>"
                             f"<div style='color:{MUTED};font-size:12px;font-weight:700'>{nm} · "
                             f"<span dir='ltr'>{g*100:+.1f}%/{L('yr','سنة')}</span></div>"
                             f"<div style='color:{clr};font-size:24px;font-weight:800;margin:4px 0'>${fv:.2f}</div>"
                             f"<div style='color:{clr};font-size:13px;font-weight:700'><span dir='ltr'>{up:+.0f}%</span> {L('total','إجمالي')}</div>"
                             f"<div style='color:{MUTED};font-size:12px'><span dir='ltr'>{ann:+.1f}%/{L('yr','سنة')}</span></div></div>",
                             unsafe_allow_html=True)
            # probability-weighted expected value + verdict
            ptot=(pr_cons+pr_base+pr_opt) or 1
            wfv=sum(pp*fv for _,_,pp,_,fv in results)/ptot
            w_up=(wfv/price-1)*100; w_ann=((wfv/price)**(1/years)-1)*100
            implausible = (w_ann>30) or (wfv>price*3.5) or (wfv<price*0.3)
            if implausible:
                vk_lbl,vk_clr=L("⚠️ Result looks unrealistic — review the exit multiple & growth","⚠️ النتيجة غير واقعية — راجع مضاعف الخروج والنمو"),DN
            elif w_ann>=12: vk_lbl,vk_clr=L("Undervalued — attractive","مقوّم بأقل من قيمته — جذّاب"),UP
            elif w_ann>=4: vk_lbl,vk_clr=L("Fairly valued","عادل التقييم"),"#d97706"
            else: vk_lbl,vk_clr=L("Expensive — limited upside","مكلّف — صعود محدود"),DN
            st.markdown(f"<div style='border:1.5px solid {vk_clr};border-radius:12px;padding:14px 16px;margin-top:10px;background:rgba(0,0,0,.01)'>"
                        f"<div style='font-size:16px;font-weight:800;color:{vk_clr}'>⚖️ {vk_lbl}</div>"
                        f"<div style='font-size:13.5px;color:{TEXT};margin-top:4px'>"
                        f"{L('Probability-weighted fair value','القيمة العادلة المرجّحة بالاحتمالات')}: <b>${wfv:.2f}</b> "
                        f"{L('vs current','مقابل الحالي')} ${price:.2f} → <b style='color:{vk_clr}'>{w_up:+.0f}%</b> "
                        f"({w_ann:+.1f}%/{L('yr','سنة')})</div></div>",unsafe_allow_html=True)
            if implausible:
                st.warning(L("The fair value is implausibly far from the price — usually a too-high exit multiple (rich P/S on an unprofitable stock) or an extreme growth input. Open Assumptions and set a realistic exit multiple; don't trust this verdict as-is.",
                             "القيمة العادلة بعيدة جداً عن السعر — غالباً مضاعف خروج مرتفع (P/S مرتفع لسهم غير ربحي) أو نمو مبالغ. افتح الافتراضات وضع مضاعفاً واقعياً؛ ولا تثق بهذا الحكم كما هو."))
            # high-growth realism note (a sustained 5-yr rate above ~30% is very rare)
            if g_base>0.30:
                st.caption(L(f"Note: a {g_base*100:.0f}%/yr base growth sustained for {years} years is very rare — analyst figures often reflect a near-term rate, not a durable {years}-yr rate. Consider lowering it.",
                             f"ملاحظة: نمو {g_base*100:.0f}%/سنة مستمرّ {years} سنوات نادر جداً — أرقام المحلّلين غالباً قصيرة المدى لا معدّلاً مستداماً {years} سنوات. يُنصح بخفضه."))
            # reverse: growth the market already prices in
            denom = (eps*exit_mult) if use_eps else ((rev*exit_mult)/shares if (isinstance(rev,(int,float)) and shares) else None)
            if denom and denom>0:
                g_impl=(price/denom)**(1/years)-1
                if implausible:
                    # don't draw a cheap/expensive conclusion on broken inputs — just state the market-implied figure
                    st.caption(L(f"🔁 Reverse check: at today's price the market is pricing in ~{g_impl*100:.1f}%/yr growth at this multiple. "
                                 f"Fix the assumptions above before reading this as cheap/expensive.",
                                 f"🔁 فحص عكسي: السعر الحالي يسعّر نمواً ~{g_impl*100:.1f}%/سنة عند هذا المضاعف. "
                                 f"صحّح الافتراضات أعلاه قبل قراءته كأرخص/أغلى."))
                else:
                    cheaper = g_base>g_impl
                    st.caption(L(f"🔁 Reverse check: at today's price the market is pricing in ~{g_impl*100:.1f}%/yr growth. "
                                 f"Your base is {g_base*100:.1f}% → the stock looks {'CHEAP vs your view' if cheaper else 'EXPENSIVE vs your view'}.",
                                 f"🔁 فحص عكسي: السعر الحالي يسعّر نمواً ~{g_impl*100:.1f}%/سنة. "
                                 f"نموك الأساسي {g_base*100:.1f}% → السهم يبدو {'أرخص من توقّعك' if cheaper else 'أغلى من توقّعك'}."))
            # scenario table
            st.markdown(f"**{L('Scenario detail','تفصيل السيناريوهات')}**")
            trows=[]
            for nm,g,pp,clr,fv in results:
                trows.append({L("Scenario","السيناريو"):nm,L("Growth/yr","نمو/سنة"):f"{g*100:.1f}%",
                              L("Prob","احتمال"):f"{pp/ptot*100:.0f}%",L("Fair value","قيمة عادلة"):f"${fv:.2f}",
                              L("Upside","الصعود"):f"{(fv/price-1)*100:+.0f}%",L("Annual","سنوي"):f"{((fv/price)**(1/years)-1)*100:+.1f}%"})
            st.dataframe(pd.DataFrame(trows),hide_index=True,use_container_width=True)
            # paths chart
            import plotly.graph_objects as _go
            yrs_axis=list(range(0,years+1)); pf=_go.Figure()
            for nm,g,pp,clr,fv in results:
                if use_eps: path=[eps*((1+g)**y)*exit_mult for y in yrs_axis]
                else: path=[(rev*((1+g)**y)*exit_mult)/shares for y in yrs_axis]
                pf.add_trace(_go.Scatter(x=yrs_axis,y=path,mode="lines+markers",name=nm,line=dict(color=clr,width=2)))
            pf.add_hline(y=price,line=dict(color=MUTED,width=1.2,dash="dash"),
                         annotation_text=L("today","اليوم"),annotation_position="top left")
            if isinstance(tgt,(int,float)):
                pf.add_trace(_go.Scatter(x=[1],y=[tgt],mode="markers",name=L("12-mo target","هدف ١٢ش"),
                                         marker=dict(color="#d97706",size=10,symbol="diamond")))
            pf.update_layout(template="plotly_white",height=300,margin=dict(l=8,r=8,t=28,b=8),
                             paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                             font=dict(family="Inter",color="#334155"),
                             title=dict(text=L(f"Fair-value paths · {ov_sym}",f"مسارات القيمة العادلة · {ov_sym}"),x=0.01,font=dict(size=14)),
                             legend=dict(orientation="h",y=-0.18))
            pf.update_xaxes(title=L("Years from now","سنوات من الآن"),gridcolor=LINE)
            pf.update_yaxes(title=L("Fair value / share","القيمة العادلة/سهم"),gridcolor=LINE)
            st.plotly_chart(pf,use_container_width=True)
            if sector_cagr!=0:
                st.caption(L(f"Reference: sector growth CAGR {sector_cagr:.1f}% vs your base {g_base*100:.1f}%.",
                             f"مرجع: نمو القطاع CAGR {sector_cagr:.1f}% مقابل نموك الأساسي {g_base*100:.1f}%."))
            st.caption(L("⚠️ Scenarios, not a prediction. Output quality depends entirely on the assumptions. "
                         "Free analyst data is approximate — licensed estimate feeds (e.g. Intrinio/Zacks) make this far more rigorous.",
                         "⚠️ سيناريوهات لا تنبؤ. جودة النتيجة تعتمد كلياً على الافتراضات. "
                         "بيانات المحلّلين المجانية تقريبية — وتقديرات مرخّصة (مثل Intrinio/Zacks) تجعلها أدقّ بكثير."))

st.divider()
st.caption(L("⚠️ Educational analysis, not licensed investment advice. Free-source data may be delayed ~15 minutes.",
             "⚠️ تحليل تعليمي وليس نصيحة استثمارية مرخّصة. بيانات المصادر المجانية قد تتأخّر ~15 دقيقة."))
