"""
╔══════════════════════════════════════════════════════════════════╗
║     SULTAN TECHNICAL ANALYST v2.0 — محلل فني احترافي شامل      ║
║  شموع يابانية | نماذج شارت | داو | Wyckoff | Ichimoku           ║
║  مسح 200 سهم | أطر زمنية متعددة | Telegram | إحصاء تاريخي      ║
╚══════════════════════════════════════════════════════════════════╝
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import box
import time
import json
import urllib.request
import urllib.parse
import concurrent.futures
import os
import sys
import contextlib
import io

ET      = ZoneInfo("America/New_York")
console = Console()

# ══════════════════════════════════════════════════════════════
#  اللغة — زر تبديل عربي/إنجليزي (يُحفظ بين الجلسات)
# ══════════════════════════════════════════════════════════════
_LANG_FILE = os.path.join(os.path.expanduser("~"), ".ta_scanner_lang")

def _load_lang():
    try:
        with open(_LANG_FILE) as f:
            v = f.read().strip().lower()
            return v if v in ("ar", "en") else "ar"
    except Exception:
        return "ar"

LANG = _load_lang()

def set_lang(v):
    global LANG
    LANG = "en" if str(v).lower().startswith("en") else "ar"
    try:
        with open(_LANG_FILE, "w") as f: f.write(LANG)
    except Exception:
        pass
    return LANG

def T(ar, en):
    """يرجع النص بالعربية أو الإنجليزية حسب اللغة الحالية"""
    return en if LANG == "en" else ar

# ══════════════════════════════════════════════════════════════
#  إعدادات — عدّل هنا فقط
# ══════════════════════════════════════════════════════════════
TELEGRAM_TOKEN = ""        # ← ضع توكن البوت هنا
TELEGRAM_CHAT  = ""        # ← ضع Chat ID هنا

# ── مصدر السعر اللحظي (اختياري) — ضع مفتاحاً واحداً يكفي ──
#   Finnhub:  https://finnhub.io  (مجاني — أنشئ حساباً وانسخ المفتاح)
#   Alpaca:   https://alpaca.markets  (مجاني — لحظي IEX)
FINNHUB_KEY   = ""         # ← مفتاح Finnhub المجاني (يعطي سعراً لحظياً)
ALPACA_KEY    = ""         # ← مفتاح Alpaca (اختياري)
ALPACA_SECRET = ""         # ← سر Alpaca (اختياري)
MIN_SCAN_SCORE = 6         # الحد الأدنى للإشارة في المسح
SCAN_WORKERS   = 8         # عدد الأسهم المحللة بالتوازي

# قائمة المسح — أفضل 200 سهم أمريكي نشاطاً
SCAN_UNIVERSE = [
    "AAPL","MSFT","NVDA","TSLA","AMZN","META","GOOGL","AMD","PLTR","MSTR",
    "SMCI","ARM","AVGO","ORCL","CRM","NFLX","UBER","LYFT","COIN","HOOD",
    "SOFI","RIVN","LCID","NIO","XPEV","LI","BABA","JD","PDD","KWEB",
    "SPY","QQQ","IWM","XLK","XLF","XLE","XLV","ARKK","SOXL","TQQQ",
    "AAON","ACN","ADBE","ADI","ADP","ADSK","AEP","AFL","AIG","AMAT",
    "AMT","AMGN","ANSS","AON","APA","APD","APH","APTV","ARE","ATO",
    "ATVI","AVB","AVGO","AXP","AZO","BA","BAC","BALL","BAX","BBY",
    "BDX","BEN","BK","BKNG","BMY","BR","BSX","BX","C","CAG",
    "CAH","CARR","CAT","CB","CBOE","CBRE","CCI","CCL","CDNS","CDW",
    "CE","CEG","CF","CFG","CHD","CHRW","CHTR","CI","CINF","CL",
    "CLX","CMA","CMCSA","CME","CMG","CMI","CMS","CNC","CNP","COF",
    "COO","COP","COST","CPB","CPRT","CPT","CSX","CTAS","CTLT","CTSH",
    "CTVA","CVS","CVX","D","DAL","DD","DE","DFS","DG","DGX",
    "DHI","DHR","DIS","DLTR","DOV","DOW","DPZ","DRI","DTE","DUK",
    "DVA","DVN","DXC","DXCM","EA","EBAY","ECL","ED","EFX","EIX",
    "EL","EMN","EMR","ENPH","EOG","EPAM","EQIX","EQR","EQT","ES",
    "ESS","ETN","ETR","EVRG","EW","EXC","EXPD","EXPE","EXR","F",
    "FANG","FAST","FCX","FDS","FDX","FE","FFIV","FIS","FISV","FLT",
    "FMC","FOX","FOXA","FRC","FRT","FTNT","FTV","GD","GE","GEHC",
    "GEN","GILD","GIS","GL","GLW","GM","GNRC","GPC","GPN","GPS",
    "GRMN","GS","GWW","HAL","HAS","HBAN","HCA","HD","HES","HIG",
    "HII","HLT","HOLX","HON","HPE","HPQ","HRL","HSIC","HST","HSY",
    "HUM","IBM","ICE","IDXX","IEX","IFF","ILMN","INCY","INTC","INTU",
    "INVH","IP","IPG","IQV","IR","IRM","ISRG","IT","ITW","IVZ",
]

# إحصاءات الأداء التاريخي للنماذج (مبنية على أبحاث Thomas Bulkowski)
PATTERN_STATS = {
    "Bullish Engulfing":    {"win_rate": 63, "avg_gain": 8.3,  "avg_loss": 3.1, "trades": 1200},
    "Morning Star":         {"win_rate": 78, "avg_gain": 9.5,  "avg_loss": 3.8, "trades": 890},
    "Hammer":               {"win_rate": 61, "avg_gain": 7.1,  "avg_loss": 3.5, "trades": 2100},
    "Three White Soldiers": {"win_rate": 83, "avg_gain": 11.2, "avg_loss": 4.2, "trades": 540},
    "Bullish Harami":       {"win_rate": 54, "avg_gain": 5.8,  "avg_loss": 3.9, "trades": 1800},
    "Shooting Star":        {"win_rate": 59, "avg_gain": 7.4,  "avg_loss": 3.3, "trades": 1600},
    "Bearish Engulfing":    {"win_rate": 66, "avg_gain": 8.9,  "avg_loss": 3.4, "trades": 1150},
    "Evening Star":         {"win_rate": 72, "avg_gain": 9.1,  "avg_loss": 3.7, "trades": 760},
    "Three Black Crows":    {"win_rate": 79, "avg_gain": 10.8, "avg_loss": 4.0, "trades": 480},
    "Doji":                 {"win_rate": 48, "avg_gain": 4.2,  "avg_loss": 3.8, "trades": 3200},
    "W Double Bottom":      {"win_rate": 71, "avg_gain": 13.5, "avg_loss": 5.1, "trades": 980},
    "M Double Top":         {"win_rate": 69, "avg_gain": 12.8, "avg_loss": 4.9, "trades": 870},
    "Bull Flag":            {"win_rate": 67, "avg_gain": 10.2, "avg_loss": 3.8, "trades": 1400},
    "Cup & Handle":         {"win_rate": 65, "avg_gain": 14.5, "avg_loss": 5.2, "trades": 620},
    "Triangle Breakout":    {"win_rate": 62, "avg_gain": 9.7,  "avg_loss": 4.1, "trades": 1100},
}

# ══════════════════════════════════════════════════════════════
#  Telegram
# ══════════════════════════════════════════════════════════════

def send_telegram(msg: str):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT:
        return
    try:
        url  = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        data = urllib.parse.urlencode({
            "chat_id":    TELEGRAM_CHAT,
            "text":       msg,
            "parse_mode": "HTML",
        }).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        urllib.request.urlopen(req, timeout=5)
    except:
        pass

# ══════════════════════════════════════════════════════════════
#  أدوات التحليل الفني
# ══════════════════════════════════════════════════════════════

def _rsi(closes, period=14):
    s = pd.Series(closes)
    d = s.diff()
    g = d.clip(lower=0).rolling(period).mean()
    l = (-d.clip(upper=0)).rolling(period).mean()
    rs = g / l.replace(0, np.nan)
    v = 100 - 100/(1+rs.iloc[-1])
    return float(v) if not np.isnan(v) else 50.0

def _ema(closes, p):
    return float(pd.Series(closes).ewm(span=p, adjust=False).mean().iloc[-1])

def _atr(h, l, c, p=14):
    hh=pd.Series(h); ll=pd.Series(l); cc=pd.Series(c)
    tr=pd.concat([hh-ll,(hh-cc.shift()).abs(),(ll-cc.shift()).abs()],axis=1).max(axis=1)
    v = tr.rolling(p).mean().iloc[-1]
    return float(v) if not np.isnan(v) else float((hh-ll).mean())

def _macd(closes):
    s=pd.Series(closes)
    m=s.ewm(span=12).mean()-s.ewm(span=26).mean()
    sig=m.ewm(span=9).mean()
    return float(m.iloc[-1]), float(sig.iloc[-1]), float((m-sig).iloc[-1])

def _vwap(h,l,c,v):
    vv=np.where(np.array(v)<=0,1,v)
    tp=(np.array(h)+np.array(l)+np.array(c))/3
    return float(np.cumsum(tp*vv)[-1]/np.cumsum(vv)[-1])

def _bb(closes,p=20,std=2):
    s=pd.Series(closes)
    m=s.rolling(p).mean(); sd=s.rolling(p).std()
    return float(m.iloc[-1]),float((m+std*sd).iloc[-1]),float((m-std*sd).iloc[-1])

# ══════════════════════════════════════════════════════════════
#  نماذج الشموع اليابانية
# ══════════════════════════════════════════════════════════════

def detect_candles(o,h,l,c):
    patterns=[]
    if len(o)<3: return patterns
    o1,h1,l1,c1=o[-1],h[-1],l[-1],c[-1]
    o2,h2,l2,c2=o[-2],h[-2],l[-2],c[-2]
    o3,h3,l3,c3=o[-3],h[-3],l[-3],c[-3]
    body1=abs(c1-o1); body2=abs(c2-o2); body3=abs(c3-o3)
    r1=h1-l1 if h1>l1 else 0.0001; r2=h2-l2 if h2>l2 else 0.0001
    uw1=h1-max(o1,c1); lw1=min(o1,c1)-l1
    uw2=h2-max(o2,c2); lw2=min(o2,c2)-l2
    bull1=c1>o1; bear1=c1<o1; bull2=c2>o2; bear2=c2<o2

    if lw1>=body1*2 and uw1<=body1*0.5 and body1<r1*0.45:
        patterns.append(("Hammer","BULLISH",4,"ذيل سفلي طويل — انعكاس صاعد محتمل"))
    if uw1>=body1*2 and lw1<=body1*0.5 and body1<r1*0.45:
        patterns.append(("Shooting Star","BEARISH",4,"ذيل علوي طويل — انعكاس هابط محتمل"))
    if bear2 and bull1 and o1<=c2 and c1>=o2 and body1>body2:
        patterns.append(("Bullish Engulfing","BULLISH",5,"ابتلاع صاعد — إشارة انعكاس قوية جداً"))
    if bull2 and bear1 and o1>=c2 and c1<=o2 and body1>body2:
        patterns.append(("Bearish Engulfing","BEARISH",5,"ابتلاع هابط — إشارة انعكاس هابطة قوية"))
    if bear2 and body2>r2*0.5 and abs(c[-2]-o[-2])<r2*0.3 and bull1 and c1>(o2+c2)/2:
        patterns.append(("Morning Star","BULLISH",5,"نجمة الصباح — انعكاس صاعد قوي"))
    if bull2 and body2>r2*0.5 and abs(c[-2]-o[-2])<r2*0.3 and bear1 and c1<(o2+c2)/2:
        patterns.append(("Evening Star","BEARISH",5,"نجمة المساء — انعكاس هابط قوي"))
    if bear2 and bull1 and o1>=c2 and c1<=o2 and body1<body2*0.6:
        patterns.append(("Bullish Harami","BULLISH",3,"هارامي صاعد — انعكاس محتمل"))
    if bull1 and bull2 and c3>o3 and c1>c2>c3 and o1>o2>o3:
        patterns.append(("Three White Soldiers","BULLISH",5,"ثلاثة جنود بيض — استمرار صاعد قوي"))
    if bear1 and bear2 and c3<o3 and c1<c2<c3 and o1<o2<o3:
        patterns.append(("Three Black Crows","BEARISH",5,"ثلاثة غربان سوداء — استمرار هابط"))
    if body1<r1*0.1 and r1>0:
        patterns.append(("Doji","NEUTRAL",2,"تردد السوق — انتظر تأكيد"))
    return patterns

# ══════════════════════════════════════════════════════════════
#  نماذج الشارت
# ══════════════════════════════════════════════════════════════

def detect_chart_patterns(h,l,c,v):
    patterns=[]
    if len(c)<20: return patterns
    ha=np.array(h); la=np.array(l); ca=np.array(c)

    # Double Bottom
    if len(ca)>=20:
        l20=la[-20:]; i1=np.argmin(l20[:10]); i2=np.argmin(l20[10:])+10
        lo1=l20[i1]; lo2=l20[i2]
        if abs(lo1-lo2)/max(lo1,0.001)<0.025 and max(l20[i1:i2])>lo1*1.03:
            neck=max(ca[-20:-10])
            if ca[-1]>neck:
                tp=neck+(neck-lo1)
                patterns.append(("W Double Bottom","BULLISH",5,f"قاع مزدوج ✅ كسر النكلاين",neck,lo1*0.98,tp))

    # Double Top
    if len(ca)>=20:
        h20=ha[-20:]; i1=np.argmax(h20[:10]); i2=np.argmax(h20[10:])+10
        hi1=h20[i1]; hi2=h20[i2]
        if abs(hi1-hi2)/max(hi1,0.001)<0.025 and min(h20[i1:i2])<hi1*0.97:
            neck=min(ca[-20:-10])
            if ca[-1]<neck:
                tp=neck-(hi1-neck)
                patterns.append(("M Double Top","BEARISH",5,f"قمة مزدوجة ✅ كسر النكلاين",neck,hi1*1.02,tp))

    # Bull Flag
    if len(ca)>=15:
        pole_s=ca[-15]; pole_e=max(ca[-10:-5]); flag_lo=min(ca[-5:])
        if (pole_e-pole_s)/max(pole_s,0.001)>0.05 and (pole_e-flag_lo)/max(pole_e,0.001)<0.05:
            if ca[-1]>flag_lo*1.005:
                tp=ca[-1]+(pole_e-pole_s)
                patterns.append(("Bull Flag","BULLISH",4,f"راية صاعدة ✅",ca[-1],flag_lo*0.98,tp))

    # Cup & Handle
    if len(ca)>=30:
        cl=max(ca[-30:-20]); cb=min(ca[-25:-10]); cr=max(ca[-10:-5]); hdl=min(ca[-5:])
        if abs(cl-cr)/max(cl,0.001)<0.04 and (cl-cb)/max(cl,0.001)>0.08 and hdl>cb and ca[-1]>=cr*0.995:
            tp=ca[-1]+(cl-cb)
            patterns.append(("Cup & Handle","BULLISH",5,f"كوب وعروة ✅",ca[-1],hdl*0.97,tp))

    # Triangle
    if len(ca)>=15:
        try:
            res=np.polyval(np.polyfit(range(10),ha[-10:],1),9)
            sup=np.polyval(np.polyfit(range(10),la[-10:],1),9)
            if abs(res-sup)/max(res,0.001)<0.04:
                if ca[-1]>res*1.005:
                    tp=ca[-1]+(res-sup)*2
                    patterns.append(("Triangle Breakout","BULLISH",4,f"كسر مثلث صاعد ✅",ca[-1],sup*0.99,tp))
                elif ca[-1]<sup*0.995:
                    tp=ca[-1]-(res-sup)*2
                    patterns.append(("Triangle Breakdown","BEARISH",4,f"كسر مثلث هابط ✅",ca[-1],res*1.01,tp))
        except: pass

    return patterns

# ══════════════════════════════════════════════════════════════
#  مستويات الدعم والمقاومة
# ══════════════════════════════════════════════════════════════

def find_levels(h,l,c,price):
    ha=np.array(h[-60:]); la=np.array(l[-60:])
    pivots=[]
    for i in range(2,len(ha)-2):
        if ha[i]==max(ha[i-2:i+3]): pivots.append(("R",float(ha[i])))
        if la[i]==min(la[i-2:i+3]): pivots.append(("S",float(la[i])))
    supports    = sorted([p[1] for p in pivots if p[0]=="S" and p[1]<price],reverse=True)[:3]
    resistances = sorted([p[1] for p in pivots if p[0]=="R" and p[1]>price])[:3]
    return supports, resistances


def volume_profile(h, l, c, v, lookback=220, bins=60, va_pct=0.70):
    """
    ملف الحجم عالي الدقة (Volume Profile):
    يوزّع حجم كل شمعة على نطاق سعرها (high→low) بدل تكديسه في نقطة واحدة → دقّة أعلى.
    يُرجع: VPOC (نقطة التحكّم)، VAH/VAL (حدّا منطقة القيمة 70%)، HVN/LVN (عقد عالية/منخفضة الحجم)، والملف الكامل للرسم.
    """
    h = np.asarray(h, float)[-lookback:]; l = np.asarray(l, float)[-lookback:]
    c = np.asarray(c, float)[-lookback:]; v = np.nan_to_num(np.asarray(v, float))[-lookback:]
    n = len(c)
    if n < 20: return None
    lo = float(l.min()); hi = float(h.max())
    if hi <= lo or v.sum() <= 0: return None
    edges = np.linspace(lo, hi, bins + 1); centers = (edges[:-1] + edges[1:]) / 2
    vp = np.zeros(bins)
    for i in range(n):
        bl, bh, vol = l[i], h[i], v[i]
        if vol <= 0: continue
        if bh <= bl:                                   # شمعة بلا مدى → لإغلاقها
            j = min(max(int((c[i] - lo) / (hi - lo) * bins), 0), bins - 1); vp[j] += vol; continue
        j0 = min(max(int((bl - lo) / (hi - lo) * bins), 0), bins - 1)
        j1 = min(max(int((bh - lo) / (hi - lo) * bins), 0), bins - 1)
        span = bh - bl
        for j in range(j0, j1 + 1):                    # توزيع متناسب مع تداخل الشمعة مع كل نطاق
            seg = min(edges[j + 1], bh) - max(edges[j], bl)
            if seg > 0: vp[j] += vol * (seg / span)
    total = vp.sum()
    if total <= 0: return None
    poc_i = int(vp.argmax()); poc = float(centers[poc_i])
    # منطقة القيمة: توسّع من VPOC بإضافة الجار الأعلى حجماً حتى بلوغ 70%
    cum = vp[poc_i]; lo_i = hi_i = poc_i; target = va_pct * total
    while cum < target and (lo_i > 0 or hi_i < bins - 1):
        left  = vp[lo_i - 1] if lo_i > 0 else -1.0
        right = vp[hi_i + 1] if hi_i < bins - 1 else -1.0
        if right >= left: hi_i += 1; cum += vp[hi_i]
        else:             lo_i -= 1; cum += vp[lo_i]
    val = float(centers[lo_i]); vah = float(centers[hi_i])
    # العقد عالية/منخفضة الحجم عبر القمم/القيعان المحلية على ملف مُنعّم
    sm = np.convolve(vp, np.ones(3) / 3, mode="same"); mean = sm.mean(); std = sm.std()
    hvn = []; lvn = []
    for j in range(1, bins - 1):
        if sm[j] >= sm[j - 1] and sm[j] >= sm[j + 1] and sm[j] > mean + 0.5 * std:
            hvn.append({"level": round(float(centers[j]), 2), "pct": round(float(vp[j] / total * 100), 1)})
        if sm[j] <= sm[j - 1] and sm[j] <= sm[j + 1] and sm[j] < mean - 0.3 * std:
            lvn.append({"level": round(float(centers[j]), 2), "pct": round(float(vp[j] / total * 100), 1)})
    hvn = sorted(hvn, key=lambda x: x["pct"], reverse=True)[:5]
    lvn = sorted(lvn, key=lambda x: x["pct"])[:4]
    vmax = vp.max() or 1.0
    profile = [{"level": round(float(centers[j]), 4), "vol": round(float(vp[j] / vmax), 4)} for j in range(bins)]
    return {"poc": round(poc, 2), "vah": round(vah, 2), "val": round(val, 2),
            "hvn": hvn, "lvn": lvn, "profile": profile, "lookback": n, "bins": bins}


def smart_levels(o, h, l, c, v, price, atr=None):
    """
    دعم/مقاومة بأسلوب المكاتب المؤسسية — يدمج عدة مدارس ثم يُجمّع ويرجّح:
      • قمم/قيعان متأرجحة (fractals) بنوافذ متعددة، مرجّحة بالحداثة
      • بروفايل الحجم (مناطق أعلى تداول = حيث تتمركز الأموال المؤسسية)
      • فيبوناتشي لآخر سوينغ
      • نقاط البيفوت الكلاسيكية
      • متوسطات EMA50/200 كدعم/مقاومة ديناميكي
      • الأرقام النفسية المستديرة
    تُجمّع المرشحات في مناطق (clustering)، وتُرجّح بعدد اللمسات + الحجم + التقاء المدارس.
    يرجع: (supports, resistances, sup_zones, res_zones)
    """
    h=np.asarray(h,float); l=np.asarray(l,float); c=np.asarray(c,float); v=np.nan_to_num(np.asarray(v,float))
    n=len(c)
    if n<30 or price<=0:
        s=sorted([x for x in l[-30:] if x<price],reverse=True)[:3]
        r=sorted([x for x in h[-30:] if x>price])[:3]
        return s, r, [], []
    if not atr or atr<=0:
        atr=float(np.mean(h[-14:]-l[-14:])) or price*0.02
    tol=max(atr*0.6, price*0.008)

    cand=[]
    def add(level,w,method):
        if np.isfinite(level) and level>0: cand.append((float(level),float(w),method))

    # 1) قمم/قيعان متأرجحة بنوافذ متعددة (مرجّحة بالحداثة)
    for left,right in ((2,2),(3,3),(5,5)):
        for i in range(left,n-right):
            rec=0.5+0.5*(i/n)
            if h[i]==h[i-left:i+right+1].max(): add(h[i],1.2*rec,"swing")
            if l[i]==l[i-left:i+right+1].min(): add(l[i],1.2*rec,"swing")
    # 2) بروفايل الحجم عالي الدقة: نقطة التحكّم + حدّا منطقة القيمة + العقد عالية الحجم
    _vpf = volume_profile(h, l, c, v, lookback=min(220, n), bins=60)
    if _vpf:
        add(_vpf["poc"], 2.8, "volume")               # VPOC — أقوى مغناطيس سيولة
        add(_vpf["vah"], 1.9, "volume")               # حدّ منطقة القيمة العلوي
        add(_vpf["val"], 1.9, "volume")               # حدّ منطقة القيمة السفلي
        for _nd in _vpf["hvn"]:
            add(_nd["level"], 1.4 + _nd["pct"] / 100 * 3.0, "volume")   # عقد عالية الحجم = دعم/مقاومة قوي
    # 3) فيبوناتشي لآخر سوينغ
    wf=min(120,n); sh=float(h[-wf:].max()); sl=float(l[-wf:].min()); diff=sh-sl
    if diff>0:
        for f in (0.236,0.382,0.5,0.618,0.786): add(sh-diff*f,1.0,"fib")
    # 4) نقاط البيفوت
    pp=(h[-1]+l[-1]+c[-1])/3
    add(2*pp-l[-1],0.9,"pivot"); add(2*pp-h[-1],0.9,"pivot")
    add(pp+(h[-1]-l[-1]),0.8,"pivot"); add(pp-(h[-1]-l[-1]),0.8,"pivot")
    # 5) متوسطات ديناميكية
    def _ema(a,s):
        k=2/(s+1); e=a[0]
        for x in a[1:]: e=x*k+e*(1-k)
        return e
    if n>=50:  add(_ema(c[-50:],50),0.8,"ema50")
    if n>=200: add(_ema(c[-200:],200),1.0,"ema200")
    # 6) أرقام نفسية مستديرة
    step=10**np.floor(np.log10(price)) if price>0 else 1.0; half=step/2
    base=round(price/half)*half
    for m in (-2,-1,0,1,2):
        rn=base+m*half
        if rn>0: add(rn,0.5,"round")

    # تجميع المرشحات في مناطق
    cand.sort(key=lambda x:x[0]); zones=[]
    for lvl,w,method in cand:
        for z in zones:
            if abs(lvl-z["level"])<=tol:
                tot=z["w"]+w; z["level"]=(z["level"]*z["w"]+lvl*w)/tot
                z["w"]=tot; z["methods"].add(method); break
        else:
            zones.append({"level":lvl,"w":w,"methods":{method}})
    for z in zones:
        lo_z=z["level"]-tol; hi_z=z["level"]+tol
        z["touches"]=int(np.sum((l<=hi_z)&(h>=lo_z)))
        z["confluence"]=len(z["methods"])
        z["score"]=z["w"]*(1+0.15*z["touches"])*(1+0.25*(z["confluence"]-1))

    _LABEL={"swing":T("سوينغ","Swing"),"volume":T("حجم","Volume node"),"fib":"Fibonacci",
            "pivot":"Pivot","ema50":"EMA50","ema200":"EMA200","round":T("رقم مستدير","Round #")}
    def pack(z):
        meth=sorted(z["methods"], key=lambda m:0 if m=="volume" else 1)
        return {"level":round(z["level"],2),
                "dist":round((z["level"]-price)/price*100,1),
                "touches":z["touches"],"confluence":z["confluence"],
                "methods":[_LABEL.get(m,m) for m in meth]}
    res_z=sorted([z for z in zones if z["level"]>price*1.003], key=lambda z:z["level"])
    sup_z=sorted([z for z in zones if z["level"]<price*0.997], key=lambda z:z["level"], reverse=True)
    def best(zs):
        near=zs[:8]
        strong=sorted(near,key=lambda z:z["score"],reverse=True)[:4]
        return sorted(strong,key=lambda z:abs(z["level"]-price))
    sup_b=best(sup_z); res_b=best(res_z)
    return ([round(z["level"],2) for z in sup_b],
            [round(z["level"],2) for z in res_b],
            [pack(z) for z in sup_b],
            [pack(z) for z in res_b])

# ══════════════════════════════════════════════════════════════
#  مدارس التحليل
# ══════════════════════════════════════════════════════════════

def wyckoff_phase(c, v, h=None, l=None):
    """تحليل وايكوف معمّق: سياق الاتجاه + سلوك الحجم (جهد/نتيجة) + موضع النطاق."""
    ca = np.array(c, float); va = np.array(v, float)
    n = len(ca)
    if n < 40: return T("غير محدد","N/A"), ""
    look = min(50, n); seg = ca[-look:]
    slope = (seg[-1] - seg[0]) / seg[0] if seg[0] > 0 else 0
    rec = ca[-20:]
    rng = (rec.max() - rec.min()) / rec.mean() if rec.mean() > 0 else 0
    cl = ca[-21:]
    upv = [va[-20 + i] for i in range(20) if cl[i + 1] > cl[i]]
    dnv = [va[-20 + i] for i in range(20) if cl[i + 1] < cl[i]]
    upvol = np.mean(upv) if upv else 0.0; dnvol = np.mean(dnv) if dnv else 0.0
    vol_bias = (upvol - dnvol) / (upvol + dnvol + 1e-9)   # >0 تدفّق شرائي
    in_range = rng < 0.10
    if in_range:
        if slope < -0.03 and vol_bias > 0.05:
            return T("تراكم (Accumulation) 🟢","Accumulation 🟢"), T("نطاق بعد هبوط مع تدفّق شرائي — تجميع محتمل","Range after decline with buying flow")
        if slope > 0.03 and vol_bias < -0.05:
            return T("توزيع (Distribution) 🔴","Distribution 🔴"), T("نطاق بعد صعود مع تدفّق بيعي — توزيع محتمل","Range after advance with selling flow")
        return T("نطاق تداول ⚪","Trading range ⚪"), T("تماسك جانبي — انتظر كسراً مؤكّداً بالحجم","Sideways — await volume-confirmed break")
    if slope > 0.03:
        if vol_bias > 0:
            return T("ترقّي (Markup) 🟢","Markup 🟢"), T("اتجاه صاعد مدعوم بالحجم — صحّي","Up-trend supported by volume")
        return T("ترقّي ضعيف ⚠️","Weak markup ⚠️"), T("صعود بلا تأكيد حجمي — احذر التوزيع","Rising without volume — distribution risk")
    if slope < -0.03:
        if vol_bias < 0:
            return T("هبوط (Markdown) 🔴","Markdown 🔴"), T("اتجاه هابط بضغط بيعي","Down-trend with selling pressure")
        return T("هبوط يتباطأ 🟡","Slowing markdown 🟡"), T("هبوط مع ظهور تدفّق شرائي — راقب التأسيس","Falling but buying flow emerging")
    return T("مرحلة حيادية ⚪","Neutral ⚪"), T("لا مرحلة واضحة","No clear phase")

def _swings(ha, la, k=3):
    """نقاط تأرجح متناوبة (قمم/قيعان) من القيم العليا/الدنيا."""
    n = len(ha); piv = []
    for i in range(k, n - k):
        if ha[i] == max(ha[i-k:i+k+1]): piv.append((i, ha[i], 'H'))
        elif la[i] == min(la[i-k:i+k+1]): piv.append((i, la[i], 'L'))
    alt = []
    for p in piv:
        if alt and alt[-1][2] == p[2]:
            if (p[2]=='H' and p[1]>alt[-1][1]) or (p[2]=='L' and p[1]<alt[-1][1]): alt[-1]=p
        else: alt.append(p)
    return alt

def dow_theory(c, h=None, l=None):
    ca = np.array(c, float); n = len(ca)
    if n < 20: return T("غير محدد","N/A")
    ha = np.array(h, float) if h is not None else ca
    la = np.array(l, float) if l is not None else ca
    alt = _swings(ha, la, 3)
    highs = [p[1] for p in alt if p[2]=='H'][-3:]
    lows  = [p[1] for p in alt if p[2]=='L'][-3:]
    if len(highs) >= 2 and len(lows) >= 2:
        hh = highs[-1] > highs[-2]; hl = lows[-1] > lows[-2]
        if hh and hl:        return T("📈 صاعد — قمم وقيعان صاعدة (HH/HL)","📈 Uptrend — higher highs & lows")
        if (not hh) and (not hl): return T("📉 هابط — قمم وقيعان هابطة (LH/LL)","📉 Downtrend — lower highs & lows")
        return T("↔️ تحوّل — هيكل مختلط","↔️ Transition — mixed structure")
    return T("↔️ عرضي — لا اتجاه واضح","↔️ Sideways — no clear trend")

def ichimoku_signal(c, h, l):
    n = len(c)
    if n < 52: return T("بيانات غير كافية","Insufficient data")
    ca = np.array(c, float); ha = np.array(h, float); la = np.array(l, float)
    tenkan = (ha[-9:].max() + la[-9:].min()) / 2
    kijun  = (ha[-26:].max() + la[-26:].min()) / 2
    j = n - 1 - 26                      # السحابة الحالية تتحدّد قبل ٢٦ شمعة
    if j >= 51:
        sa = ((ha[j-8:j+1].max()+la[j-8:j+1].min())/2 + (ha[j-25:j+1].max()+la[j-25:j+1].min())/2)/2
        sb = (ha[j-51:j+1].max() + la[j-51:j+1].min()) / 2
    else:
        sa = (tenkan + kijun) / 2; sb = (ha[-52:].max() + la[-52:].min()) / 2
    price = ca[-1]; top = max(sa, sb); bot = min(sa, sb)
    green = sa >= sb; tk = "▲" if tenkan > kijun else "▼"
    if price > top:
        return T(f"✅ صاعد — فوق السحابة ({'سحابة صاعدة' if green else 'سحابة هابطة'}، TK {tk})",
                 f"✅ Bullish — above cloud ({'green' if green else 'red'} cloud, TK {tk})")
    if price < bot:
        return T(f"🔴 هابط — تحت السحابة (TK {tk})", f"🔴 Bearish — below cloud (TK {tk})")
    return T(f"⚪ محايد — داخل السحابة (TK {tk})", f"⚪ Neutral — inside cloud (TK {tk})")

def detect_harmonic(h, l, c):
    """كشف نماذج الهارمونيك (XABCD) وفق نسب فيبوناتشي: جارتلي، بات، فراشة، سلطعون، AB=CD."""
    n = len(c)
    if n < 40: return []
    ha = np.array(h, float); la = np.array(l, float)
    alt = _swings(ha, la, 3)
    if len(alt) < 5: return []
    X, A, B, C, D = alt[-5:]
    XA = abs(A[1]-X[1]); AB = abs(B[1]-A[1]); BC = abs(C[1]-B[1]); CD = abs(D[1]-C[1]); AD = abs(D[1]-A[1])
    if min(XA, AB, BC) <= 0: return []
    ab_xa = AB/XA; bc_ab = BC/AB; cd_bc = CD/BC; ad_xa = AD/XA
    bull = D[2] == 'L'                      # النموذج الصاعد يكتمل عند قاع
    def nr(x, t, tol=0.08): return abs(x - t) <= tol
    out = []
    def add(name, ok):
        if not ok: return
        out.append({"name": name, "type": T("هارمونيك","Harmonic"),
                    "dir": "BULLISH" if bull else "BEARISH", "strength": 4,
                    "desc": T(f"اكتمل عند ${D[1]:.2f} — منطقة انعكاس محتملة (PRZ)",
                              f"Completed at ${D[1]:.2f} — potential reversal zone (PRZ)"),
                    "brk": float(D[1]), "target": float(C[1]), "stop": float(X[1])})
    add("Gartley",   nr(ab_xa,0.618,0.06) and 0.382<=bc_ab<=0.886 and nr(ad_xa,0.786,0.07))
    add("Bat",       0.382<=ab_xa<=0.5  and 0.382<=bc_ab<=0.886 and nr(ad_xa,0.886,0.06))
    add("Butterfly", nr(ab_xa,0.786,0.06) and 0.382<=bc_ab<=0.886 and 1.27<=ad_xa<=1.7)
    add("Crab",      0.382<=ab_xa<=0.618 and 0.382<=bc_ab<=0.886 and 1.5<=ad_xa<=1.9)
    add("AB=CD",     nr(cd_bc,1.0,0.12) or nr(cd_bc,1.272,0.12) or nr(cd_bc,1.618,0.15))
    return out[:2]

# ══════════════════════════════════════════════════════════════
#  الأطر الزمنية المتعددة
# ══════════════════════════════════════════════════════════════

def multi_timeframe(sym: str):
    """تحليل 1h + 4h + يومي — يرجع اتجاه كل إطار"""
    results = {}
    frames  = {"1h": ("5d","1h"), "4h": ("1mo","1h"), T("يومي","1d"): ("3mo","1d")}

    for label, (period, interval) in frames.items():
        try:
            with contextlib.redirect_stderr(io.StringIO()):
                df = yf.Ticker(sym).history(period=period, interval=interval)
            if not df.empty:
                df = df.dropna(subset=["Open", "High", "Low", "Close"])
            if df.empty or len(df) < 15: continue
            c  = df["Close"].values.astype(float)
            h  = df["High"].values.astype(float)
            l  = df["Low"].values.astype(float)

            e9  = _ema(c, 9); e21 = _ema(c, 21)
            r   = _rsi(c)
            _, _, macd_h = _macd(c)
            price = c[-1]

            bull = sum([e9>e21, price>e21, r>50, macd_h>0, c[-1]>c[-5]])
            if bull >= 4:   trend = "🟢 صاعد"
            elif bull >= 3: trend = "🟡 محايد"
            else:           trend = "🔴 هابط"

            results[label] = {
                "trend": trend, "rsi": r,
                "ema9": e9, "ema21": e21,
                "macd_h": macd_h, "bull": bull
            }
        except: pass

    return results

# ══════════════════════════════════════════════════════════════
#  المدارس الإضافية: Fibonacci + Pivot Points + SMC
# ══════════════════════════════════════════════════════════════

def fibonacci_levels(h, l, c, price):
    ha = np.array(h[-60:]); la = np.array(l[-60:])
    swing_high = float(ha.max()); swing_low = float(la.min())
    diff = swing_high - swing_low
    if diff <= 0: return {}, "", 0
    fib = {
        "0.0%":   swing_high,
        "23.6%":  swing_high - diff*0.236,
        "38.2%":  swing_high - diff*0.382,
        "50.0%":  swing_high - diff*0.500,
        "61.8%":  swing_high - diff*0.618,
        "78.6%":  swing_high - diff*0.786,
        "100%":   swing_low,
        "127.2%": swing_low  - diff*0.272,
        "161.8%": swing_low  - diff*0.618,
    }
    nearest   = min(fib.items(), key=lambda x: abs(x[1]-price))
    dist_pct  = abs(price - nearest[1]) / price * 100
    signal=""; strength=0
    if dist_pct <= 2.0:
        if nearest[0] in ("38.2%","50.0%","61.8%"):
            signal = f"ارتداد من فيبوناتشي {nearest[0]} الذهبي 🎯"; strength=3
        elif nearest[0] in ("23.6%","78.6%"):
            signal = f"عند فيبوناتشي {nearest[0]}"; strength=2
        else:
            signal = f"قرب فيبوناتشي {nearest[0]}"; strength=1
    fib_sups = {k:v for k,v in fib.items() if v < price}
    fib_res  = {k:v for k,v in fib.items() if v > price}
    return {
        "levels": fib, "nearest": (nearest[0], nearest[1], dist_pct),
        "support":    max(fib_sups.items(), key=lambda x:x[1]) if fib_sups else None,
        "resistance": min(fib_res.items(),  key=lambda x:x[1]) if fib_res  else None,
        "swing_high": swing_high, "swing_low": swing_low,
        "signal": signal, "strength": strength,
    }, signal, strength


def pivot_points(h, l, c):
    prev_h = float(h[-2]) if len(h)>=2 else float(h[-1])
    prev_l = float(l[-2]) if len(l)>=2 else float(l[-1])
    prev_c = float(c[-2]) if len(c)>=2 else float(c[-1])
    curr   = float(c[-1])
    pp = (prev_h + prev_l + prev_c) / 3
    r1 = 2*pp - prev_l;  r2 = pp + (prev_h - prev_l);  r3 = prev_h + 2*(pp - prev_l)
    s1 = 2*pp - prev_h;  s2 = pp - (prev_h - prev_l);  s3 = prev_l - 2*(prev_h - pp)
    rng  = prev_h - prev_l
    fp_r1 = pp + rng*0.382; fp_r2 = pp + rng*0.618
    fp_s1 = pp - rng*0.382; fp_s2 = pp - rng*0.618
    signal=""; strength=0
    for name, level in [("PP",pp),("R1",r1),("S1",s1),("R2",r2),("S2",s2),("FP-R1",fp_r1),("FP-S1",fp_s1)]:
        dist = abs(curr-level)/curr*100
        if dist <= 1.5:
            if name=="PP":    signal=f"عند نقطة الارتكاز PP (${level:.2f})"; strength=2
            elif "S" in name: signal=f"ارتداد من {name} (${level:.2f}) 🟢"; strength=3 if name=="S1" else 2
            elif "R" in name: signal=f"عند مقاومة {name} (${level:.2f}) ⚠️"; strength=1
            break
    if not signal:
        signal = f"فوق PP (${pp:.2f}) — إيجابي" if curr>pp else f"تحت PP (${pp:.2f}) — سلبي"
        strength = 1 if curr>pp else 0
    return {
        "pp":pp,"r1":r1,"r2":r2,"r3":r3,"s1":s1,"s2":s2,"s3":s3,
        "fp_r1":fp_r1,"fp_r2":fp_r2,"fp_s1":fp_s1,"fp_s2":fp_s2,
        "above_pp": curr>pp, "signal":signal, "strength":strength,
    }


def smart_money_concepts(h, l, c, v, price):
    signals=[]; strength=0
    ha=np.array(h); la=np.array(l); ca=np.array(c)

    # Order Block
    if len(ca)>=5:
        for i in range(-6,-1):
            try:
                if ca[i]<ca[i-1] and ca[i]>0:
                    rise=(ca[i+1]-ca[i])/ca[i]*100
                    if rise>=2.0:
                        ob_top=float(ha[i]); ob_bot=float(la[i])
                        if ob_bot<=price<=ob_top*1.02:
                            signals.append(f"Order Block صاعد ${ob_bot:.2f}–${ob_top:.2f} 🟦"); strength+=3; break
            except: pass

    # Fair Value Gap
    if len(ca)>=4:
        for i in range(-5,-1):
            try:
                if float(la[i])>float(ha[i-2]):
                    mid=(float(la[i])+float(ha[i-2]))/2
                    if abs(price-mid)/price*100<=3.0:
                        signals.append(f"Fair Value Gap صاعد ${ha[i-2]:.2f}–${la[i]:.2f} ⬆️"); strength+=2; break
                elif float(ha[i])<float(la[i-2]):
                    mid=(float(ha[i])+float(la[i-2]))/2
                    if abs(price-mid)/price*100<=3.0:
                        signals.append(f"Fair Value Gap هابط ⬇️"); strength+=0; break
            except: pass

    # Liquidity Sweep
    if len(ha)>=10:
        ph=ha[-10:-1]; pl=la[-10:-1]
        ppeak=float(ph[:-1].max()); ptrough=float(pl[:-1].min())
        if float(la[-1])<ptrough and float(ca[-1])>ptrough:
            signals.append(f"Liquidity Sweep صاعد — اصطياد وقوف الخسارة ✅"); strength+=3
        elif float(ha[-1])>ppeak and float(ca[-1])<ppeak:
            signals.append(f"Liquidity Sweep هابط ⚠️")

    # Break of Structure
    if len(ca)>=6:
        h3=[float(ha[-i]) for i in range(1,4)]
        if h3[0]>h3[1]>h3[2]:
            signals.append(f"Break of Structure صاعد (BOS) ✅"); strength+=2
        elif h3[0]<h3[1]<h3[2]:
            signals.append(f"Break of Structure هابط (BOS) ⚠️"); strength-=1

    # Change of Character
    if len(ca)>=8:
        rl=float(la[-3:].min()); el=float(la[-8:-3].min())
        if rl>el and float(ca[-1])>float(ca[-4]):
            signals.append(f"Change of Character صاعد (ChoCH) 🔄"); strength+=2

    # Premium / Discount
    if len(ha)>=20:
        h20=float(ha[-20:].max()); l20=float(la[-20:].min()); rng20=h20-l20
        if rng20>0:
            pos=(price-l20)/rng20*100
            if pos<=35:   signals.append(f"منطقة Discount ({pos:.0f}%) 🟢"); strength+=2
            elif pos>=65: signals.append(f"منطقة Premium ({pos:.0f}%) ⚠️"); strength-=1
            else:         signals.append(f"منطقة Equilibrium ({pos:.0f}%)")

    return {"signals": signals, "strength": max(0, min(10, strength))}


# ══════════════════════════════════════════════════════════════
#  نسبة الربح/الخسارة التاريخية
# ══════════════════════════════════════════════════════════════

def pattern_stats_table(patterns_found: list):
    """يعرض الإحصاءات التاريخية للنماذج المكتشفة"""
    rows = []
    for name in patterns_found:
        clean = name.replace("🔨 ","").replace("🕯️ ","").replace("⭐ ","").replace("🌠 ","") \
                    .replace("⚔️ ","").replace("🐦 ","").replace("🌆 ","").replace("📊 ","") \
                    .replace("✚ ","").replace("W ","").replace("M ","").replace("🚩 ","") \
                    .replace("☕ ","").replace("△ ","").replace("▽ ","").strip()
        st = PATTERN_STATS.get(clean, None)
        if st:
            wr = st.get("win", st.get("win_rate", 0))
            ag = st.get("gain", st.get("avg_gain", 0))
            al = st.get("loss", st.get("avg_loss", 0))
            tr = st.get("trades", 0)
            ev = (wr/100 * ag) - ((1-wr/100) * al)
            rows.append((clean, wr, ag, al, ev, tr))
    return rows

# ══════════════════════════════════════════════════════════════
#  التحليل الكامل لسهم واحد
# ══════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════
#  نظام تقييم مزدوج: مضارب يومي + مستثمر
# ══════════════════════════════════════════════════════════════

def smart_stop_loss(price, h, l, c, supports, atr_v):
    """
    وقف خسارة احترافي — 4 طبقات بالأولوية:
    1. أقرب دعم تحت السعر (الأفضل)
    2. Low آخر 3 شمعات
    3. ATR×0.5 — محدود بـ 8%
    4. حد أقصى إجباري 8%
    """
    candidates = []
    if supports:
        for sup in supports[:3]:
            dist_pct = (price - sup) / price * 100
            if 1.5 <= dist_pct <= 8.0:
                candidates.append(("Support", sup * 0.995, dist_pct))
    recent_low = float(min(l[-3:]))
    dist_low   = (price - recent_low) / price * 100
    if 1.0 <= dist_low <= 10.0:
        candidates.append(("Recent Low", recent_low * 0.998, dist_low))
    atr_stop     = price - (atr_v * 0.5)
    atr_dist_pct = (price - atr_stop) / price * 100
    if atr_dist_pct <= 8.0:
        candidates.append(("ATR×0.5", atr_stop, atr_dist_pct))
    atr1_stop     = price - atr_v
    atr1_dist_pct = (price - atr1_stop) / price * 100
    if atr1_dist_pct <= 8.0:
        candidates.append(("ATR×1.0", atr1_stop, atr1_dist_pct))
    valid = [c2 for c2 in candidates if 1.5 <= c2[2] <= 8.0]
    if valid:
        best = min(valid, key=lambda x: x[2])
        return best[0], best[1], best[2]
    return "Max 8%", price * 0.92, 8.0


# ══════════════════════════════════════════════════════════════
#  محرّك هيكل السوق + الباكتيست (دراسة سلوك السهم الماضي)
#  قمم/قيعان متأرجحة • مناطق عرض/طلب • وقف هيكلي • تحقق تاريخي
# ══════════════════════════════════════════════════════════════

def _ema_series(x, p):
    x = np.asarray(x, float)
    if len(x) == 0: return x
    k = 2.0 / (p + 1.0)
    out = np.empty_like(x); out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = x[i] * k + out[i-1] * (1 - k)
    return out

def _rsi_series(c, p=14):
    c = np.asarray(c, float)
    rsi = np.full(len(c), 50.0)
    if len(c) <= p: return rsi
    d = np.diff(c)
    up = np.where(d > 0, d, 0.0); dn = np.where(d < 0, -d, 0.0)
    ag = up[:p].mean(); al = dn[:p].mean()
    for i in range(p, len(d)):
        ag = (ag * (p-1) + up[i]) / p
        al = (al * (p-1) + dn[i]) / p
        rs = ag / al if al > 0 else 999.0
        rsi[i+1] = 100 - 100 / (1 + rs)
    return rsi

def _atr_series(h, l, c, p=14):
    h = np.asarray(h, float); l = np.asarray(l, float); c = np.asarray(c, float)
    atr = np.zeros(len(c))
    if len(c) < 2: return atr
    tr = np.maximum(h[1:] - l[1:],
                    np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    if len(tr) < p:
        atr[:] = tr.mean() if len(tr) else 0.0
        return atr
    a = tr[:p].mean()
    atr[p] = a
    for i in range(p, len(tr)):
        a = (a * (p-1) + tr[i]) / p
        atr[i+1] = a
    atr[:p] = atr[p]
    return atr

def detect_swings(h, l, left=2, right=2):
    """قمم وقيعان متأرجحة مؤكَّدة (Fractals) — يرجع [(index, price), ...]"""
    h = np.asarray(h, float); l = np.asarray(l, float); n = len(h)
    highs, lows = [], []
    for i in range(left, n - right):
        if h[i] == h[i-left:i+right+1].max():
            highs.append((i, float(h[i])))
        if l[i] == l[i-left:i+right+1].min():
            lows.append((i, float(l[i])))
    return highs, lows

def cluster_levels(prices, tol_pct=0.6):
    """يجمّع الأسعار المتقاربة في مناطق ويعدّ اللمسات (قوة المنطقة)"""
    prices = sorted(float(p) for p in prices if p and p > 0)
    if not prices: return []
    zones = [[prices[0]]]
    for p in prices[1:]:
        if abs(p - zones[-1][-1]) / zones[-1][-1] * 100 <= tol_pct:
            zones[-1].append(p)
        else:
            zones.append([p])
    return [{"level": float(np.mean(z)), "touches": len(z)} for z in zones]

def structure_stop(price, swing_lows, atr_v, lo_pct, hi_pct, buf=0.25):
    """وقف هيكلي: تحت أقرب قاع متأرجح + هامش ATR، ثم ATR احتياطياً، مع تقييد بالنطاق"""
    below = [lv for _, lv in swing_lows if lv < price]
    if below:
        lvl = max(below)                      # أقرب قاع تحت السعر
        stop = lvl - buf * atr_v
        pct = (price - stop) / price * 100
        if lo_pct <= pct <= hi_pct:
            return T("قاع متأرجح","Swing low"), stop, pct
    mult = 1.5 if hi_pct <= 8 else 3.0        # احتياطي ATR (Chandelier)
    pct = min(max((mult * atr_v) / price * 100, lo_pct), hi_pct)
    return f"ATR×{mult}", price * (1 - pct/100), pct

def backtest_long(h, l, c, horizon="trader", rr=2.0):
    """
    باكتيست بسيط بدون استشراف (no lookahead) على البيانات اليومية:
    إشارة شراء = اتجاه صاعد (فوق EMA50) + تراجع (RSI<55 وقرب EMA21) + شمعة انعكاس.
    الدخول عند إغلاق الإشارة، الوقف من ATR، الهدف = rr × المخاطرة.
    يرجع: عدد الصفقات، نسبة الربح، متوسط R، ومؤشر ثقة 0–100.
    """
    c = np.asarray(c, float); h = np.asarray(h, float); l = np.asarray(l, float)
    n = len(c)
    empty = {"trades": 0, "winrate": 0.0, "avgR": 0.0, "conf": 0}
    if n < 40: return empty
    e21 = _ema_series(c, 21)
    e50 = _ema_series(c, 50 if n >= 50 else max(10, n // 2))
    rsi = _rsi_series(c); atr = _atr_series(h, l, c)
    max_hold = 10 if horizon == "trader" else 35
    stop_mult = 1.2 if horizon == "trader" else 2.5

    trades = []; i = 30
    while i < n - 1:
        uptrend = c[i] > e50[i]
        pullback = rsi[i] < 55 and (abs(c[i] - e21[i]) / c[i] < 0.04 or c[i] < e21[i] * 1.01)
        trigger = c[i] > c[i-1] and c[i-1] <= c[i-2]   # ارتداد بعد تراجع
        if uptrend and pullback and trigger and atr[i] > 0:
            entry = c[i]
            stop  = entry - stop_mult * atr[i]
            risk  = entry - stop
            if risk <= 0:
                i += 1; continue
            target = entry + rr * risk
            outcome = None
            j = i + 1; end = min(n, i + 1 + max_hold)
            while j < end:
                if l[j] <= stop:   outcome = -1.0; break
                if h[j] >= target: outcome = rr;   break
                j += 1
            if outcome is None:
                outcome = (c[min(j, n-1)] - entry) / risk
            trades.append(outcome)
            i = j + 1                                   # منع تداخل الصفقات
        else:
            i += 1

    if not trades: return empty
    wins = sum(1 for t in trades if t > 0)
    wr   = wins / len(trades) * 100
    avgR = float(np.mean(trades))
    conf = max(0, min(100, wr * 0.5 + avgR * 15 + min(len(trades), 12) * 2))
    return {"trades": len(trades), "winrate": round(wr, 1),
            "avgR": round(avgR, 2), "conf": round(conf)}


# ══════════════════════════════════════════════════════════════
#  نظام تقييم مزدوج: مضارب يومي + مستثمر
# ══════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════
#  التوقّع الاحتمالي (لا التنبؤ): نموذج احتمالي + النطاق المتوقع
#  يقيس الاحتمالات من توزيع عوائد السهم نفسه — ليس وعداً بالاتجاه
# ══════════════════════════════════════════════════════════════

def forecast_probabilistic(c, entry, stop, target, horizon_days, v=None, flow_bias=0.0, n_sims=5000):
    """
    توقع احتمالي متعدد العوامل: نموذج احتمالي معدّل اتجاهياً وفق
    سلوك السهم (الزخم)، الحجم (تجميع/توزيع)، وتدفق المؤسسات/الداخل (flow_bias).
    يرجع احتمالات بلوغ الهدف/الوقف، أرجحية الهدف قبل الوقف، الانحياز، والمحرّكات.
    كلها تقديرات احتمالية لا ضمانات.
    """
    out = {"ok": False}
    c = np.asarray(c, float)
    mask = np.isfinite(c) & (c > 0)
    c = c[mask]
    if len(c) < 30 or not np.isfinite(entry) or entry <= 0:
        return out
    rets = np.diff(np.log(c))
    rets = rets[np.isfinite(rets)]
    if len(rets) < 20:
        return out

    mu_hist = float(np.mean(rets))
    sigma_d = float(np.std(rets)) or 1e-6
    H = max(1, int(horizon_days))

    def _clip(x, a=-1.0, b=1.0): return max(a, min(b, x))

    # ── 1) الزخم / سلوك السهم السابق (عائد 20 يوماً) ──
    look = min(21, len(c) - 1)
    mom = (c[-1] / c[-1 - look] - 1) if look > 0 else 0.0
    mom_sig = _clip(mom / 0.15)                      # ±15% خلال ~شهر = إشارة كاملة

    # ── 2) الحجم: تجميع مقابل توزيع + تمدّد ──
    acc = vol_exp = 0.0
    if v is not None:
        v = np.asarray(v, float)[mask] if len(np.asarray(v, float)) == len(mask) else np.asarray(v, float)
        v = np.nan_to_num(v)
        if len(v) >= 21 and len(c) >= 21:
            vv = v[-21:]; dirn = np.sign(np.diff(c[-21:]))
            upv = vv[1:][dirn > 0].sum(); dnv = vv[1:][dirn < 0].sum()
            acc = _clip((upv - dnv) / (upv + dnv + 1e-9))      # حجم الصعود مقابل الهبوط
            vol_exp = _clip(vv[-5:].mean() / (vv.mean() + 1e-9) - 1)  # تمدّد الحجم مؤخراً

    # ── 3) الانحياز المركّب (conviction) ──
    fb = _clip(float(flow_bias))
    conv = _clip(0.40 * mom_sig + 0.35 * acc + 0.10 * vol_exp + 0.15 * fb)

    # الأساس: مشي عشوائي بلا انحياز (نزع الدريفت التاريخي تماماً — غير موثوق ويسبب تفاؤلاً زائفاً).
    # الاحتمال يعتمد جوهرياً على قرب الهدف مقابل الوقف (first-passage)، مع لمسة سلوكية
    # صغيرة محدودة لا تتراكم: إجمالي الإزاحة عبر كامل الأفق ≤ ±0.2 من انحراف الأفق.
    sigma_H = sigma_d * np.sqrt(H)
    mu_total = conv * 0.20 * sigma_H      # إزاحة كلية صغيرة عبر الأفق كله
    mu_adj   = mu_total / H               # لكل خطوة، فمجموعها = mu_total (لا تراكم مُبالغ)
    rets_centered = rets - mu_hist        # نحافظ على شكل التذبذب فقط، بلا دريفت تاريخي

    em1 = entry * sigma_d * np.sqrt(H)
    band1 = (entry - em1, entry + em1)
    band2 = (entry - 2*em1, entry + 2*em1)

    rng   = np.random.default_rng(42)
    steps = rng.choice(rets_centered, size=(n_sims, H), replace=True) + mu_adj
    paths = entry * np.exp(np.cumsum(steps, axis=1))
    finals = paths[:, -1]

    BIG = H + 1
    t_first = np.where((paths >= target).any(axis=1), (paths >= target).argmax(axis=1), BIG)
    s_first = np.where((paths <= stop).any(axis=1),   (paths <= stop).argmax(axis=1),   BIG)
    hit_t = int(np.sum(t_first < s_first))
    hit_s = int(np.sum(s_first < t_first))
    neither = n_sims - hit_t - hit_s
    p_t = hit_t / n_sims * 100; p_s = hit_s / n_sims * 100
    odds = p_t / (p_t + p_s) * 100 if (p_t + p_s) > 0 else 50.0
    p_up = float(np.mean(finals > entry) * 100)

    bias = T("صاعد", "Bullish") if conv > 0.18 else (T("هابط", "Bearish") if conv < -0.18 else T("محايد", "Neutral"))
    drivers = []
    if mom_sig >  0.15: drivers.append(T("زخم صاعد", "Upward momentum"))
    elif mom_sig < -0.15: drivers.append(T("زخم هابط", "Downward momentum"))
    if acc >  0.15: drivers.append(T("تجميع (حجم على الصعود)", "Accumulation (up-volume)"))
    elif acc < -0.15: drivers.append(T("توزيع (حجم على الهبوط)", "Distribution (down-volume)"))
    if vol_exp > 0.20: drivers.append(T("تمدّد في الحجم", "Volume expansion"))

    return {
        "ok": True,
        "p_target": p_t, "p_stop": p_s, "p_neither": neither / n_sims * 100,
        "odds_target_first": odds,           # أرجحية بلوغ الهدف قبل الوقف
        "p_up": p_up,                        # احتمال أن يكون أعلى من الدخول نهاية الأفق
        "bias": bias, "conviction": round(conv, 2), "drivers": drivers,
        "exp_move_pct": em1 / entry * 100,
        "band1": band1, "band2": band2,
        "median": float(np.median(finals)),
        "p10": float(np.percentile(finals, 10)),
        "p90": float(np.percentile(finals, 90)),
        "horizon": H,
    }


def score_trader(sym, price, o, h, l, c, v, supports, resistances,
                 rsi_v, e9, e21, e50, atr_v, macd_h, bb_u, bb_lo,
                 candles, chart_p, mtf):
    """
    تقييم المضارب اليومي — يبحث عن:
    ◈ نقطة دخول دقيقة مع زخم قصير المدى
    ◈ الأطر: 5m + 15m + 1h
    ◈ المعايير: VWAP، Momentum، Volume Surge، RSI قوي
    ◈ الوقف: ضيق جداً (1-4%)
    ◈ الهدف: 2-8% في نفس اليوم أو يومين
    """
    score   = 0
    signals = []
    reasons = []

    # ── 1. زخم السعر اليومي ────────────────────────────────────
    day_chg = (c[-1]-c[-2])/c[-2]*100 if c[-2]>0 else 0
    if day_chg >= 5:   score+=3; signals.append("زخم قوي جداً 🔥")
    elif day_chg >= 2: score+=2; signals.append("زخم صاعد ✅")
    elif day_chg >= 0.5: score+=1; signals.append("صاعد طفيف")
    elif day_chg < -3: score-=2; signals.append("هبوط حاد ⚠️")

    # ── 2. حجم التداول — الأهم للمضارب ─────────────────────────
    if len(v) >= 5:
        avg_vol = float(np.mean(v[-20:-1]))
        today_vol = float(v[-1])
        if avg_vol > 0:
            vol_ratio = today_vol / avg_vol
            if vol_ratio >= 3:   score+=3; signals.append(f"حجم ×{vol_ratio:.1f} 🔥")
            elif vol_ratio >= 2: score+=2; signals.append(f"حجم ×{vol_ratio:.1f} ✅")
            elif vol_ratio >= 1.3: score+=1; signals.append(f"حجم ×{vol_ratio:.1f}")
            elif vol_ratio < 0.7: score-=1

    # ── 3. RSI في النطاق المثالي للمضاربة ─────────────────────
    if 55 <= rsi_v <= 72:
        score+=2; signals.append(f"RSI={rsi_v:.0f} مثالي ✅")
    elif 45 <= rsi_v < 55:
        score+=1; signals.append(f"RSI={rsi_v:.0f} محايد")
    elif rsi_v > 80:
        score-=2; signals.append(f"RSI={rsi_v:.0f} مشبع ⚠️")
    elif rsi_v < 40:
        score-=1

    # ── 4. MACD Histogram متسارع ────────────────────────────────
    if macd_h > 0.05:  score+=2; signals.append("MACD متسارع ✅")
    elif macd_h > 0:   score+=1; signals.append("MACD إيجابي")
    elif macd_h < -0.05: score-=1

    # ── 5. EMA 9 فوق EMA 21 (زخم قصير) ─────────────────────────
    if e9 > e21 * 1.005: score+=2; signals.append("EMA9 > EMA21 ✅")
    elif e9 > e21:        score+=1

    # ── 6. السعر قريب من EMA9 (نقطة دخول مثالية) ──────────────
    dist_from_e9 = abs(price - e9) / price * 100
    if dist_from_e9 <= 1.0: score+=2; signals.append("قرب EMA9 — دخول مثالي 🎯")
    elif dist_from_e9 <= 2.5: score+=1

    # ── 7. Bollinger — ليس في الذروة ───────────────────────────
    if bb_u > 0:
        bb_pos = (price - bb_lo) / (bb_u - bb_lo) if (bb_u-bb_lo) > 0 else 0.5
        if 0.4 <= bb_pos <= 0.75: score+=1; signals.append("موقع BB مثالي ✅")
        elif bb_pos > 0.90: score-=2; signals.append("قرب الحد العلوي ⚠️")

    # ── 8. نموذج شمعة صاعد قوي ─────────────────────────────────
    bull_candles = [(n,s) for n,d,s,_ in candles if d=="BULLISH" and s>=4]
    if bull_candles:
        best = max(bull_candles, key=lambda x: x[1])
        score+=2; signals.append(f"نموذج: {best[0]} ★{best[1]}")

    # ── 9. دعم قريب يحمي الصفقة ────────────────────────────────
    if supports:
        near_sup = (price - supports[0]) / price * 100
        if near_sup <= 3: score+=2; signals.append(f"دعم قريب -{near_sup:.1f}% 🛡️")
        elif near_sup <= 5: score+=1

    # ══ هيكل السوق: قمم/قيعان متأرجحة + مناطق طلب/عرض ═══════════
    sw_h, sw_l = detect_swings(h, l, left=2, right=2)
    demand = cluster_levels([lv for _, lv in sw_l if lv < price])   # دعوم
    supply = cluster_levels([lv for _, lv in sw_h if lv > price])   # مقاومات

    # ── منطقة الدخول: تقاطع (دعم + EMA + فيبوناتشي) ────────────
    confl = []
    if demand:
        confl.append(demand[-1]["level"])             # أقرب دعم تحت السعر
    for ema in (e9, e21):
        if 0 < ema <= price * 1.002:
            confl.append(ema)
    if sw_h and sw_l:                                 # فيبو للموجة الصاعدة الأخيرة
        sw_low = sw_l[-1][1]; sw_high = max(price, sw_h[-1][1])
        rng = sw_high - sw_low
        if rng > 0:
            for f in (0.382, 0.5, 0.618):
                confl.append(sw_high - rng * f)
    confl = [x for x in confl if 0 < x <= price * 1.002]

    if confl:
        confl.sort(reverse=True)
        entry_hi = min(price, confl[0])               # أعلى تقاطع تحت السعر
        band     = min(max(atr_v * 0.5, price * 0.004), entry_hi * 0.04)  # سقف عرض المنطقة ~4% ليبقى عملياً
        entry_lo = entry_hi - band
        entry_note    = T(f"منطقة دخول ${entry_lo:.2f}–${entry_hi:.2f} (تقاطع دعم/EMA/فيبو)", f"Entry zone ${entry_lo:.2f}–${entry_hi:.2f} (S/R+EMA+Fib confluence)")
        entry_trigger = T("التفعيل: إغلاق شمعة صاعدة داخل المنطقة + حجم ≥ المتوسط", "Trigger: bullish candle close inside zone + volume ≥ avg")
    else:
        entry_hi = price * 0.997
        entry_lo = price * 0.99
        entry_note    = T(f"دخول على الارتداد ${entry_lo:.2f}–${entry_hi:.2f}", f"Pullback entry ${entry_lo:.2f}–${entry_hi:.2f}")
        entry_trigger = T(f"التفعيل: تأكيد إغلاق فوق ${price:.2f}", f"Trigger: confirmed close above ${price:.2f}")

    entry_ref = (entry_lo + entry_hi) / 2.0

    # ── الوقف الهيكلي: تحت منطقة الدخول (قاع متأرجح + ATR) ─────
    #    يُحسب نسبةً إلى الدخول لا إلى السعر الحالي حتى لا يقع فوق الدخول
    stop_method, trader_stop, _ = structure_stop(
        entry_lo, sw_l, atr_v, lo_pct=1.2, hi_pct=5.0, buf=0.25)
    if trader_stop >= entry_lo:                       # ضمان الوقف تحت المنطقة
        trader_stop = entry_lo - max(atr_v * 1.0, entry_lo * 0.012)
    trader_risk = entry_ref - trader_stop
    if trader_risk <= 0:
        trader_risk = entry_ref * 0.02
        trader_stop = entry_ref - trader_risk
    trader_stop_pct = (entry_ref - trader_stop) / entry_ref * 100  # المخاطرة من الدخول

    # ── الأهداف: أقرب مقاومة حقيقية، ومُقيَّدة بتذبذب السهم (ATR) لتبقى واقعية قريبة ──
    #    منهج المحلل المخضرم: الهدف عند أقرب عرض فعلي أو ضمن حركة السهم المعتادة، لا أرقام بعيدة
    t1_cap = entry_ref + max(trader_risk * 2.0, atr_v * 2.2)   # سقف واقعي لـ TP1
    t2_cap = entry_ref + max(trader_risk * 3.0, atr_v * 4.0)   # سقف واقعي لـ TP2
    near1 = [s for s in supply if entry_ref < s["level"] <= entry_ref + atr_v * 4.5
             and (s["level"] - entry_ref) / trader_risk >= 1.2]
    if near1:
        trader_tp1 = min(near1[0]["level"] * 0.996, t1_cap)
    else:
        trader_tp1 = entry_ref + min(trader_risk * 2.0, atr_v * 2.2)
    near2 = [s for s in supply if s["level"] > trader_tp1 and s["level"] <= entry_ref + atr_v * 7]
    if near2:
        trader_tp2 = min(near2[0]["level"] * 0.996, t2_cap)
    else:
        trader_tp2 = min(entry_ref + trader_risk * 3.0, t2_cap)
    if trader_tp1 <= entry_ref: trader_tp1 = entry_ref + trader_risk * 1.8
    if trader_tp2 <= trader_tp1: trader_tp2 = trader_tp1 + max(trader_risk * 1.0, atr_v * 1.0)
    actual_rr = (trader_tp1 - entry_ref) / trader_risk if trader_risk > 0 else 0

    trader_entry_lo = entry_lo
    trader_entry_hi = entry_hi

    # ── دراسة سلوك السهم الماضي (باكتيست بدون استشراف) ────────
    bt = backtest_long(h, l, c, horizon="trader", rr=2.0)

    # ── التوقّع الاحتمالي (نموذج احتمالي، أفق ~10 أيام) ──────────
    fc = forecast_probabilistic(c, entry_ref, trader_stop, trader_tp1, horizon_days=10, v=v)

    score = max(0, min(10, score))

    return {
        "score":      score,
        "signals":    signals,
        "entry_lo":   trader_entry_lo,
        "entry_hi":   trader_entry_hi,
        "entry_ref":  entry_ref,
        "entry_note": entry_note,
        "entry_trigger": entry_trigger,
        "stop":       trader_stop,
        "stop_pct":   trader_stop_pct,
        "stop_method": stop_method,
        "invalidation": trader_stop,
        "tp1":        trader_tp1,
        "tp2":        trader_tp2,
        "rr":         actual_rr,
        "horizon":    T("نفس اليوم — يومان","Intraday — 2 days"),
        "bt_trades":  bt["trades"],
        "bt_winrate": bt["winrate"],
        "bt_avgR":    bt["avgR"],
        "confidence": bt["conf"],
        "forecast":   fc,
    }


def score_investor(sym, price, h, l, c, v, supports, resistances,
                   rsi_v, e50, e200, atr_v, macd_h, candles, chart_p):
    """
    تقييم المستثمر — يبحث عن:
    ◈ اتجاه قوي طويل المدى مع تصحيح صحي
    ◈ الأطر: يومي + أسبوعي
    ◈ المعايير: EMA50/200، Wyckoff تراكم، نماذج عكس كبيرة
    ◈ الوقف: أوسع (5-15%)
    ◈ الهدف: 15-40% في أسابيع أو أشهر
    """
    score   = 0
    signals = []

    # ── 1. السعر فوق EMA200 — اتجاه صاعد طويل ──────────────────
    if price > e200 * 1.02:
        score+=3; signals.append("فوق EMA200 — Uptrend ✅")
    elif price > e200:
        score+=2; signals.append("فوق EMA200 ✅")
    elif price < e200 * 0.95:
        score-=2; signals.append("تحت EMA200 بعيداً ❌")

    # ── 2. Golden Cross EMA50/200 ───────────────────────────────
    if e50 > e200 * 1.01:
        score+=3; signals.append("Golden Cross EMA50/200 ✅")
    elif e50 > e200:
        score+=1; signals.append("EMA50 > EMA200")
    elif e50 < e200 * 0.97:
        score-=2; signals.append("Death Cross ❌")

    # ── 3. تصحيح صحي من الذروة (نقطة دخول مثالية) ─────────────
    high_20 = float(np.max(h[-20:]))
    pullback = (high_20 - price) / high_20 * 100 if high_20 > 0 else 0
    if 8 <= pullback <= 20:
        score+=3; signals.append(f"تصحيح صحي -{pullback:.0f}% من الذروة 🎯")
    elif 3 <= pullback < 8:
        score+=1; signals.append(f"تراجع طفيف -{pullback:.0f}%")
    elif pullback > 30:
        score-=1; signals.append(f"تراجع عميق -{pullback:.0f}%")

    # ── 4. RSI — مناسب للاستثمار ────────────────────────────────
    if 40 <= rsi_v <= 65:
        score+=2; signals.append(f"RSI={rsi_v:.0f} منطقة شراء مثالية ✅")
    elif 35 <= rsi_v < 40:
        score+=1; signals.append(f"RSI={rsi_v:.0f} — مشبع بيع قريب")
    elif rsi_v > 75:
        score-=1; signals.append(f"RSI={rsi_v:.0f} — مرتفع جداً")

    # ── 5. نماذج عكس كبيرة ──────────────────────────────────────
    strong_patterns = ["W Double Bottom","Cup & Handle","Morning Star",
                       "Three White Soldiers","Bullish Engulfing"]
    found_strong = [n for n,d,*_ in chart_p+candles
                    if n in strong_patterns and d=="BULLISH"]
    if found_strong:
        score+=3; signals.append(f"نموذج قوي: {found_strong[0]} 🏆")

    # ── 6. حجم مرتفع على الارتداد (تأكيد المؤسسات) ─────────────
    if len(v) >= 10:
        avg_v = float(np.mean(v[-20:]))
        last5_v = float(np.mean(v[-5:]))
        if avg_v > 0 and last5_v/avg_v >= 1.5:
            score+=2; signals.append("حجم مرتفع — اهتمام مؤسسي ✅")

    # ── 7. دعم قوي يحمي المركز ──────────────────────────────────
    if supports and len(supports) >= 2:
        score+=2; signals.append(f"مستويات دعم متعددة 🛡️")
    elif supports:
        score+=1; signals.append(f"دعم قريب 🛡️")

    # ── 8. MACD فوق الصفر أو يتجه للأعلى ───────────────────────
    if macd_h > 0: score+=1; signals.append("MACD إيجابي ✅")

    # ══ هيكل السوق للمستثمر: قيعان/قمم متأرجحة + مناطق ═════════
    sw_h, sw_l = detect_swings(h, l, left=3, right=3)
    demand = cluster_levels([lv for _, lv in sw_l if lv < price])
    supply = cluster_levels([lv for _, lv in sw_h if lv > price])

    # ── الوقف الهيكلي: قاع متأرجح + ATR، نطاق أضيق 5–12% (لا وقف بعيد) ─────
    stop_method, inv_stop, _ = structure_stop(
        price, sw_l, atr_v, lo_pct=5.0, hi_pct=12.0, buf=0.5)
    # لا يكون الوقف أعلى من EMA50 إن كان السعر فوقها (منطقي للاتجاه)
    if price > e50 and inv_stop > e50 * 0.97:
        inv_stop = e50 * 0.97
    inv_stop_pct = (price - inv_stop) / price * 100
    inv_risk     = price - inv_stop
    if inv_risk <= 0:
        inv_risk = price * 0.05; inv_stop = price - inv_risk
        inv_stop_pct = 5.0

    # ── الدخول: تقاطع EMA50 / منطقة طلب رئيسية ─────────────────
    if abs(price - e50) / price < 0.03:
        inv_entry_note = T(f"الدخول المثالي: قرب EMA50 (${e50:.2f})", f"Ideal entry: near EMA50 (${e50:.2f})")
    elif demand:
        inv_entry_note = T(f"الدخول المثالي: منطقة طلب (${demand[-1]['level']:.2f})", f"Ideal entry: demand zone (${demand[-1]['level']:.2f})")
    else:
        inv_entry_note = T(f"الدخول: السعر الحالي ${price:.2f}", f"Entry: current price ${price:.2f}")

    # ── الأهداف: متناسبة مع تذبذب السهم (ATR) وأقرب مقاومة، مرتّبة وغير بعيدة ──
    i1_cap = price + atr_v * 4
    i2_cap = price + atr_v * 7
    i3_cap = price + atr_v * 10
    def _nearest_res(lo, hi):
        cs = [s["level"] for s in supply if lo < s["level"] <= hi]
        return cs[0] if cs else None
    r1 = _nearest_res(price, i1_cap)
    inv_tp1 = min((r1 * 0.995) if r1 else price + atr_v * 2.5, i1_cap)
    r2 = _nearest_res(inv_tp1, i2_cap)
    inv_tp2 = min((r2 * 0.995) if r2 else inv_tp1 + atr_v * 2.5, i2_cap)
    r3 = _nearest_res(inv_tp2, i3_cap)
    inv_tp3 = min((r3 * 0.995) if r3 else inv_tp2 + atr_v * 2.5, i3_cap)
    # ضمان ترتيب تصاعدي صارم فوق السعر
    inv_tp1 = max(inv_tp1, price + atr_v * 1.0)
    inv_tp2 = max(inv_tp2, inv_tp1 + atr_v * 0.8)
    inv_tp3 = max(inv_tp3, inv_tp2 + atr_v * 0.8)

    inv_bt = backtest_long(h, l, c, horizon="investor", rr=2.5)

    # ── التوقّع الاحتمالي (نموذج احتمالي، أفق ~35 يوماً) ─────────
    inv_fc = forecast_probabilistic(c, price, inv_stop, inv_tp1, horizon_days=35, v=v)

    score = max(0, min(10, score))

    return {
        "score": score, "signals": signals,
        "entry_note": inv_entry_note,
        "stop": inv_stop, "stop_pct": inv_stop_pct,
        "stop_method": stop_method, "invalidation": inv_stop,
        "tp1": inv_tp1, "tp2": inv_tp2, "tp3": inv_tp3,
        "rr": (inv_tp1 - price) / inv_risk if inv_risk > 0 else 0,
        "horizon": T("أسابيع — أشهر","Weeks — months"),
        "bt_trades": inv_bt["trades"], "bt_winrate": inv_bt["winrate"],
        "bt_avgR": inv_bt["avgR"], "confidence": inv_bt["conf"],
        "forecast": inv_fc,
    }
    """
    وقف خسارة احترافي — 4 طبقات بالأولوية:

    1. أقرب دعم تحت السعر مباشرة (الأفضل)
    2. أدنى آخر شمعة (Low of last candle)
    3. ATR×0.5 فقط — محدود بـ 8% كحد أقصى
    4. حد أقصى إجباري 8% إذا كل الطرق فشلت
    """
    candidates = []

    # ── الطبقة 1: أقرب دعم تحت السعر ────────────────────────
    if supports:
        for sup in supports[:3]:
            dist_pct = (price - sup) / price * 100
            # الدعم المثالي: 2% - 8% تحت السعر
            if 1.5 <= dist_pct <= 8.0:
                candidates.append(("Support", sup * 0.995, dist_pct))

    # ── الطبقة 2: Low آخر 3 شمعات ───────────────────────────
    recent_low = float(min(l[-3:]))
    dist_low   = (price - recent_low) / price * 100
    if 1.0 <= dist_low <= 10.0:
        candidates.append(("Recent Low", recent_low * 0.998, dist_low))

    # ── الطبقة 3: ATR × 0.5 (ضيق) ──────────────────────────
    atr_stop     = price - (atr_v * 0.5)
    atr_dist_pct = (price - atr_stop) / price * 100
    if atr_dist_pct <= 8.0:
        candidates.append(("ATR×0.5", atr_stop, atr_dist_pct))

    # ── الطبقة 4: ATR × 1.0 (متوسط) ─────────────────────────
    atr1_stop     = price - atr_v
    atr1_dist_pct = (price - atr1_stop) / price * 100
    if atr1_dist_pct <= 8.0:
        candidates.append(("ATR×1.0", atr1_stop, atr1_dist_pct))

    # ── اختر الأقرب للسعر ضمن نطاق 1.5% - 8% ───────────────
    valid = [c2 for c2 in candidates if 1.5 <= c2[2] <= 8.0]

    if valid:
        # الأقرب للسعر = أضيق وقف = أفضل R:R
        best = min(valid, key=lambda x: x[2])
        return best[0], best[1], best[2]

    # ── حد أقصى إجباري: 8% ──────────────────────────────────
    forced = price * 0.92
    return "Max 8%", forced, 8.0


def analyze(sym: str, silent=False) -> dict:
    sym = sym.upper().strip()
    result = {"sym": sym, "score": 0, "direction": "", "patterns": [], "entry": 0, "stop": 0, "tp1": 0}

    try:
        tk = yf.Ticker(sym)
        with contextlib.redirect_stderr(io.StringIO()):
            df = tk.history(period="3mo", interval="1d")
        # تنظيف البيانات من الصفوف الفارغة (NaN) التي تُفسد آخر سعر
        if not df.empty:
            df = df.dropna(subset=["Open", "High", "Low", "Close"])
        if df.empty or len(df) < 20: return result

        o=df["Open"].values.astype(float); h=df["High"].values.astype(float)
        l=df["Low"].values.astype(float);  c=df["Close"].values.astype(float)
        v=np.nan_to_num(df["Volume"].values.astype(float))

        prev_close = float(c[-1])                      # آخر إغلاق يومي (للمؤشرات)
        # السعر اللحظي: Finnhub/Alpaca (إن توفّر مفتاح) ثم yfinance، وإلا آخر إغلاق
        live = get_live_price(sym)
        if not (live and np.isfinite(live) and live > 0):
            try:
                with contextlib.redirect_stderr(io.StringIO()):
                    fi = getattr(tk, "fast_info", None)
                    if fi is not None:
                        live = fi.get("last_price") if hasattr(fi, "get") else getattr(fi, "last_price", None)
            except Exception:
                live = None
        if not (live and np.isfinite(live) and live > 0):
            try:
                info0 = tk.info or {}
                live = info0.get("currentPrice") or info0.get("regularMarketPrice")
            except Exception:
                live = None
        price = float(live) if (live and np.isfinite(live) and live > 0) else prev_close
        c[-1] = price                                  # استخدم السعر الحي كآخر نقطة
        # تحقّق نهائي: السعر يجب أن يكون رقماً صالحاً وموجباً
        if not np.isfinite(price) or price <= 0: return result
        ref = c[-2] if len(c) > 1 else prev_close
        price_chg = (price-ref)/ref*100 if (np.isfinite(ref) and ref > 0) else 0

        # المؤشرات
        rsi_v       = _rsi(c)
        e9,e21,e50  = _ema(c,9),_ema(c,21),_ema(c,50)
        e200        = _ema(c,200) if len(c)>=200 else _ema(c,len(c))
        atr_v       = _atr(h,l,c)
        _,_,macd_h  = _macd(c)
        bb_m,bb_u,bb_lo = _bb(c)

        # النماذج
        candles  = detect_candles(o,h,l,c)
        chart_p  = detect_chart_patterns(h,l,c,v)
        harmonics = detect_harmonic(h,l,c)
        supports, resistances, sup_zones, res_zones = smart_levels(o,h,l,c,v,price,atr_v)

        # مدارس التحليل (معمّقة)
        wyck, wyck_d = wyckoff_phase(c,v,h,l)
        dow  = dow_theory(c,h,l)
        ichi = ichimoku_signal(c,h,l)

        # المدارس الإضافية
        fib_data, fib_signal, fib_strength = fibonacci_levels(h, l, c, price)
        piv_data  = pivot_points(h, l, c)
        smc_data  = smart_money_concepts(h, l, c, v, price)

        # الأطر الزمنية
        mtf = multi_timeframe(sym)

        # الاتجاه الكلي
        above_e50  = price>e50; above_e200 = price>e200
        ema_cross  = e9>e21;    macd_bull  = macd_h>0; rsi_ok = 40<rsi_v<75
        bull_sig   = sum([above_e50,above_e200,ema_cross,macd_bull,rsi_ok,price_chg>0])
        mtf_bull   = sum(1 for v2 in mtf.values() if "🟢" in v2.get("trend",""))

        bull_candles = sum(1 for _,d,*_ in candles if d=="BULLISH")
        bear_candles = sum(1 for _,d,*_ in candles if d=="BEARISH")
        bull_charts  = sum(1 for _,d,*_ in chart_p if d=="BULLISH")
        bear_charts  = sum(1 for _,d,*_ in chart_p if d=="BEARISH")

        total_bull = bull_sig + mtf_bull + bull_candles*2 + bull_charts*2
        total_bear = (6-bull_sig) + bear_candles*2 + bear_charts*2

        # إضافة نقاط المدارس الجديدة
        total_bull += fib_strength
        total_bull += piv_data["strength"]
        total_bull += smc_data["strength"]

        if total_bull > total_bear+3: direction="📈 صاعد قوي";  dir_c="bold green"; dir_disp=T("صاعد قوي","Strong Up")
        elif total_bull > total_bear: direction="📈 صاعد";        dir_c="green";      dir_disp=T("صاعد","Up")
        elif total_bear > total_bull+3: direction="📉 هابط قوي"; dir_c="bold red";   dir_disp=T("هابط قوي","Strong Down")
        else:                           direction="↔️ محايد";      dir_c="yellow";     dir_disp=T("محايد","Neutral")
        dir_icon = direction.split()[0]

        is_bullish = total_bull >= total_bear
        score = min(10, total_bull if is_bullish else total_bear)

        # ══ خطة التداول الاحترافية ══════════════════════════════
        stop_method, stop_loss, stop_pct = smart_stop_loss(price, h, l, c, supports, atr_v)

        # منطقة الدخول: انتظر pullback بسيط
        entry_ideal  = price             # الدخول اللحظي
        entry_lo     = price * 0.997     # أفضل دخول: -0.3%
        entry_hi     = price * 1.003     # حد الدخول: +0.3%

        risk = price - stop_loss
        if risk <= 0: risk = price * 0.03

        # أهداف الربح مبنية على R:R وأقرب مقاومة
        tp1 = price + risk * 1.5
        tp2 = price + risk * 2.5
        tp3 = price + risk * 4.0

        # إذا وجد مقاومة قريبة — استخدمها كـ TP1
        if resistances:
            r1_dist = (resistances[0] - price) / price * 100
            if 2.0 <= r1_dist <= 15.0:
                tp1 = resistances[0] * 0.995   # أسفل المقاومة قليلاً
            if len(resistances) >= 2:
                r2_dist = (resistances[1] - price) / price * 100
                if r2_dist <= 25.0:
                    tp2 = resistances[1] * 0.995

        rr_ratio = (tp2 - price) / risk if risk > 0 else 0

        result.update({
            "score": score, "direction": direction, "entry": price,
            "stop": stop_loss, "tp1": tp1, "tp2": tp2, "tp3": tp3,
            "stop_method": stop_method, "stop_pct": stop_pct,
            "patterns": [n for n,*_ in candles]+[n for n,*_ in chart_p],
            "chg": price_chg,
            "details": {
                "indicators": {
                    "rsi": float(rsi_v), "ema9": float(e9), "ema21": float(e21),
                    "ema50": float(e50), "ema200": float(e200), "macd_h": float(macd_h),
                    "bb_u": float(bb_u), "bb_lo": float(bb_lo), "atr": float(atr_v),
                },
                "supports":    [float(x) for x in supports[:4]],
                "resistances": [float(x) for x in resistances[:4]],
                "sup_zones": sup_zones, "res_zones": res_zones,
                "volume_profile": volume_profile(h, l, c, v, lookback=min(220, len(c)), bins=60),
                "mtf": mtf,
                "schools": {
                    "dow": dow, "wyckoff": f"{wyck} — {wyck_d}", "ichimoku": ichi,
                    "smc": (smc_data.get("signals", [])[:3] if isinstance(smc_data, dict) else []),
                },
                "bull_pts": int(total_bull), "bear_pts": int(total_bear),
                "pattern_detail":
                    [{"name":n,"type":T("شمعة","Candle"),"dir":d,"strength":s,"desc":ds} for n,d,s,ds in candles]
                  + [{"name":n,"type":T("شارت","Chart"),"dir":d,"strength":s,"desc":ds,
                      "brk":(float(rest[0]) if len(rest)>0 and rest[0] else None),
                      "stop":(float(rest[1]) if len(rest)>1 and rest[1] else None),
                      "target":(float(rest[2]) if len(rest)>2 and rest[2] else None)}
                     for n,d,s,ds,*rest in chart_p]
                  + harmonics,
            },
        })

        # ══════════════════════════════════════════════════════
        #  تقييم المضارب والمستثمر — يُحسب دائماً حتى في الوضع الصامت
        #  حتى تحصل مقارنة المحفظة على درجات المضارب/المستثمر و R:R
        # ══════════════════════════════════════════════════════
        trader   = score_trader(sym, price, o, h, l, c, v, supports, resistances,
                                rsi_v, e9, e21, e50, atr_v, macd_h, bb_u, bb_lo,
                                candles, chart_p, mtf)
        investor = score_investor(sym, price, h, l, c, v, supports, resistances,
                                  rsi_v, e50, e200, atr_v, macd_h, candles, chart_p)
        result["_trader"]   = trader
        result["_investor"] = investor

        if silent: return result

        def entry_verdict(ts, is_, direction):
            bull = "صاعد" in direction; bear = "هابط" in direction
            if not bull and not bear:
                return "⏳",T("انتظر — السوق محايد","Wait — market neutral"),"yellow",T("لا توجد إشارة واضحة","no clear signal")
            if bull:
                if ts>=7 and is_>=7: return "✅",T("مناسب للمضارب والمستثمر","Good for trader & investor"),"bold green",T("إشارة قوية من كلا الأسلوبين","strong on both styles")
                elif ts>=7:          return "⚡",T("مناسب للمضاربة اليومية","Good for day trading"),"green",T("زخم قوي قصير المدى","strong short-term momentum")
                elif is_>=7:         return "📈",T("مناسب للاستثمار","Good for investing"),"green",T("اتجاه طويل المدى قوي","strong long-term trend")
                elif ts>=5 or is_>=5: return "◑",T("فرصة مقبولة — كن حذراً","Fair setup — be careful"),"yellow",T("إشارات جيدة لكن ليست مثالية","decent but not ideal")
                else:                return "✗",T("غير مناسب الآن","Not suitable now"),"red",T("الإشارات ضعيفة","weak signals")
            return "✗",T("تجنب — اتجاه هابط","Avoid — downtrend"),"red",T("لا تدخل ضد الاتجاه","don't trade against trend")

        vi, vt, vc, vw = entry_verdict(trader["score"], investor["score"], direction)
        chg_c  = "green" if price_chg >= 0 else "red"
        vol_m  = v[-1]/1e6 if v[-1]>=1e6 else v[-1]/1e3
        vol_s  = f"{vol_m:.1f}M" if v[-1]>=1e6 else f"{vol_m:.0f}K"
        ema_cross  = e9>e21; above_e50=price>e50; above_e200=price>e200; macd_bull=macd_h>0
        W = "═"*78

        # ── 1. شريط السهم الرئيسي ────────────────────────────
        console.print()
        console.print(f"[bold cyan]{W}[/bold cyan]")
        console.print(
            f"  [bold white]{sym}[/bold white]"
            f"   [bold yellow]${price:.2f}[/bold yellow]"
            f"   [{chg_c}]{price_chg:+.2f}%[/{chg_c}]"
            f"   [dim]{T('حجم','Vol')}: {vol_s}[/dim]"
            f"   [dim]ATR: ${atr_v:.2f}[/dim]"
            f"   [{dir_c}]{dir_icon} {dir_disp}[/{dir_c}]"
            f"   [yellow]◈ {T('قوة الإشارة','Signal')}: {score}/10[/yellow]"
        )
        console.print(f"  [bold {vc}]{vi}  {vt}[/bold {vc}]   [dim]{vw}[/dim]")
        console.print(f"[bold cyan]{W}[/bold cyan]")

        # ── 2. المؤشرات الفنية ───────────────────────────────
        console.print()
        console.print(f"  [bold cyan]📊 {T('المؤشرات الفنية','Technical Indicators')}[/bold cyan]")

        def sig(cond, yes_txt, no_txt):
            return f"[green]{yes_txt}[/green]" if cond else f"[red]{no_txt}[/red]"

        def rsi_sig(r):
            if r>75: return f"[red]{T('مشبع شراء','Overbought')} ⚠[/red]"
            if r<30: return f"[green]{T('مشبع بيع','Oversold')} ✅[/green]"
            if r>55: return f"[green]{T('قوي','Strong')} ✅[/green]"
            if r<45: return f"[red]{T('ضعيف','Weak')}[/red]"
            return f"[yellow]{T('محايد','Neutral')}[/yellow]"

        itbl = Table(show_header=True, header_style="bold cyan", box=box.SQUARE,
                     pad_edge=False, show_lines=False, expand=False)
        itbl.add_column(T("المؤشر","Indicator"), style="dim", no_wrap=True)
        itbl.add_column(T("القيمة","Value"), justify="left", style="white", no_wrap=True)
        itbl.add_column(T("الحالة","Status"), justify="left", no_wrap=True)
        itbl.add_column(T("ملاحظة","Note"), justify="left", style="dim", no_wrap=True)

        def pr(label, val, signal, note=""):
            itbl.add_row(label, str(val), signal, note)

        pr("RSI (14)",   f"{rsi_v:.1f}",                    rsi_sig(rsi_v),        T("70+ بيع | 30- شراء","70+ sell | 30- buy"))
        pr("EMA 9/21",   f"{e9:.2f} / {e21:.2f}",           sig(ema_cross,T("تقاطع ذهبي","Golden cross")+" ✅",T("تقاطع موت","Death cross")+" ❌"),  T("اتجاه قصير المدى","short-term trend"))
        pr("EMA 50",     f"${e50:.2f}",                      sig(above_e50,T("السعر فوقه","Price above")+" ✅",T("السعر تحته","Price below")+" ❌"), T("اتجاه متوسط المدى","mid-term trend"))
        pr("EMA 200",    f"${e200:.2f}",                     sig(above_e200,"Uptrend ✅","Downtrend ❌"),    T("الاتجاه العام","overall trend"))
        pr("MACD",       f"{macd_h:+.4f}",                   sig(macd_bull,T("إيجابي","Positive")+" ✅",T("سلبي","Negative")+" ❌"),           T("زخم السعر","price momentum"))
        pr("BB Upper",   f"${bb_u:.2f}",
           f"[yellow]⚠ {T('قرب الذروة','Near top')}[/yellow]" if price>bb_u*0.97 else f"[dim]{T('طبيعي','Normal')}[/dim]",
           f"{T('يبعد','away')} {(bb_u-price)/price*100:.1f}%")
        pr("BB Lower",   f"${bb_lo:.2f}",
           f"[green]✅ {T('قرب القاع','Near bottom')}[/green]" if price<bb_lo*1.03 else f"[dim]{T('طبيعي','Normal')}[/dim]",
           f"{T('يبعد','away')} {(price-bb_lo)/price*100:.1f}%")
        pr("ATR (14)",   f"${atr_v:.2f}",
           f"[{'red' if atr_v/price>0.04 else 'green'}]{('⚠ '+T('مرتفع','High')) if atr_v/price>0.04 else ('✅ '+T('طبيعي','Normal'))}[/{'red' if atr_v/price>0.04 else 'green'}]",
           f"{atr_v/price*100:.1f}% {T('من السعر','of price')}")
        console.print(itbl)

        # ── 3. الدعم والمقاومة ───────────────────────────────
        console.print()
        console.print(f"  [bold yellow]🧱 {T('الدعم والمقاومة','Support & Resistance')}  +  Fibonacci  +  Pivot Points[/bold yellow]")

        srtbl = Table(show_header=True, header_style="bold yellow", box=box.SQUARE,
                      pad_edge=False, show_lines=False, expand=False)
        srtbl.add_column(T("المستوى","Level"), no_wrap=True)
        srtbl.add_column(T("السعر","Price"), justify="right", no_wrap=True)
        srtbl.add_column(T("البُعد","Dist"), justify="right", no_wrap=True)
        srtbl.add_column(T("النوع","Type"), no_wrap=True)

        def sr_line(tag, price_v, dist_v, ntype, color):
            srtbl.add_row(f"[{color}]{tag}[/{color}]", f"[{color}]${price_v:.2f}[/{color}]",
                          f"[{color}]{dist_v}[/{color}]", f"[{color}]{ntype}[/{color}]")

        for i, rv in enumerate(resistances[:3]):
            sr_line(f"{T('مقاومة','Resistance')} {i+1}", rv, f"+{(rv-price)/price*100:.1f}%", "Classic", "red")

        if isinstance(fib_data, dict) and fib_data.get("resistance"):
            fn, fv = fib_data["resistance"]
            fd = (fv-price)/price*100
            if 0 < fd <= 20:
                sr_line(f"Fib {fn}", fv, f"+{fd:.1f}%", "Fibonacci", "yellow")

        for pname, pval in [("Pivot R1", piv_data["r1"]),("FP-R1", piv_data["fp_r1"])]:
            pd_ = (pval-price)/price*100
            if 0 < pd_ <= 15:
                sr_line(pname, pval, f"+{pd_:.1f}%", "Pivot", "cyan"); break

        srtbl.add_row(f"[bold yellow]▶ {T('السعر الآن','Price now')}[/bold yellow]", f"[bold yellow]${price:.2f}[/bold yellow]", "", "")

        for pname, pval in [("Pivot S1", piv_data["s1"]),("FP-S1", piv_data["fp_s1"])]:
            pd_ = (price-pval)/price*100
            if 0 < pd_ <= 15:
                sr_line(pname, pval, f"-{pd_:.1f}%", "Pivot", "cyan"); break

        if isinstance(fib_data, dict) and fib_data.get("support"):
            fn, fv = fib_data["support"]
            fd = (price-fv)/price*100
            if 0 < fd <= 20:
                sr_line(f"Fib {fn}", fv, f"-{fd:.1f}%", "Fibonacci", "yellow")

        for i, sv in enumerate(supports[:3]):
            sr_line(f"{T('دعم','Support')} {i+1}", sv, f"-{(price-sv)/price*100:.1f}%", "Classic", "green")

        console.print(srtbl)

        # ── 4. مدارس التحليل ─────────────────────────────────
        console.print()
        console.print(f"  [bold blue]📚 {T('مدارس التحليل الفني','Analysis Schools')}[/bold blue]")
        console.print(f"  [dim]{'─'*74}[/dim]")

        schools = [
            (T("داو","Dow"),  dow),
            ("Wyckoff",    f"{wyck}  [dim]{wyck_d}[/dim]"),
            ("Ichimoku",   ichi),
        ]
        if isinstance(fib_data, dict) and fib_data.get("signal"):
            schools.append(("Fibonacci", fib_data["signal"]))
        schools.append(("Pivot",     piv_data.get("signal","—")))
        if smc_data.get("signals"):
            for i, sig_s in enumerate(smc_data["signals"][:3]):
                schools.append(("SMC" if i==0 else "", sig_s))

        for name, val in schools:
            console.print(
                f"  [cyan]{name:<14}[/cyan]"
                f"[white]{val}[/white]" if name else
                f"  [dim]{'':<14}[/dim]{val}"
            )

        # ── 5. الأطر الزمنية ─────────────────────────────────
        console.print()
        console.print(f"  [bold blue]⏱  {T('الأطر الزمنية','Timeframes')}[/bold blue]")
        tftbl = Table(show_header=True, header_style="bold blue", box=box.SQUARE,
                      pad_edge=False, show_lines=False, expand=False)
        tftbl.add_column(T("الإطار","TF"), no_wrap=True)
        tftbl.add_column(T("الاتجاه","Trend"), no_wrap=True)
        tftbl.add_column("RSI", justify="center", no_wrap=True)
        tftbl.add_column("EMA", justify="center", no_wrap=True)
        tftbl.add_column("MACD", justify="center", no_wrap=True)
        tftbl.add_column(T("القوة","Strength"), no_wrap=True)
        for lbl, d2 in mtf.items():
            tc = "green" if "🟢" in d2["trend"] else ("red" if "🔴" in d2["trend"] else "yellow")
            ec = "green" if d2["ema9"]>d2["ema21"] else "red"
            mc = "green" if d2["macd_h"]>0 else "red"
            trend_txt = d2["trend"]
            if LANG == "en":
                trend_txt = ("🟢 Up" if "🟢" in d2["trend"] else ("🔴 Down" if "🔴" in d2["trend"] else "🟡 Neutral"))
            bar = "[cyan]" + "█"*d2["bull"] + "[/cyan][dim]" + "░"*(5-d2["bull"]) + f"[/dim] {d2['bull']}/5"
            tftbl.add_row(
                f"[bold]{lbl}[/bold]",
                f"[{tc}]{trend_txt}[/{tc}]",
                f"[{tc}]{d2['rsi']:.0f}[/{tc}]",
                f"[{ec}]{'▲'+T('ذهبي','Gold') if d2['ema9']>d2['ema21'] else '▼'+T('موت','Death')}[/{ec}]",
                f"[{mc}]{'▲'+T('إيجابي','Pos') if d2['macd_h']>0 else '▼'+T('سلبي','Neg')}[/{mc}]",
                bar,
            )
        console.print(tftbl)

        # ── 6. النماذج الفنية ────────────────────────────────
        all_pats = [(n,T("شمعة","Candle"),dr,st,ds) for n,dr,st,ds in candles] + \
                   [(n,T("شارت","Chart"),dr,st,ds) for n,dr,st,ds,*_ in chart_p]
        if all_pats:
            console.print()
            console.print(f"  [bold magenta]🕯  {T('النماذج الفنية المكتشفة','Detected Patterns')}[/bold magenta]")
            ptbl = Table(show_header=True, header_style="bold magenta", box=box.SQUARE,
                         pad_edge=False, show_lines=False, expand=False)
            ptbl.add_column(T("النموذج","Pattern"), no_wrap=True)
            ptbl.add_column(T("النوع","Type"), no_wrap=True)
            ptbl.add_column(T("الاتجاه","Direction"), no_wrap=True)
            ptbl.add_column(T("القوة","Strength"), no_wrap=True)
            ptbl.add_column(T("التفسير","Meaning"), style="dim")
            for nm, typ, dr, st, ds in all_pats:
                dc  = "green" if dr=="BULLISH" else ("red" if dr=="BEARISH" else "yellow")
                dar = T("صاعد","Bullish")+" 📈" if dr=="BULLISH" else (T("هابط","Bearish")+" 📉" if dr=="BEARISH" else T("محايد","Neutral")+" ↔")
                stars = "★"*st + "☆"*(5-st)
                pst = PATTERN_STATS.get(nm, {})
                wrv = pst.get("win", pst.get("win_rate",0))
                ds_full = f"{ds}  {T('فوز','win')}:{wrv}%" if pst else ds
                ptbl.add_row(
                    f"[bold {dc}]{nm}[/bold {dc}]",
                    typ,
                    f"[{dc}]{dar}[/{dc}]",
                    f"[yellow]{stars}[/yellow]",
                    ds_full,
                )
            console.print(ptbl)

        # ── 7. خطة التداول ───────────────────────────────────
        console.print()
        console.print(f"  [bold cyan]{'─'*78}[/bold cyan]")

        # المضارب والمستثمر جنباً لجنب
        t_sc  = "bold green" if trader["score"]>=7 else ("yellow" if trader["score"]>=5 else "red")
        i_sc  = "bold green" if investor["score"]>=7 else ("yellow" if investor["score"]>=5 else "red")
        t_stc = "green" if trader["stop_pct"]<=2.5 else ("yellow" if trader["stop_pct"]<=4 else "red")
        i_stc = "green" if investor["stop_pct"]<=10 else ("yellow" if investor["stop_pct"]<=15 else "red")

        def rr_color(rr, score, fc):
            if score <= 3: return "yellow"
            if fc and fc.get("ok"):
                ev = fc["p_target"]/100.0*rr - fc["p_stop"]/100.0
                if ev <= 0: return "red"
                if ev >= 1.0 and rr >= 2: return "bold green"
                if ev >= 0.4: return "green"
                return "yellow"
            return "bold green" if rr >= 2 else ("yellow" if rr >= 1.5 else "red")

        t_rrc = rr_color(trader["rr"],   trader["score"],   trader.get("forecast"))
        i_rrc = rr_color(investor["rr"], investor["score"], investor.get("forecast"))

        def rr_label(rr, score, fc):
            # R:R وحده مضلِّل: هدف بعيد جداً يعطي نسبة عالية باحتمال شبه معدوم.
            # الحكم يوازن الدرجة + احتمال بلوغ الهدف (نموذج احتمالي) = التوقع الرياضي.
            if score <= 3:
                return T(f"نظري — الدرجة {score}/10 ضعيفة ⚠️", f"Theoretical — score {score}/10 weak ⚠️")
            if fc and fc.get("ok"):
                ev = fc["p_target"]/100.0*rr - fc["p_stop"]/100.0
                if ev <= 0:
                    return T(f"سلبي — احتمال الهدف {fc['p_target']:.0f}% فقط ⚠️",
                             f"Negative — only {fc['p_target']:.0f}% target chance ⚠️")
                if ev >= 1.0 and rr >= 2.0: return T(f"ممتاز (توقّع +{ev:.1f}R) ✅", f"Excellent (EV +{ev:.1f}R) ✅")
                if ev >= 0.4:               return T(f"جيد (توقّع +{ev:.1f}R) ✅", f"Good (EV +{ev:.1f}R) ✅")
                return T(f"مقبول (توقّع +{ev:.1f}R)", f"Fair (EV +{ev:.1f}R)")
            if rr >= 2.5: return T("ممتاز ✅", "Excellent ✅")
            if rr >= 2.0: return T("جيد جداً ✅", "Very good ✅")
            if rr >= 1.5: return T("مقبول", "Fair")
            return T("ضعيف ⚠️", "Weak ⚠️")

        # صف العناوين
        console.print(
            f"  [bold yellow]⚡ {T('المضارب اليومي','Day Trader')}[/bold yellow]  [{t_sc}]{trader['score']}/10[/{t_sc}]"
            f"   [dim]{trader['horizon']}[/dim]"
            f"{'':>10}"
            f"[bold magenta]📈 {T('المستثمر طويل المدى','Long-term Investor')}[/bold magenta]  [{i_sc}]{investor['score']}/10[/{i_sc}]"
            f"   [dim]{investor['horizon']}[/dim]"
        )
        console.print(f"  [dim]{'─'*35}{'':8}{'─'*35}[/dim]")
        entry_note       = trader.get("entry_note", T("دخول عند السعر الحالي","entry at current price"))
        entry_note_short = investor["entry_note"].replace("الدخول المثالي: ","").replace("الدخول: ","")

        console.print(
            f"  [dim]{T('منطقة الدخول','Entry zone'):<16}[/dim][cyan]${trader['entry_lo']:.2f}[/cyan]"
            f"   [dim]{entry_note}[/dim]"
        )
        console.print(
            f"  [dim]{T('دخول المستثمر','Investor entry'):<16}[/dim][cyan]${price:.2f}[/cyan]"
            f"   [dim]{entry_note_short}[/dim]"
        )
        console.print(
            f"\n  [dim]{T('وقف المضارب','Trader stop'):<16}[/dim][{t_stc}]${trader['stop']:.2f}[/{t_stc}]"
            f"   [{t_stc}]-{trader['stop_pct']:.1f}%[/{t_stc}]   [dim]{trader.get('stop_method','')}[/dim]"
        )
        console.print(
            f"  [dim]{T('وقف المستثمر','Investor stop'):<16}[/dim][{i_stc}]${investor['stop']:.2f}[/{i_stc}]"
            f"   [{i_stc}]-{investor['stop_pct']:.1f}%[/{i_stc}]   [dim]{investor.get('stop_method','')}[/dim]"
        )
        console.print(f"\n  [dim]{'─'*70}[/dim]")
        console.print(f"  [dim]{'':4}{T('المضارب اليومي','Day Trader'):<30}{T('المستثمر طويل المدى','Long-term Investor')}[/dim]")
        console.print(f"  [dim]{'─'*70}[/dim]")

        tp1_t_pct = (trader['tp1']-trader['entry_lo'])/trader['entry_lo']*100 if trader['entry_lo']>0 else 0
        tp2_t_pct = (trader['tp2']-trader['entry_lo'])/trader['entry_lo']*100 if trader['entry_lo']>0 else 0
        tp1_i_pct = (investor['tp1']-price)/price*100 if price>0 else 0
        tp2_i_pct = (investor['tp2']-price)/price*100 if price>0 else 0
        tp3_i_pct = (investor['tp3']-price)/price*100 if price>0 else 0

        console.print(
            f"  [dim]{T('الهدف الأول','Target 1')}  [/dim][green]${trader['tp1']:.2f}[/green]"
            f"  [green]+{tp1_t_pct:.1f}%[/green] [dim]← {T('اخرج','exit')} 70%[/dim]"
            f"{'':12}"
            f"[green]${investor['tp1']:.2f}[/green]"
            f"  [green]+{tp1_i_pct:.1f}%[/green] [dim]← {T('بيع','sell')} 40%[/dim]"
        )
        console.print(
            f"  [dim]{T('الهدف الثاني','Target 2')} [/dim][green]${trader['tp2']:.2f}[/green]"
            f"  [green]+{tp2_t_pct:.1f}%[/green] [dim]← {T('ابقِ','keep')} 30%[/dim]"
            f"{'':12}"
            f"[green]${investor['tp2']:.2f}[/green]"
            f"  [green]+{tp2_i_pct:.1f}%[/green] [dim]← {T('بيع','sell')} 40%[/dim]"
        )
        console.print(
            f"  [dim]{'':13}[/dim]"
            f"{'':37}"
            f"[green]${investor['tp3']:.2f}[/green]"
            f"  [green]+{tp3_i_pct:.1f}%[/green] [dim]← {T('ابقِ','keep')} 20%[/dim]"
        )
        console.print(f"  [dim]{'─'*70}[/dim]")
        console.print(
            f"  [dim]{T('R:R المضارب','Trader R:R'):<16}[/dim][{t_rrc}]1 : {trader['rr']:.1f}   {rr_label(trader['rr'], trader['score'], trader.get('forecast'))}[/{t_rrc}]"
            f"{'':16}[dim]{T('R:R المستثمر','Investor R:R')}[/dim]  [{i_rrc}]1 : {investor['rr']:.1f}   {rr_label(investor['rr'], investor['score'], investor.get('forecast'))}[/{i_rrc}]"
        )

        # ── 8. التوصية النهائية ──────────────────────────────
        console.print()
        console.print(f"  [bold {vc}]{W}[/bold {vc}]")
        detail_hint = T(f"اكتب '{sym} +' للتفاصيل", f"type '{sym} +' for details")
        console.print(
            f"  [bold {vc}]{vi}  {vt}[/bold {vc}]   [dim]{vw}[/dim]"
            f"   [dim]{T('صاعد','bull')}:{total_bull}  {T('هابط','bear')}:{total_bear}  {T('قوة','strength')}:{score}/10[/dim]"
            f"   [dim]{detail_hint}[/dim]"
        )
        console.print(f"  [bold {vc}]{W}[/bold {vc}]")
        console.print()

        # حفظ البيانات
        result["_trader"]   = trader
        result["_investor"] = investor
        result["_detailed_data"] = {
            "rsi_v":rsi_v,"e9":e9,"e21":e21,"e50":e50,"e200":e200,
            "macd_h":macd_h,"bb_u":bb_u,"bb_lo":bb_lo,"atr_v":atr_v,
            "candles":candles,"chart_p":chart_p,"supports":supports,
            "resistances":resistances,"mtf":mtf,"wyck":wyck,"wyck_d":wyck_d,
            "dow":dow,"ichi":ichi,"price_chg":price_chg,"vol_s":vol_s,
            "stop_loss":stop_loss,"stop_pct":stop_pct,"stop_method":stop_method,
            "tp1":tp1,"tp2":tp2,"tp3":tp3,"risk":risk,"rr_ratio":rr_ratio,
            "total_bull":total_bull,"total_bear":total_bear,"score":score,
            "direction":direction,"dir_c":dir_c,
            "fib_data":fib_data,"piv_data":piv_data,"smc_data":smc_data,
        }

        # Telegram
        if score >= MIN_SCAN_SCORE and TELEGRAM_TOKEN:
            tg = (f"🔔 <b>{sym}</b> — {direction} ({score}/10)\n"
                  f"السعر: ${price:.2f}  {price_chg:+.2f}%\n\n"
                  f"⚡ المضارب: دخول ${trader['entry_lo']:.2f} | وقف ${trader['stop']:.2f} | هدف ${trader['tp1']:.2f}\n"
                  f"📈 المستثمر: {investor['entry_note']}\n"
                  f"R:R = 1:{trader['rr']:.1f}")
            send_telegram(tg)

    except Exception as e:
        if not silent: console.print(f"[red]❌ Error {sym}: {e}[/red]")

    return result

def show_details(r: dict):
    """عرض التحليل التفصيلي الكامل عند طلب المستخدم"""
    if not r or not r.get("_detailed_data"):
        console.print("[red]لا توجد بيانات تفصيلية — حلّل السهم أولاً[/red]")
        return

    d       = r["_detailed_data"]
    trader  = r.get("_trader", {})
    investor= r.get("_investor", {})
    sym     = r["sym"]
    price   = r["entry"]

    console.print(f"\n[bold cyan]{'═'*68}[/bold cyan]")
    console.print(f"  [bold white]تحليل تفصيلي كامل — {sym}[/bold white]")
    console.print(f"[bold cyan]{'═'*68}[/bold cyan]")

    # ── الأطر الزمنية ────────────────────────────────────────
    mtf = d.get("mtf", {})
    if mtf:
        console.print(f"\n  [bold blue]⏱ الأطر الزمنية[/bold blue]")
        console.print(f"  {'الإطار':<10}{'الاتجاه':<16}{'RSI':<8}{'EMA9/21':<20}{'MACD':<10}{'القوة'}")
        console.print(f"  {'─'*68}")
        for lbl, d2 in mtf.items():
            tc = "green" if "🟢" in d2["trend"] else ("red" if "🔴" in d2["trend"] else "yellow")
            ms = "▲ إيجابي" if d2["macd_h"]>0 else "▼ سلبي"
            bar= "█"*d2["bull"]+"░"*(5-d2["bull"])
            console.print(
                f"  [bold]{lbl:<10}[/bold]"
                f"[{tc}]{d2['trend']:<16}[/{tc}]"
                f"{d2['rsi']:<8.0f}"
                f"[{'green' if d2['ema9']>d2['ema21'] else 'red'}]{d2['ema9']:.2f}/{d2['ema21']:.2f}[/{'green' if d2['ema9']>d2['ema21'] else 'red'}]{'':6}"
                f"[{'green' if d2['macd_h']>0 else 'red'}]{ms:<10}[/{'green' if d2['macd_h']>0 else 'red'}]"
                f"[cyan]{bar}[/cyan]"
            )

    # ── المؤشرات ──────────────────────────────────────────────
    console.print(f"\n  [bold cyan]📊 المؤشرات الفنية[/bold cyan]")
    console.print(f"  {'المؤشر':<14}{'القيمة':<14}{'الإشارة':<26}{'ملاحظة'}")
    console.print(f"  {'─'*68}")
    rsi_v=d["rsi_v"]; e9=d["e9"]; e21=d["e21"]; e50=d["e50"]; e200=d["e200"]
    macd_h=d["macd_h"]; bb_u=d["bb_u"]; bb_lo=d["bb_lo"]; atr_v=d["atr_v"]
    ema_cross=e9>e21; above_e50=price>e50; above_e200=price>e200; macd_bull=macd_h>0
    rows_ind = [
        ("RSI(14)",  f"{rsi_v:.1f}",
         "[red]مشبع شراء⚠️[/red]" if rsi_v>75 else ("[green]مشبع بيع✅[/green]" if rsi_v<25 else ("[green]قوي✅[/green]" if rsi_v>55 else "[yellow]محايد[/yellow]")),
         "منطقة بيع" if rsi_v>75 else ("منطقة شراء" if rsi_v<25 else ("زخم صاعد" if rsi_v>55 else "محايد"))),
        ("EMA 9/21", f"{e9:.2f}/{e21:.2f}",
         "[green]تقاطع ذهبي✅[/green]" if ema_cross else "[red]تقاطع موت❌[/red]",
         "صاعد" if ema_cross else "هابط"),
        ("EMA 50",   f"${e50:.2f}",
         "[green]فوقه✅[/green]" if above_e50 else "[red]تحته❌[/red]", "اتجاه متوسط"),
        ("EMA 200",  f"${e200:.2f}",
         "[green]Uptrend✅[/green]" if above_e200 else "[red]Downtrend❌[/red]", "الاتجاه العام"),
        ("MACD",     f"{macd_h:+.4f}",
         "[green]إيجابي✅[/green]" if macd_bull else "[red]سلبي❌[/red]", "الزخم"),
        ("BB Upper", f"${bb_u:.2f}",
         "[yellow]قرب الحد العلوي⚠️[/yellow]" if price>bb_u*0.97 else "[dim]طبيعي[/dim]",
         f"يبعد {(bb_u-price)/price*100:.1f}%"),
        ("BB Lower", f"${bb_lo:.2f}",
         "[green]قرب الحد السفلي✅[/green]" if price<bb_lo*1.03 else "[dim]طبيعي[/dim]",
         f"يبعد {(price-bb_lo)/price*100:.1f}%"),
        ("ATR(14)",  f"${atr_v:.2f}",
         f"[{'red' if atr_v/price>0.04 else 'green'}]{'مرتفع⚠️' if atr_v/price>0.04 else 'طبيعي✅'}[/{'red' if atr_v/price>0.04 else 'green'}]",
         f"{atr_v/price*100:.1f}% من السعر"),
    ]
    for ind,val,sig,note in rows_ind:
        console.print(f"  [dim]{ind:<14}[/dim][white]{val:<14}[/white]{sig}  [dim]{note}[/dim]")

    # ── مدارس التحليل ─────────────────────────────────────────
    console.print(f"\n  [bold blue]📚 مدارس التحليل الفني[/bold blue]")
    console.print(f"  {'─'*60}")
    console.print(f"  [cyan]نظرية داو: [/cyan] {d['dow']}")
    console.print(f"  [cyan]Wyckoff:   [/cyan] {d['wyck']} — {d['wyck_d']}")
    console.print(f"  [cyan]Ichimoku:  [/cyan] {d['ichi']}")

    # ── النماذج التفصيلية ─────────────────────────────────────
    candles=d["candles"]; chart_p=d["chart_p"]
    all_pats=[(n,"شمعة",dr,st,ds) for n,dr,st,ds in candles] + \
             [(n,"شارت",dr,st,ds) for n,dr,st,ds,*_ in chart_p]
    if all_pats:
        console.print(f"\n  [bold magenta]🕯 النماذج المكتشفة — تفصيلي[/bold magenta]")
        console.print(f"  {'النموذج':<26}{'النوع':<10}{'الاتجاه':<14}{'القوة':<12}{'نسبة الفوز':<12}{'التوقع'}")
        console.print(f"  {'─'*80}")
        for nm,typ,dr,st,ds in all_pats:
            dc="green" if dr=="BULLISH" else ("red" if dr=="BEARISH" else "yellow")
            dr_ar="صاعد📈" if dr=="BULLISH" else ("هابط📉" if dr=="BEARISH" else "محايد↔️")
            stars="★"*st+"☆"*(5-st)
            pst=PATTERN_STATS.get(nm,{})
            wr_v=pst.get("win",pst.get("win_rate",0)); ag_v=pst.get("gain",pst.get("avg_gain",0)); ls_v=pst.get("loss",pst.get("avg_loss",0))
            wr=f"{wr_v}%" if pst else "—"
            ev=wr_v/100*ag_v-(1-wr_v/100)*ls_v if pst else 0
            ev_s=f"[{'green' if ev>0 else 'red'}]{'+' if ev>0 else ''}{ev:.1f}%[/{'green' if ev>0 else 'red'}]" if pst else "—"
            console.print(f"  [bold]{nm:<26}[/bold][dim]{typ:<10}[/dim][{dc}]{dr_ar:<14}[/{dc}][yellow]{stars:<12}[/yellow][{'green' if pst and wr_v>=60 else 'yellow'}]{wr:<12}[/{'green' if pst and wr_v>=60 else 'yellow'}]{ev_s}")
            console.print(f"  [dim]  └─ {ds}[/dim]")

    # ── الدعم والمقاومة ───────────────────────────────────────
    supports=d["supports"]; resistances=d["resistances"]
    console.print(f"\n  [bold yellow]🧱 الدعم والمقاومة التفصيلي[/bold yellow]")
    for i,rv in enumerate(resistances[:3]):
        dist=(rv-price)/price*100; bar="░"*min(int(dist),20)
        console.print(f"  [red]  م{i+1}  ${rv:.2f}  +{dist:.1f}%  {bar}[/red]")
    console.print(f"  [bold yellow]▶▶ ${price:.2f} ← السعر الحالي[/bold yellow]")
    for i,sv in enumerate(supports[:3]):
        dist=(price-sv)/price*100; bar="░"*min(int(dist),20)
        console.print(f"  [green]  د{i+1}  ${sv:.2f}  -{dist:.1f}%  {bar}[/green]")

    # ── خطة التداول التفصيلية للمضارب ────────────────────────
    if trader:
        console.print(f"\n  [bold yellow]⚡ خطة المضارب اليومي — تفصيلية[/bold yellow]")
        console.print(f"  {'─'*60}")
        console.print(f"  لماذا هذه الإشارات؟")
        for sig in trader.get("signals",[]):
            console.print(f"    [dim]•[/dim] {sig}")
        console.print(f"\n  الدخول: [cyan]${trader['entry_lo']:.2f} — ${trader['entry_hi']:.2f}[/cyan]")
        sc="green" if trader["stop_pct"]<=2 else ("yellow" if trader["stop_pct"]<=3.5 else "red")
        console.print(f"  الوقف:  [{sc}]${trader['stop']:.2f}[/{sc}]  (-{trader['stop_pct']:.1f}%)  [dim]أساسه: Low آخر شمعتين[/dim]")
        console.print(f"  الهدف1: [green]${trader['tp1']:.2f}[/green]  (+{(trader['tp1']-price)/price*100:.1f}%)  [dim]← اخرج بـ 70%[/dim]")
        console.print(f"  الهدف2: [green]${trader['tp2']:.2f}[/green]  (+{(trader['tp2']-price)/price*100:.1f}%)  [dim]← ابقِ 30%[/dim]")
        rrc="bold green" if trader["rr"]>=2 else ("yellow" if trader["rr"]>=1.5 else "red")
        console.print(f"  [{rrc}]R:R = 1:{trader['rr']:.1f}[/{rrc}]  |  الأفق: {trader['horizon']}")
        fct = trader.get("forecast", {})
        if fct.get("ok"):
            pc = "green" if fct["p_target"] >= 55 else ("yellow" if fct["p_target"] >= 45 else "red")
            console.print(
                f"  [dim]🎲 توقّع احتمالي ({fct['horizon']} يوم):[/dim] "
                f"[{pc}]بلوغ الهدف {fct['p_target']:.0f}%[/{pc}] | الوقف {fct['p_stop']:.0f}% | "
                f"بلا حسم {fct['p_neither']:.0f}% | حركة متوقّعة ±{fct['exp_move_pct']:.1f}%"
            )

    # ── خطة التداول التفصيلية للمستثمر ──────────────────────
    if investor:
        console.print(f"\n  [bold magenta]📈 خطة المستثمر — تفصيلية[/bold magenta]")
        console.print(f"  {'─'*60}")
        console.print(f"  لماذا هذه الإشارات؟")
        for sig in investor.get("signals",[]):
            console.print(f"    [dim]•[/dim] {sig}")
        console.print(f"\n  {investor['entry_note']}")
        sc="green" if investor["stop_pct"]<=10 else ("yellow" if investor["stop_pct"]<=15 else "red")
        console.print(f"  الوقف:  [{sc}]${investor['stop']:.2f}[/{sc}]  (-{investor['stop_pct']:.1f}%)  [dim]تحت EMA50 أو الدعم الرئيسي[/dim]")
        console.print(f"  الهدف1: [green]${investor['tp1']:.2f}[/green]  (+{(investor['tp1']-price)/price*100:.1f}%)  [dim]← بيع 40%[/dim]")
        console.print(f"  الهدف2: [green]${investor['tp2']:.2f}[/green]  (+{(investor['tp2']-price)/price*100:.1f}%)  [dim]← بيع 40%[/dim]")
        console.print(f"  الهدف3: [green]${investor['tp3']:.2f}[/green]  (+{(investor['tp3']-price)/price*100:.1f}%)  [dim]← ابقِ 20%[/dim]")
        rrc="bold green" if investor["rr"]>=2 else ("yellow" if investor["rr"]>=1.5 else "red")
        console.print(f"  [{rrc}]R:R = 1:{investor['rr']:.1f}[/{rrc}]  |  الأفق: {investor['horizon']}")
        fci = investor.get("forecast", {})
        if fci.get("ok"):
            pc = "green" if fci["p_target"] >= 55 else ("yellow" if fci["p_target"] >= 45 else "red")
            console.print(
                f"  [dim]🎲 توقّع احتمالي ({fci['horizon']} يوم):[/dim] "
                f"[{pc}]بلوغ الهدف {fci['p_target']:.0f}%[/{pc}] | الوقف {fci['p_stop']:.0f}% | "
                f"بلا حسم {fci['p_neither']:.0f}% | حركة متوقّعة ±{fci['exp_move_pct']:.1f}%"
            )

    console.print(f"\n[bold cyan]{'═'*68}[/bold cyan]\n")


# ══════════════════════════════════════════════════════════════
#  مسح 200 سهم تلقائياً
# ══════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════
#  معلومات الشركة — مقارنة المحفظة
# ══════════════════════════════════════════════════════════════

def get_live_price(sym):
    """
    السعر اللحظي من مصدر رسمي إن توفّر مفتاح: Finnhub ثم Alpaca.
    يرجع float أو None (فيتراجع البرنامج إلى yfinance/آخر إغلاق).
    """
    sym = sym.upper().strip()
    if FINNHUB_KEY:
        try:
            url = f"https://finnhub.io/api/v1/quote?symbol={urllib.parse.quote(sym)}&token={FINNHUB_KEY}"
            with urllib.request.urlopen(url, timeout=6) as resp:
                d = json.loads(resp.read().decode())
            p = d.get("c")                       # current price
            if p and float(p) > 0: return float(p)
        except Exception:
            pass
    if ALPACA_KEY and ALPACA_SECRET:
        try:
            url = f"https://data.alpaca.markets/v2/stocks/{urllib.parse.quote(sym)}/trades/latest"
            req = urllib.request.Request(url, headers={
                "APCA-API-KEY-ID": ALPACA_KEY,
                "APCA-API-SECRET-KEY": ALPACA_SECRET,
            })
            with urllib.request.urlopen(req, timeout=6) as resp:
                d = json.loads(resp.read().decode())
            p = (d.get("trade") or {}).get("p")
            if p and float(p) > 0: return float(p)
        except Exception:
            pass
    return None


def validate_company_info(d):
    """
    طبقة تحقّق من سلامة البيانات (Data Integrity) — معيار أساسي في الأنظمة المؤسسية:
    ترفض القيم المستحيلة/الشاذة (مثل P/S=31390)، تضمن إيجابية القيم العددية،
    تصحّح التناقضات (52w، الأسهم الحرة)، وتبني مؤشّر جودة بيانات + قائمة تنبيهات.
    """
    flags = []
    def clamp(key, lo, hi, label=None):
        v = d.get(key)
        if v is None: return
        try: v = float(v)
        except (TypeError, ValueError): d[key] = None; return
        if (not np.isfinite(v)) or v < lo or v > hi:
            d[key] = None; flags.append(label or key)
        else: d[key] = v
    def positive(key, label=None):
        v = d.get(key)
        if v is None: return
        try: v = float(v)
        except (TypeError, ValueError): d[key] = None; return
        if (not np.isfinite(v)) or v <= 0:
            d[key] = None; flags.append(label or key)
        else: d[key] = v

    clamp("pe_trail", -2000, 5000, "P/E"); clamp("pe_fwd", -2000, 5000, "Fwd P/E")
    clamp("pb", 0, 500, "P/B"); clamp("ps", 0, 500, "P/S")
    clamp("peg", -100, 100, "PEG"); clamp("ev_ebitda", -500, 2000, "EV/EBITDA")
    clamp("roe", -10, 10, "ROE"); clamp("roa", -10, 10, "ROA")
    clamp("profit_m", -50, 50); clamp("gross_m", -5, 5); clamp("op_m", -50, 50, "Op Margin")
    clamp("rev_growth", -1, 50, "Rev Growth"); clamp("earn_growth", -50, 50)
    clamp("beta", -10, 10, "Beta")
    clamp("short_pct", 0, 1, "Short %"); clamp("insiders", 0, 1, "Insiders")
    clamp("institutions", 0, 1, "Institutions"); clamp("div_yield", 0, 1)
    for k, lbl in [("mktcap","Market Cap"),("shares","Shares"),("float_sh","Free Float"),
                   ("volume","Volume"),("avg_vol","Avg Volume"),("price","Price"),
                   ("high52","52W High"),("low52","52W Low"),("prev_close","Prev Close")]:
        positive(k, lbl)
    # تصحيح تناقضات منطقية
    if d.get("high52") and d.get("low52") and d["high52"] < d["low52"]:
        d["high52"], d["low52"] = d["low52"], d["high52"]
    if d.get("float_sh") and d.get("shares") and d["float_sh"] > d["shares"] * 1.02:
        d["float_sh"] = d["shares"]
    # مؤشّر جودة البيانات
    core = ["price","mktcap","sector","pe_trail","ps","roe","rev_growth","volume","high52","low52"]
    present = sum(1 for k in core if d.get(k) not in (None, "", "غير محدد", "—"))
    d["data_quality"] = {"score": round(present / len(core) * 100), "flags": sorted(set(flags))}
    return d


def institutional_activity(sym: str) -> dict:
    """
    نشاط التملّك المؤسسي: النسبة الحالية + اتجاه التغيّر خلال آخر ربع
    (كم مالكاً زاد مقابل من خفّض، وصافي تغيّر الأسهم) من جدول كبار الملّاك.
    """
    out = {"inst_pct": None, "insider_pct": None, "direction": None,
           "increased": 0, "decreased": 0, "net_shares": None,
           "avg_change": None, "as_of": None}
    try:
        t = yf.Ticker(sym)
        info = {}
        try: info = t.info
        except Exception: info = {}
        out["inst_pct"]    = info.get("heldPercentInstitutions")
        out["insider_pct"] = info.get("heldPercentInsiders")
    except Exception:
        pass
    try:
        ih = yf.Ticker(sym).institutional_holders
        if ih is not None and len(ih) > 0:
            pc_col = sh_col = dt_col = None
            for k in ih.columns:
                kl = str(k).lower()
                if pc_col is None and "change" in kl: pc_col = k
                if sh_col is None and kl in ("shares", "# shares"): sh_col = k
                if dt_col is None and "date" in kl: dt_col = k
            if pc_col is not None:
                ch = ih[pc_col].dropna().astype(float)
                if len(ch) > 0:
                    out["increased"] = int((ch > 0).sum())
                    out["decreased"] = int((ch < 0).sum())
                    out["avg_change"] = float(ch.mean())
                    if sh_col is not None:
                        sh = ih[sh_col].fillna(0).astype(float)
                        # صافي الأسهم المضافة ≈ Σ shares*pctChange/(1+pctChange)
                        net = float((sh * ch / (1.0 + ch)).sum())
                        out["net_shares"] = net
                    m = out["avg_change"]
                    out["direction"] = "increase" if m > 0.002 else ("decrease" if m < -0.002 else "flat")
            if dt_col is not None:
                try: out["as_of"] = str(ih[dt_col].iloc[0])[:10]
                except Exception: pass
    except Exception:
        pass
    return out


def get_company_info(sym: str) -> dict:
    """يجلب معلومات مالية كاملة عن الشركة"""
    try:
        tk   = yf.Ticker(sym)
        info = tk.info or {}

        # ── بيانات أساسية ──────────────────────────────────────
        name     = info.get("longName") or info.get("shortName") or sym
        sector   = info.get("sector", "غير محدد")
        industry = info.get("industry", "غير محدد")
        country  = info.get("country", "—")
        website  = info.get("website", "—")
        desc     = (info.get("longBusinessSummary") or "")[:300]

        # ── التقييم ────────────────────────────────────────────
        pe_trail  = info.get("trailingPE")
        pe_fwd    = info.get("forwardPE")
        pb        = info.get("priceToBook")
        ps        = info.get("priceToSalesTrailing12Months")
        peg       = info.get("pegRatio")
        ev_ebitda = info.get("enterpriseToEbitda")

        # ── الربحية ────────────────────────────────────────────
        eps_trail = info.get("trailingEps")
        eps_fwd   = info.get("forwardEps")
        roe       = info.get("returnOnEquity")
        roa       = info.get("returnOnAssets")
        profit_m  = info.get("profitMargins")
        gross_m   = info.get("grossMargins")
        op_m      = info.get("operatingMargins")

        # ── النمو ──────────────────────────────────────────────
        rev_growth   = info.get("revenueGrowth")
        earn_growth  = info.get("earningsGrowth")
        earn_q_growth= info.get("earningsQuarterlyGrowth")

        # ── الميزانية ──────────────────────────────────────────
        total_cash    = info.get("totalCash")
        total_debt    = info.get("totalDebt")
        current_ratio = info.get("currentRatio")
        debt_equity   = info.get("debtToEquity")
        free_cf       = info.get("freeCashflow")
        op_cf         = info.get("operatingCashflow")
        revenue       = info.get("totalRevenue")
        net_income    = info.get("netIncomeToCommon")

        # ── السوق ──────────────────────────────────────────────
        mktcap    = info.get("marketCap")
        shares    = info.get("sharesOutstanding")
        float_sh  = info.get("floatShares")
        short_pct = info.get("shortPercentOfFloat")
        insiders     = info.get("heldPercentInsiders")
        institutions = info.get("heldPercentInstitutions")
        beta      = info.get("beta")
        div_yield = info.get("dividendYield")
        div_rate  = info.get("dividendRate")
        payout    = info.get("payoutRatio")

        # ── 52w ────────────────────────────────────────────────
        high52  = info.get("fiftyTwoWeekHigh")
        low52   = info.get("fiftyTwoWeekLow")
        avg50   = info.get("fiftyDayAverage")
        avg200  = info.get("twoHundredDayAverage")
        price   = info.get("currentPrice") or info.get("regularMarketPrice")
        volume     = info.get("volume") or info.get("regularMarketVolume")
        avg_vol    = info.get("averageVolume") or info.get("averageDailyVolume10Day")
        prev_close = info.get("previousClose") or info.get("regularMarketPreviousClose")
        day_high   = info.get("dayHigh") or info.get("regularMarketDayHigh")
        day_low    = info.get("dayLow") or info.get("regularMarketDayLow")

        # ── تحليل المحللين ─────────────────────────────────────
        target_mean = info.get("targetMeanPrice")
        target_high = info.get("targetHighPrice")
        target_low  = info.get("targetLowPrice")
        rec         = info.get("recommendationKey", "—")
        num_analysts= info.get("numberOfAnalystOpinions")

        return validate_company_info({
            "name": name, "sector": sector, "industry": industry,
            "country": country, "website": website, "desc": desc,
            "pe_trail": pe_trail, "pe_fwd": pe_fwd, "pb": pb,
            "ps": ps, "peg": peg, "ev_ebitda": ev_ebitda,
            "eps_trail": eps_trail, "eps_fwd": eps_fwd,
            "roe": roe, "roa": roa,
            "profit_m": profit_m, "gross_m": gross_m, "op_m": op_m,
            "rev_growth": rev_growth, "earn_growth": earn_growth,
            "earn_q_growth": earn_q_growth,
            "total_cash": total_cash, "total_debt": total_debt,
            "current_ratio": current_ratio, "debt_equity": debt_equity,
            "free_cf": free_cf, "op_cf": op_cf,
            "revenue": revenue, "net_income": net_income,
            "mktcap": mktcap, "beta": beta, "shares": shares,
            "float_sh": float_sh, "short_pct": short_pct,
            "insiders": insiders, "institutions": institutions,
            "div_yield": div_yield, "div_rate": div_rate, "payout": payout,
            "high52": high52, "low52": low52,
            "avg50": avg50, "avg200": avg200, "price": price,
            "volume": volume, "avg_vol": avg_vol, "prev_close": prev_close,
            "day_high": day_high, "day_low": day_low,
            "target_mean": target_mean, "target_high": target_high,
            "target_low": target_low, "rec": rec,
            "num_analysts": num_analysts,
        })
    except Exception as e:
        return {"name": sym, "error": str(e)}


def show_company(sym: str):
    """يعرض معلومات الشركة بشكل احترافي"""
    sym = sym.upper().strip()
    console.print(f"\n[dim]⟳ جاري جلب بيانات {sym}...[/dim]")

    info = get_company_info(sym)
    if "error" in info and not info.get("name"):
        console.print(f"[red]❌ خطأ: {info['error']}[/red]")
        return

    W = "═"*78
    price = info.get("price", 0) or 0

    # ── هيدر الشركة ──────────────────────────────────────────
    console.print()
    console.print(f"[bold cyan]{W}[/bold cyan]")
    console.print(f"  [bold white]{sym}[/bold white]   [bold yellow]{info['name']}[/bold yellow]")
    console.print(f"  [cyan]القطاع:[/cyan] {info['sector']}   [cyan]النشاط:[/cyan] {info['industry']}   [cyan]الدولة:[/cyan] {info['country']}")
    if info.get("desc"):
        desc = info["desc"]
        console.print(f"  [dim]{desc}...[/dim]")
    console.print(f"[bold cyan]{W}[/bold cyan]")

    def fmt_num(v, suffix="", pct=False, b=False):
        if v is None: return "[dim]—[/dim]"
        if pct:  return f"{v*100:.1f}%"
        if b:
            if abs(v) >= 1e9:  return f"${v/1e9:.2f}B"
            if abs(v) >= 1e6:  return f"${v/1e6:.1f}M"
            return f"${v:,.0f}"
        return f"{v:.2f}{suffix}"

    def color_val(v, good_if_high=True, warn_thresh=None, bad_thresh=None):
        if v is None: return "[dim]—[/dim]"
        if bad_thresh and (v > bad_thresh if good_if_high else v < bad_thresh):
            return f"[red]{v:.2f}[/red]"
        if warn_thresh and (v < warn_thresh if good_if_high else v > warn_thresh):
            return f"[yellow]{v:.2f}[/yellow]"
        return f"[green]{v:.2f}[/green]"

    def pr2(l1, v1, l2, v2):
        console.print(f"  [dim]{l1:<22}[/dim]{v1:<28}[dim]{l2:<22}[/dim]{v2}")

    # ── 1. التقييم ───────────────────────────────────────────
    console.print()
    console.print("  [bold yellow]💰 مؤشرات التقييم[/bold yellow]")
    console.print(f"  [dim]{'─'*74}[/dim]")

    pe_str  = color_val(info["pe_trail"], good_if_high=False, warn_thresh=30, bad_thresh=50) if info["pe_trail"] else "[dim]—[/dim]"
    pef_str = color_val(info["pe_fwd"],   good_if_high=False, warn_thresh=25, bad_thresh=40) if info["pe_fwd"] else "[dim]—[/dim]"
    pb_str  = color_val(info["pb"],       good_if_high=False, warn_thresh=3,  bad_thresh=8)  if info["pb"] else "[dim]—[/dim]"
    peg_str = color_val(info["peg"],      good_if_high=False, warn_thresh=1.5,bad_thresh=2.5)if info["peg"] else "[dim]—[/dim]"

    pr2("مكرر الأرباح (P/E)", pe_str,
        "مكرر الأرباح المتوقع", pef_str)
    pr2("مكرر القيمة الدفترية (P/B)", pb_str,
        "PEG Ratio", peg_str)
    pr2("EV/EBITDA", fmt_num(info["ev_ebitda"]),
        "السعر/المبيعات (P/S)", fmt_num(info["ps"]))
    pr2("EPS الفعلي", fmt_num(info["eps_trail"],"$"),
        "EPS المتوقع", fmt_num(info["eps_fwd"],"$"))

    # ── 2. الربحية ───────────────────────────────────────────
    console.print()
    console.print("  [bold green]📈 مؤشرات الربحية[/bold green]")
    console.print(f"  [dim]{'─'*74}[/dim]")

    def pct_color(v, good_thresh=0.10, warn_thresh=0.05):
        if v is None: return "[dim]—[/dim]"
        pv = v*100
        if pv >= good_thresh*100: return f"[green]{pv:.1f}%[/green]"
        if pv >= warn_thresh*100: return f"[yellow]{pv:.1f}%[/yellow]"
        return f"[red]{pv:.1f}%[/red]"

    pr2("هامش الربح الصافي",  pct_color(info["profit_m"], 0.10, 0.05),
        "هامش الربح الإجمالي", pct_color(info["gross_m"],  0.30, 0.15))
    pr2("هامش التشغيل",       pct_color(info["op_m"],     0.15, 0.08),
        "العائد على الأصول",   pct_color(info["roa"],      0.05, 0.02))
    pr2("العائد على الملكية",  pct_color(info["roe"],      0.15, 0.08),
        "نمو الإيرادات",       pct_color(info["rev_growth"],0.10, 0.05))
    pr2("نمو الأرباح السنوي",  pct_color(info["earn_growth"],0.10, 0.0),
        "نمو الأرباح الفصلي",  pct_color(info["earn_q_growth"],0.10, 0.0))

    # ── 3. الميزانية والسيولة ────────────────────────────────
    console.print()
    console.print("  [bold cyan]🏦 الميزانية والسيولة[/bold cyan]")
    console.print(f"  [dim]{'─'*74}[/dim]")

    cr = info["current_ratio"]
    cr_str = f"[green]{cr:.2f}x[/green]" if cr and cr>=2 else (f"[yellow]{cr:.2f}x[/yellow]" if cr and cr>=1 else (f"[red]{cr:.2f}x[/red]" if cr else "[dim]—[/dim]"))
    de = info["debt_equity"]
    de_str = f"[green]{de:.1f}%[/green]" if de and de<=50 else (f"[yellow]{de:.1f}%[/yellow]" if de and de<=150 else (f"[red]{de:.1f}%[/red]" if de else "[dim]—[/dim]"))

    pr2("إجمالي النقد",        fmt_num(info["total_cash"],b=True),
        "إجمالي الديون",       fmt_num(info["total_debt"],b=True))
    pr2("نسبة السيولة",        cr_str,
        "الدين/حقوق الملكية",  de_str)
    pr2("التدفق النقدي الحر",  fmt_num(info["free_cf"],b=True),
        "التدفق النقدي التشغيلي", fmt_num(info["op_cf"],b=True))
    pr2("الإيرادات السنوية",   fmt_num(info["revenue"],b=True),
        "صافي الدخل",          fmt_num(info["net_income"],b=True))

    # ── 4. السوق والأداء ─────────────────────────────────────
    console.print()
    console.print("  [bold purple]📊 بيانات السوق[/bold purple]")
    console.print(f"  [dim]{'─'*74}[/dim]")

    # 52 أسبوع
    if info["high52"] and info["low52"] and price:
        pct_from_high = (price - info["high52"]) / info["high52"] * 100
        pct_from_low  = (price - info["low52"])  / info["low52"]  * 100
        bar_pos = int((price - info["low52"]) / (info["high52"] - info["low52"]) * 20) if info["high52"]!=info["low52"] else 10
        bar = "[green]"+"█"*bar_pos+"[/green][dim]"+"░"*(20-bar_pos)+"[/dim]"
        console.print(
            f"  [dim]52 أسبوع:[/dim]  "
            f"[red]${info['low52']:.2f}[/red]  {bar}  [red]${info['high52']:.2f}[/red]"
            f"   السعر الحالي: [yellow]${price:.2f}[/yellow]"
            f"   [dim]({pct_from_high:+.1f}% من الذروة)[/dim]"
        )

    mktcap_str = fmt_num(info["mktcap"], b=True)
    beta_str = f"[green]{info['beta']:.2f}[/green]" if info["beta"] and info["beta"]<1.2 else (f"[yellow]{info['beta']:.2f}[/yellow]" if info["beta"] and info["beta"]<1.8 else (f"[red]{info['beta']:.2f}[/red]" if info["beta"] else "[dim]—[/dim]"))
    short_str = f"[red]{info['short_pct']*100:.1f}%[/red]" if info["short_pct"] and info["short_pct"]>0.10 else (f"[dim]{info['short_pct']*100:.1f}%[/dim]" if info["short_pct"] else "[dim]—[/dim]")

    pr2("القيمة السوقية",      mktcap_str,
        "بيتا (تذبذب السوق)", beta_str)
    pr2("نسبة البيع على المكشوف", short_str,
        "عائد التوزيعات",     f"[green]{info['div_yield']*100:.2f}%[/green]" if info.get("div_yield") else "[dim]لا يوزع[/dim]")

    # ── 5. توصيات المحللين ───────────────────────────────────
    if info.get("target_mean") and info.get("num_analysts"):
        console.print()
        console.print("  [bold white]🎯 توصيات المحللين[/bold white]")
        console.print(f"  [dim]{'─'*74}[/dim]")

        rec_map = {
            "strong_buy": "[bold green]شراء قوي 🟢🟢[/bold green]",
            "buy":        "[green]شراء 🟢[/green]",
            "hold":       "[yellow]احتفاظ 🟡[/yellow]",
            "underperform":"[red]ضعيف الأداء 🔴[/red]",
            "sell":       "[bold red]بيع 🔴🔴[/bold red]",
        }
        rec_str = rec_map.get(info["rec"], f"[dim]{info['rec']}[/dim]")
        upside = (info["target_mean"] - price) / price * 100 if price else 0

        pr2("توصية المحللين",    rec_str,
            "عدد المحللين",      str(info["num_analysts"] or "—"))
        pr2("متوسط السعر المستهدف", f"[bold white]${info['target_mean']:.2f}[/bold white]  [dim]({upside:+.1f}%)[/dim]",
            "أعلى هدف / أدنى هدف", f"[green]${info['target_high']:.2f}[/green] / [red]${info['target_low']:.2f}[/red]")

    console.print(f"\n[bold cyan]{W}[/bold cyan]\n")


def _fmt_big(n):
    """يصيغ الأرقام الكبيرة: 12.3M / 1.4B"""
    if n is None: return "—"
    try: n = float(n)
    except: return "—"
    for unit, div in (("B", 1e9), ("M", 1e6), ("K", 1e3)):
        if abs(n) >= div: return f"{n/div:.1f}{unit}"
    return f"{n:.0f}"

def score_financials(info: dict) -> int:
    """
    درجة مالية 0–10 من الأساسيات المتاحة.
    نسبية — مفيدة للمقارنة بين أسهم المحفظة لا للحكم المطلق.
    """
    s = 5.0
    roe   = info.get("roe");          eg   = info.get("earn_growth")
    rg    = info.get("rev_growth");   de   = info.get("debt_equity")
    pe    = info.get("pe_trail");     fcf  = info.get("free_cf")
    inst  = info.get("institutions"); short = info.get("short_pct")
    if roe  is not None: s += 2 if roe > 0.15 else (1 if roe > 0 else (-2 if roe < -0.2 else -1))
    if eg   is not None: s += 1.5 if eg > 0.15 else (0.5 if eg > 0 else -1)
    if rg   is not None: s += 1 if rg > 0.15 else (0.5 if rg > 0 else -0.5)
    if de   is not None: s += 1 if de < 50 else (-1 if de > 150 else 0)
    if pe   is not None and pe > 0: s += 1 if pe < 25 else (-1 if pe > 60 else 0)
    if fcf  is not None: s += 1 if fcf > 0 else -1
    if inst is not None: s += 0.5 if inst > 0.4 else 0
    if short is not None: s += -1 if short > 0.15 else 0
    return int(max(0, min(10, round(s))))


def compare_portfolio(syms: list):
    """
    يحلل محفظة أسهم ويقارنها ويرتبها
    يعطي أفضل سهم للمضارب وأفضل سهم للمستثمر
    """
    if not syms:
        console.print("[red]لا توجد أسهم للمقارنة[/red]")
        return

    console.print(Panel(
        f"[bold cyan]⚖️  {T('مقارنة المحفظة','Portfolio Comparison')} — {len(syms)} {T('سهم','stocks')}[/bold cyan]\n"
        f"[dim]{T('تحليل فني + مالي | أفضل للمضارب | أفضل للمستثمر','Technical + financial | best trader | best investor')}[/dim]",
        border_style="cyan"
    ))

    results = []
    no_data = []
    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
        BarColumn(), TextColumn("{task.completed}/{task.total}"),
        console=console
    ) as prog:
        task = prog.add_task(T("جاري التحليل...","Analyzing..."), total=len(syms))

        def _analyze_one(sym):
            try:
                r = analyze(sym, silent=True)
                info = get_company_info(sym)
                prog.advance(task)
                return {"sym": sym, "analysis": r, "info": info}
            except:
                prog.advance(task)
                return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
            futs = {ex.submit(_analyze_one, sym): sym for sym in syms}
            for fut in concurrent.futures.as_completed(futs):
                r = fut.result()
                if r and r["analysis"].get("entry", 0) > 0:
                    results.append(r)
                else:
                    no_data.append(r["sym"] if r else futs[fut])

    if not results:
        console.print(f"[red]{T('لم يتم تحليل أي سهم — لا توجد بيانات كافية','No stocks analyzed — insufficient data')}[/red]")
        if no_data:
            console.print(f"[yellow]{T('رموز بدون بيانات كافية','Symbols without enough data')}: {', '.join(no_data)}[/yellow]")
        return

    if no_data:
        console.print(f"[yellow]⚠️  {T('استُبعدت لعدم توفّر بيانات كافية','Excluded — insufficient data')}: {', '.join(no_data)}[/yellow]\n")

    # ── ترتيب للمضارب ────────────────────────────────────────
    for r in results:
        a = r["analysis"]
        tr = a.get("_trader", {})
        inv = a.get("_investor", {})
        r["trader_score"]   = tr.get("score", 0)
        r["investor_score"] = inv.get("score", 0)
        r["tech_score"]     = a.get("score", 0)
        r["trader_rr"]      = tr.get("rr", 0)
        r["investor_rr"]    = inv.get("rr", 0)
        r["trader_conf"]    = tr.get("confidence", 0)
        r["investor_conf"]  = inv.get("confidence", 0)
        r["fin_score"]      = score_financials(r["info"])

    # الترتيب: الدرجة الفنية أولاً، ثم ثقة الباكتيست التاريخية، ثم R:R
    trader_ranked   = sorted(results, key=lambda x: (x["trader_score"],   x["trader_conf"],   x["trader_rr"]),   reverse=True)
    investor_ranked = sorted(results, key=lambda x: (x["investor_score"], x["investor_conf"], x["investor_rr"]), reverse=True)

    W = "═"*78
    console.print()

    def _scol(val, hi=7, mid=5):
        return "bold green" if val >= hi else ("yellow" if val >= mid else "red")

    tbl = Table(show_header=True, header_style="bold cyan", box=box.SQUARE,
                pad_edge=False, show_lines=False, expand=False)
    tbl.add_column("#", justify="right", style="white")
    tbl.add_column(T("الرمز","Symbol"), justify="left", style="bold yellow")
    tbl.add_column(T("الشركة","Company"), justify="left", style="dim", max_width=24)
    tbl.add_column(T("القطاع","Sector"), justify="left", style="dim", max_width=16)
    tbl.add_column(T("تقني","Tech"),   justify="center")
    tbl.add_column(T("مضارب","Trade"),  justify="center")
    tbl.add_column(T("مستثمر","Invest"), justify="center")
    tbl.add_column(T("مالي","Fin"),   justify="center")
    tbl.add_column("R:R",    justify="center")
    tbl.add_column("P/E",    justify="center")

    for i, r in enumerate(sorted(results, key=lambda x: x["tech_score"], reverse=True), 1):
        info = r["info"]
        pe   = info.get("pe_trail")
        pe_s = f"{pe:.1f}" if pe else "—"
        rrv  = r["trader_rr"]
        rrc  = "bold green" if rrv >= 2 else ("yellow" if rrv >= 1.5 else "red")
        tbl.add_row(
            str(i), r["sym"],
            (info.get("name", "") or "")[:24],
            (info.get("sector", "") or "")[:16],
            f"[{_scol(r['tech_score'])}]{r['tech_score']}/10[/]",
            f"[{_scol(r['trader_score'])}]{r['trader_score']}/10[/]",
            f"[{_scol(r['investor_score'])}]{r['investor_score']}/10[/]",
            f"[{_scol(r['fin_score'])}]{r['fin_score']}/10[/]",
            f"[{rrc}]1:{rrv:.1f}[/]",
            pe_s,
        )
    console.print(tbl)

    # ── أفضل للمضارب ─────────────────────────────────────────
    console.print(f"\n[bold cyan]{W}[/bold cyan]")
    best_t = trader_ranked[0]
    at = best_t["analysis"]
    tr = at.get("_trader", {})
    if best_t["trader_score"] <= 0 or tr.get("entry_lo", 0) <= 0:
        console.print(
            f"  [yellow]⚡ {T('الأفضل للمضاربة اليومية','Best for day trading')}: "
            f"{T('لا يوجد مرشح صالح — لا توجد إشارات مضاربة واضحة','no valid candidate — no clear trade setups')}[/yellow]"
        )
    else:
        console.print(
            f"  [bold yellow]⚡ {T('الأفضل للمضاربة اليومية','Best for day trading')}:[/bold yellow]  "
            f"[bold white]{best_t['sym']}[/bold white]  "
            f"[dim]{best_t['info'].get('name','')[:30]}[/dim]\n"
            f"  {T('الدخول','Entry')}: [cyan]${tr.get('entry_lo',0):.2f} – ${tr.get('entry_hi',0):.2f}[/cyan]   "
            f"{T('الوقف','Stop')}: [red]${tr.get('stop',0):.2f}[/red] (-{tr.get('stop_pct',0):.1f}%) [dim]{tr.get('stop_method','')}[/dim]   "
            f"{T('الهدف','Target')}1: [green]${tr.get('tp1',0):.2f}[/green]   "
            f"{T('الهدف','Target')}2: [green]${tr.get('tp2',0):.2f}[/green]   "
            f"R:R: [bold green]1:{tr.get('rr',0):.1f}[/bold green]   "
            f"{T('درجة','Score')}: [bold yellow]{best_t['trader_score']}/10[/bold yellow]"
        )
        if tr.get("entry_trigger"):
            console.print(f"  [dim]{tr['entry_trigger']}  •  {T('الإبطال تحت','invalid below')} ${tr.get('invalidation',0):.2f}[/dim]")
        if tr.get("bt_trades"):
            bc = "green" if tr.get("bt_winrate",0) >= 50 else ("yellow" if tr.get("bt_winrate",0) >= 40 else "red")
            console.print(
                f"  [dim]📚 {T('الباكتيست','Backtest')} ({tr['bt_trades']} {T('صفقة','trades')}):[/dim] "
                f"[{bc}]{T('ربح','win')} {tr.get('bt_winrate',0):.0f}%[/{bc}] | "
                f"{T('متوسط','avg')} R {tr.get('bt_avgR',0):+.2f} | {T('ثقة','conf')} {tr.get('confidence',0)}/100"
            )
        else:
            console.print(f"  [dim]📚 {T('الباكتيست: لا توجد صفقات تاريخية كافية للتحقق','Backtest: not enough historical trades to verify')}[/dim]")
        fc = tr.get("forecast", {})
        if fc.get("ok"):
            pc = "green" if fc["p_target"] >= 55 else ("yellow" if fc["p_target"] >= 45 else "red")
            console.print(
                f"  [dim]🎲 {T('توقّع احتمالي','Forecast')} ({fc['horizon']} {T('يوم','d')}):[/dim] "
                f"[{pc}]{T('بلوغ الهدف','target')} {fc['p_target']:.0f}%[/{pc}] | {T('الوقف','stop')} {fc['p_stop']:.0f}% | "
                f"{T('بلا حسم','undecided')} {fc['p_neither']:.0f}% | {T('حركة متوقّعة','exp move')} ±{fc['exp_move_pct']:.1f}% "
                f"(${fc['band1'][0]:.2f}–${fc['band1'][1]:.2f})"
            )
        if tr.get("signals"):
            console.print(f"  [dim]{T('الأسباب','Reasons')}: {' | '.join(tr['signals'][:4])}[/dim]")

    # ── أفضل للمستثمر ────────────────────────────────────────
    console.print()
    best_i = investor_ranked[0]
    ai = best_i["analysis"]
    inv = ai.get("_investor", {})
    entry_i = ai.get("entry", 0) or 0
    if best_i["investor_score"] <= 0 or inv.get("tp1", 0) <= entry_i or entry_i <= 0:
        console.print(
            f"  [yellow]📈 {T('الأفضل للاستثمار طويل المدى','Best for long-term')}: "
            f"{T('لا يوجد مرشح صالح — لا توجد فرصة استثمارية واضحة','no valid candidate — no clear opportunity')}[/yellow]"
        )
    else:
        tp1_pct = (inv.get("tp1", 0) - entry_i) / entry_i * 100
        console.print(
            f"  [bold magenta]📈 {T('الأفضل للاستثمار طويل المدى','Best for long-term')}:[/bold magenta]  "
            f"[bold white]{best_i['sym']}[/bold white]  "
            f"[dim]{best_i['info'].get('name','')[:30]}[/dim]\n"
            f"  {T('الدخول','Entry')}: [cyan]{inv.get('entry_note','—')}[/cyan]   "
            f"{T('الوقف','Stop')}: [red]${inv.get('stop',0):.2f}[/red] (-{inv.get('stop_pct',0):.1f}%)   "
            f"{T('الهدف','Target')}1: [green]${inv.get('tp1',0):.2f}[/green] ({tp1_pct:+.1f}%)   "
            f"R:R: [bold green]1:{inv.get('rr',0):.1f}[/bold green]   "
            f"{T('درجة','Score')}: [bold yellow]{best_i['investor_score']}/10[/bold yellow]"
        )
        if inv.get("stop_method") or inv.get("invalidation"):
            console.print(f"  [dim]{T('الوقف','Stop')}: {inv.get('stop_method','')}  •  {T('الإبطال تحت','invalid below')} ${inv.get('invalidation',0):.2f}[/dim]")
        if inv.get("bt_trades"):
            bc = "green" if inv.get("bt_winrate",0) >= 50 else ("yellow" if inv.get("bt_winrate",0) >= 40 else "red")
            console.print(
                f"  [dim]📚 {T('الباكتيست','Backtest')} ({inv['bt_trades']} {T('صفقة','trades')}):[/dim] "
                f"[{bc}]{T('ربح','win')} {inv.get('bt_winrate',0):.0f}%[/{bc}] | "
                f"{T('متوسط','avg')} R {inv.get('bt_avgR',0):+.2f} | {T('ثقة','conf')} {inv.get('confidence',0)}/100"
            )
        else:
            console.print(f"  [dim]📚 {T('الباكتيست: لا توجد صفقات تاريخية كافية للتحقق','Backtest: not enough historical trades to verify')}[/dim]")
        fc = inv.get("forecast", {})
        if fc.get("ok"):
            pc = "green" if fc["p_target"] >= 55 else ("yellow" if fc["p_target"] >= 45 else "red")
            console.print(
                f"  [dim]🎲 {T('توقّع احتمالي','Forecast')} ({fc['horizon']} {T('يوم','d')}):[/dim] "
                f"[{pc}]{T('بلوغ الهدف','target')} {fc['p_target']:.0f}%[/{pc}] | {T('الوقف','stop')} {fc['p_stop']:.0f}% | "
                f"{T('بلا حسم','undecided')} {fc['p_neither']:.0f}% | {T('حركة متوقّعة','exp move')} ±{fc['exp_move_pct']:.1f}% "
                f"(${fc['band1'][0]:.2f}–${fc['band1'][1]:.2f})"
            )
        if inv.get("signals"):
            console.print(f"  [dim]{T('الأسباب','Reasons')}: {' | '.join(inv['signals'][:4])}[/dim]")

    # ── الأفضل مالياً ────────────────────────────────────────
    console.print()
    fin_ranked = sorted(results, key=lambda x: x["fin_score"], reverse=True)
    best_f = fin_ranked[0]; fi = best_f["info"]
    def _p(x, d=1): return f"{x*100:.{d}f}%" if x is not None else "—"
    if best_f["fin_score"] <= 3:
        console.print(
            f"  [bold blue]🏦 {T('الأفضل مالياً','Best financially')}:[/bold blue]  [bold white]{best_f['sym']}[/bold white]  "
            f"[yellow]({T('درجة','score')} {best_f['fin_score']}/10 — {T('أساسيات المحفظة ضعيفة عموماً، هذا الأقل ضعفاً','portfolio fundamentals weak overall, this is least weak')})[/yellow]"
        )
    else:
        console.print(
            f"  [bold blue]🏦 {T('الأفضل مالياً','Best financially')}:[/bold blue]  [bold white]{best_f['sym']}[/bold white]  "
            f"[dim]{(fi.get('name','') or '')[:30]}[/dim]  {T('درجة','score')} [bold blue]{best_f['fin_score']}/10[/bold blue]"
        )
    console.print(
        f"  [dim]{T('شراء المطّلعين','insiders')} {_p(fi.get('insiders'))} | {T('ملكية المؤسسات/الصناديق','institutions')} {_p(fi.get('institutions'))} | "
        f"{T('بيع مكشوف','short')} {_p(fi.get('short_pct'))} | {T('الأسهم الحرة','free float')} {_fmt_big(fi.get('float_sh'))}[/dim]"
    )

    # ── مقارنة مالية ─────────────────────────────────────────
    console.print(f"\n  [bold white]📊 {T('مقارنة مالية سريعة','Quick financial comparison')}:[/bold white]")
    ftbl = Table(show_header=True, header_style="bold white", box=box.SQUARE,
                 pad_edge=False, show_lines=False, expand=False)
    ftbl.add_column(T("الرمز","Sym"), style="bold yellow")
    ftbl.add_column(T("مالي","Fin"),    justify="center")
    ftbl.add_column("P/E",     justify="center")
    ftbl.add_column("ROE",     justify="center", no_wrap=True)
    ftbl.add_column(T("نمو","Growth"),     justify="center", no_wrap=True)
    ftbl.add_column(T("د/ملكية","D/E"), justify="center", no_wrap=True)
    ftbl.add_column(T("مطّلعون","Insiders"), justify="center", no_wrap=True)
    ftbl.add_column(T("مؤسسات","Instit."),  justify="center", no_wrap=True)
    ftbl.add_column(T("حرة","Float"),     justify="center", no_wrap=True)
    ftbl.add_column(T("توزيع","Div"),   justify="center", no_wrap=True)

    for r in fin_ranked:
        info = r["info"]
        pe = info.get("pe_trail"); roe = info.get("roe"); eg = info.get("earn_growth")
        de = info.get("debt_equity"); dy = info.get("div_yield")
        ins = info.get("insiders"); inst = info.get("institutions"); fl = info.get("float_sh")
        roe_c = ("green" if roe and roe > 0.15 else ("yellow" if roe and roe > 0 else "red")) if roe is not None else "dim"
        eg_c  = ("green" if eg and eg > 0.10 else ("yellow" if eg and eg > 0 else "red")) if eg is not None else "dim"
        fin_c = _scol(r["fin_score"])
        ftbl.add_row(
            r["sym"],
            f"[{fin_c}]{r['fin_score']}/10[/]",
            f"{pe:.1f}" if pe else "—",
            f"[{roe_c}]{_p(roe)}[/]",
            f"[{eg_c}]{_p(eg)}[/]",
            f"{de:.0f}%" if de else "—",
            _p(ins), _p(inst), _fmt_big(fl),
            f"{dy*100:.1f}%" if dy else "—",
        )
    console.print(ftbl)
    console.print()


def get_top_gainers(limit=200) -> tuple:
    """
    يجلب أعلى الأسهم ارتفاعاً اليوم
    المصدر 1: yfinance screener (الأحدث)
    المصدر 2: حساب يدوي على قائمة موسعة 500+ سهم
    """
    console.print("[dim]⟳ جاري جلب أعلى الأسهم ارتفاعاً اليوم...[/dim]")

    gainers = []

    # ── المصدر 1: yfinance EquityQuery ──────────────────────────
    try:
        from yfinance import EquityQuery
        q = EquityQuery('gt', ['percentchange', 3])
        result = yf.screen(q, sortField='percentchange', sortAsc=False, size=100)
        quotes = result.get("quotes", [])
        for q2 in quotes:
            sym   = q2.get("symbol","")
            chg   = q2.get("regularMarketChangePercent", 0)
            vol   = q2.get("regularMarketVolume", 0)
            price = q2.get("regularMarketPrice", 0)
            if sym and chg > 0 and price >= 0.5 and vol > 100_000:
                gainers.append((sym, round(chg,2), vol, price))
        if gainers:
            console.print(f"[green]✅ yfinance screener: {len(gainers)} سهم[/green]")
    except Exception as e:
        console.print(f"[dim]yfinance screener: {e}[/dim]")

    # ── المصدر 2: حساب يدوي على قائمة موسعة ────────────────────
    if len(gainers) < 30:
        console.print("[dim]⟳ حساب الارتفاعات من البيانات اليومية...[/dim]")

        # قائمة موسعة — أسهم نشطة ومتداولة فقط (بدون محذوفة)
        FULL_UNIVERSE = [
            # تكنولوجيا كبرى
            "AAPL","MSFT","NVDA","TSLA","AMZN","META","GOOGL","AMD","PLTR","MSTR",
            "SMCI","ARM","AVGO","ORCL","CRM","NFLX","UBER","COIN","HOOD","SOFI",
            "INTC","MU","QCOM","TXN","AMAT","LRCX","KLAC","TSM","ON","MRVL",
            "ADBE","ORCL","SAP","CRM","NOW","WDAY","ZS","CRWD","PANW","FTNT",
            "SNOW","DDOG","NET","MDB","CFLT","GTLB","DT","ESTC",
            # بيوتك ودواء
            "MRNA","BNTX","PFE","JNJ","ABBV","BMY","LLY","NVO","AMGN","GILD",
            "BIIB","REGN","VRTX","ILMN","DXCM","INCY","ALNY","ACAD","AXSM",
            "SUPN","HRMY","ADMA","PRAX","KRTX","IMVT","ARCT","BEAM","CRSP","EDIT",
            # Crypto Miners
            "MARA","RIOT","CLSK","HUT","CIFR","BTBT","WULF","IREN","CORZ","BITF",
            # EV
            "RIVN","LCID","XPEV","LI","NIO","GM","F",
            # مالية
            "BAC","JPM","GS","MS","C","WFC","BX","KKR","APO","ARES",
            "PYPL","SQ","AFRM","UPST","LC",
            # طاقة
            "CVX","XOM","COP","OXY","SLB","HAL","DVN","FANG","MRO","APA",
            "AR","CNX","RRC","EQT","CTRA","MTDR","SM",
            # ETFs رافعة
            "SOXL","TQQQ","ARKK","ARKG","ARKW","ARKF","SOXS","LABU","LABD",
            "SPXL","SPXS","TECL","FNGU","BULZ","UVXY",
            # إعلام وترفيه
            "DIS","WBD","PARA","CMCSA","T","VZ","SPOT","SNAP","PINS","MTCH","IAC",
            # طاقة متجددة
            "ENPH","FSLR","RUN","ARRY","CSIQ","MAXN","NOVA",
            # فضاء وتقنية مستقبلية
            "JOBY","ACHR","RKLB","ASTS","LUNR","IONQ","RGTI","QUBT","SPCE",
            # ألعاب وترفيه رقمي
            "U","RBLX","EA","TTWO","DKNG","PENN","MGM","WYNN",
            # صناعة وسيارات
            "GE","CAT","DE","HON","RTX","BA","LMT","NOC",
            # رعاية صحية
            "UNH","HCA","ISRG","EW","BSX","MDT","ABT","TMO",
            # استهلاكي
            "AMZN","SHOP","ETSY","CHWY","CVNA","ABNB","BKNG","EXPE",
        ]
        # إزالة المكرر
        FULL_UNIVERSE = list(dict.fromkeys(FULL_UNIVERSE))

        done = [0]
        total = len(FULL_UNIVERSE)

        def _get_chg(sym):
            try:
                # إخفاء رسائل yfinance الإزعاجية
                with contextlib.redirect_stderr(io.StringIO()):
                    df = yf.Ticker(sym).history(period="2d", interval="1d")
                if df is None or len(df) < 2:
                    return None
                chg   = (df["Close"].iloc[-1]/df["Close"].iloc[-2]-1)*100
                vol   = float(df["Volume"].iloc[-1])
                price = float(df["Close"].iloc[-1])
                if chg > 1.0 and price >= 0.3 and vol > 50_000:
                    return (sym, round(chg,2), vol, price)
            except:
                pass
            return None

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            console=console
        ) as prog:
            task_id = prog.add_task("جلب بيانات الأسهم...", total=total)
            with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
                futs = {ex.submit(_get_chg, sym): sym for sym in FULL_UNIVERSE}
                for fut in concurrent.futures.as_completed(futs):
                    r = fut.result()
                    prog.advance(task_id)
                    if r:
                        gainers.append(r)

    # ── ترتيب من الأعلى ارتفاعاً ───────────────────────────────
    # إزالة المكرر والترتيب
    seen = set()
    unique = []
    for g in gainers:
        if g[0] not in seen:
            seen.add(g[0])
            unique.append(g)

    unique = sorted(unique, key=lambda x: x[1], reverse=True)
    top    = [g[0] for g in unique[:limit]]

    if unique:
        console.print(
            f"\n[bold green]🔥 أعلى الأسهم ارتفاعاً اليوم — {len(unique)} سهم:[/bold green]"
        )
        console.print(f"[bold cyan]{'─'*65}[/bold cyan]")
        console.print(f"  [bold cyan]{'SYMBOL':<8}{'TODAY%':<12}{'PRICE':<12}{'VOLUME':>14}[/bold cyan]")
        console.print(f"[bold cyan]{'─'*65}[/bold cyan]")
        for sym, chg, vol, price in unique[:15]:
            bar = "█" * min(int(chg/3), 18)
            vol_str = f"{vol/1e6:.1f}M" if vol>=1e6 else f"{vol/1e3:.0f}K"
            console.print(
                f"  [bold yellow]{sym:<8}[/bold yellow]"
                f"[bold green]+{chg:<11.1f}%[/bold green]"
                f"[white]${price:<11.2f}[/white]"
                f"[dim]{vol_str:>10}[/dim]  "
                f"[cyan]{bar}[/cyan]"
            )
        console.print(f"[bold cyan]{'─'*65}[/bold cyan]\n")
    else:
        console.print("[yellow]⚠️ لم يتم جلب بيانات — تأكد من الاتصال بالإنترنت[/yellow]")
        top = SCAN_UNIVERSE[:limit]
        unique = []

    return top, unique


def scan_market():
    # ── جلب أعلى الأسهم ارتفاعاً اليوم ────────────────────────
    top_syms, gainers_data = get_top_gainers(200)

    console.print(Panel(
        f"[bold cyan]مسح السوق — أعلى {len(top_syms)} سهم ارتفاعاً اليوم[/bold cyan]\n"
        f"[dim]يحلل النماذج الفنية | الشموع | الدعم والمقاومة | الأطر الزمنية[/dim]",
        border_style="cyan"
    ))

    # ── عرض أعلى 5 ارتفاعاً قبل التحليل ───────────────────────
    if gainers_data:
        console.print("[bold yellow]🔥 أعلى الأسهم ارتفاعاً الآن:[/bold yellow]")
        for sym, chg, vol, price in gainers_data[:8]:
            bar = "█" * min(int(chg/2), 20)
            console.print(
                f"  [bold yellow]{sym:<6}[/bold yellow]  "
                f"[bold green]+{chg:.1f}%[/bold green]  "
                f"[cyan]{bar}[/cyan]  "
                f"[dim]${price:.2f} | Vol {vol/1e6:.1f}M[/dim]"
            )
        console.print()

    results = []
    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
        BarColumn(), TextColumn("{task.completed}/{task.total}"),
        console=console
    ) as prog:
        task = prog.add_task("جاري التحليل الفني...", total=len(top_syms))

        def _scan_one(sym):
            try:
                r = analyze(sym, silent=True)
                prog.advance(task)
                # أضف نسبة الارتفاع من gainers_data
                chg_today = next((g[1] for g in gainers_data if g[0]==sym), 0)
                if r:
                    r["chg_today"] = chg_today
                return r
            except:
                prog.advance(task)
                return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=SCAN_WORKERS) as ex:
            futures = {ex.submit(_scan_one, sym): sym for sym in top_syms}
            for fut in concurrent.futures.as_completed(futures):
                r = fut.result()
                if r and r.get("score", 0) >= MIN_SCAN_SCORE:
                    results.append(r)

    if not results:
        console.print("[yellow]⚠️ لم تُكتشف إشارات فنية قوية. جرب خفض MIN_SCAN_SCORE.[/yellow]")
        return

    # ترتيب: الأعلى score أولاً، ثم الأعلى ارتفاعاً
    results.sort(key=lambda x: (x["score"], x.get("chg_today", 0)), reverse=True)

    # ── عرض النتائج ─────────────────────────────────────────────
    console.print()
    console.print(f"[bold cyan]{'─'*100}[/bold cyan]")
    console.print(
        f"  [bold cyan]{'#':<4}{'السهم':<8}{'اليوم%':<10}{'القوة':<8}{'الاتجاه':<18}"
        f"{'السعر':<10}{'الوقف':<10}{'الهدف1':<10}{'الهدف2':<10}النماذج[/bold cyan]"
    )
    console.print(f"[bold cyan]{'─'*100}[/bold cyan]")

    for i, r in enumerate(results[:25], 1):
        sc       = r["score"]
        chg_t    = r.get("chg_today", r.get("chg", 0))
        bull     = "صاعد" in r["direction"]
        bear     = "هابط" in r["direction"]
        sc_tag   = "bold green" if sc>=8 else ("green" if sc>=6 else "yellow")
        dir_tag  = "green" if bull else ("red" if bear else "yellow")
        dir_disp = r["direction"]
        pats = ", ".join(r["patterns"][:2]) if r["patterns"] else "—"
        tp2_val  = r.get("tp2", r["tp1"] * 1.03)

        console.print(
            f"  [white]{i:<4}[/white]"
            f"[bold yellow]{r['sym']:<8}[/bold yellow]"
            f"[bold green]+{chg_t:<9.1f}%[/bold green]"
            f"[{sc_tag}]{sc}/10   [/{sc_tag}]"
            f"[{dir_tag}]{dir_disp:<18}[/{dir_tag}]"
            f"[white]${r['entry']:<9.2f}[/white]"
            f"[red]${r['stop']:<9.2f}[/red]"
            f"[green]${r['tp1']:<9.2f}[/green]"
            f"[bold green]${tp2_val:<9.2f}[/bold green]"
            f"[dim]{pats}[/dim]"
        )

    console.print(f"[bold cyan]{'─'*100}[/bold cyan]")
    console.print(
        f"\n[bold green]✅ {len(results)} إشارة مكتشفة[/bold green]  "
        f"[dim]مرتبة: القوة + الارتفاع اليومي | اكتب أي رمز للتحليل التفصيلي[/dim]\n"
    )

    # Telegram
    if TELEGRAM_TOKEN and results:
        top3 = results[:3]
        msg  = "📊 <b>Sultan TA — Top Gainers Scan</b>\n\n"
        for r in top3:
            msg += (f"⭐ <b>{r['sym']}</b> +{r.get('chg_today',0):.1f}% | Score {r['score']}/10\n"
                    f"   Entry: ${r['entry']:.2f} | Stop: ${r['stop']:.2f} | TP1: ${r['tp1']:.2f}\n\n")
        send_telegram(msg)

# ══════════════════════════════════════════════════════════════
#  القائمة الرئيسية
# ══════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════
#  خانة تحليل القطاع — تحليل بأسلوب محلل أول وترتيب أفضل الشركات
# ══════════════════════════════════════════════════════════════

SECTORS = {
    "semiconductors": ["NVDA","AVGO","AMD","TSM","QCOM","MU","INTC","ASML","AMAT","LRCX"],
    "ai":             ["NVDA","MSFT","GOOGL","META","AMD","PLTR","AVGO","ORCL","SMCI","ADBE"],
    "software":       ["MSFT","CRM","ORCL","ADBE","NOW","SNOW","PLTR","INTU","TEAM","DDOG"],
    "cybersecurity":  ["CRWD","PANW","ZS","FTNT","NET","S","OKTA","CYBR"],
    "banks":          ["JPM","BAC","WFC","C","GS","MS","USB","PNC"],
    "energy":         ["XOM","CVX","COP","SLB","EOG","OXY","MPC","PSX"],
    "defense":        ["LMT","RTX","NOC","GD","BA","LHX","HII"],
    "healthcare":     ["UNH","LLY","JNJ","MRK","ABBV","PFE","TMO","ABT"],
    "ev":             ["TSLA","RIVN","LCID","NIO","LI","XPEV"],
    "evtol":          ["JOBY","ACHR","EVTL","EH"],
    "space":          ["RKLB","ASTS","LUNR","RDW","SPCE"],
    "quantum":        ["IONQ","RGTI","QBTS","QUBT","ARQQ"],
    "retail":         ["AMZN","WMT","COST","TGT","HD","LOW"],
    "megacap":        ["AAPL","MSFT","GOOGL","AMZN","META","NVDA","TSLA"],
    # ── قطاعات Finviz القياسية الـ11 (أكبر الشركات الأمريكية في كل قطاع) ──
    "technology":             ["AAPL","MSFT","NVDA","AVGO","ORCL","CRM","AMD","ADBE","CSCO","ACN","QCOM","TXN","IBM","NOW","INTC"],
    "communication services": ["GOOGL","META","NFLX","DIS","TMUS","T","VZ","CMCSA","CHTR","EA","WBD","TTWO"],
    "consumer cyclical":      ["AMZN","TSLA","HD","MCD","NKE","LOW","SBUX","BKNG","TJX","ABNB","ORLY","CMG"],
    "consumer defensive":     ["WMT","COST","PG","KO","PEP","PM","MO","MDLZ","CL","TGT","KMB","GIS"],
    "energy":                 ["XOM","CVX","COP","SLB","EOG","MPC","PSX","OXY","WMB","KMI","VLO","HES"],
    "financial":              ["BRK-B","JPM","V","MA","BAC","WFC","GS","MS","C","SCHW","BLK","AXP","SPGI"],
    "industrials":            ["GE","CAT","HON","UNP","RTX","BA","LMT","DE","UPS","ETN","ADP","NOC"],
    "basic materials":        ["LIN","SHW","FCX","NEM","APD","ECL","DOW","NUE","CTVA","DD","ALB"],
    "real estate":            ["PLD","AMT","EQIX","WELL","SPG","PSA","O","CCI","DLR","VICI","EXR"],
    "utilities":              ["NEE","SO","DUK","CEG","SRE","AEP","D","EXC","PCG","XEL","ED"],
    "healthcare":             ["LLY","UNH","JNJ","MRK","ABBV","TMO","ABT","DHR","AMGN","PFE","ISRG","BMY"],
}
SECTOR_ALIASES = {
    "اشباه الموصلات":"semiconductors","أشباه الموصلات":"semiconductors","شرائح":"semiconductors","semis":"semiconductors","chips":"semiconductors",
    "ذكاء اصطناعي":"ai","الذكاء الاصطناعي":"ai","ai":"ai",
    "برمجيات":"software","software":"software",
    "امن سيبراني":"cybersecurity","أمن سيبراني":"cybersecurity","cyber":"cybersecurity","security":"cybersecurity",
    "بنوك":"banks","البنوك":"banks","banks":"banks","banking":"banks",
    "طاقة":"energy","الطاقة":"energy","نفط":"energy","oil":"energy","energy":"energy",
    "دفاع":"defense","الدفاع":"defense","defense":"defense","aerospace":"defense",
    "رعاية صحية":"healthcare","صحة":"healthcare","health":"healthcare","healthcare":"healthcare","pharma":"healthcare",
    "سيارات كهربائية":"ev","كهربائية":"ev","ev":"ev",
    "طيران كهربائي":"evtol","evtol":"evtol",
    "فضاء":"space","الفضاء":"space","space":"space",
    "كمي":"quantum","الحوسبة الكمية":"quantum","كوانتم":"quantum","quantum":"quantum",
    "تجزئة":"retail","retail":"retail",
    "كبرى":"megacap","megacap":"megacap","mega":"megacap",
    # ── قطاعات Finviz ──
    "تقنية":"technology","التقنية":"technology","تكنولوجيا":"technology","technology":"technology","tech":"technology",
    "خدمات الاتصالات":"communication services","اتصالات":"communication services","communication":"communication services","communication services":"communication services","telecom":"communication services",
    "سلع كمالية":"consumer cyclical","استهلاكي دوري":"consumer cyclical","consumer cyclical":"consumer cyclical","cyclical":"consumer cyclical",
    "سلع أساسية":"consumer defensive","استهلاكي دفاعي":"consumer defensive","consumer defensive":"consumer defensive","defensive":"consumer defensive",
    "مالية":"financial","المالية":"financial","financial":"financial","financials":"financial","finance":"financial",
    "صناعات":"industrials","صناعي":"industrials","industrials":"industrials","industrial":"industrials",
    "مواد أساسية":"basic materials","مواد":"basic materials","basic materials":"basic materials","materials":"basic materials",
    "عقارات":"real estate","العقارات":"real estate","real estate":"real estate","reits":"real estate",
    "مرافق":"utilities","المرافق":"utilities","utilities":"utilities","utility":"utilities",
}

def analyst_score(info, tech_score):
    """درجة محلل مركّبة 0–100: جودة + نمو + صحة مالية + تقييم + زخم فني."""
    roe=info.get("roe"); opm=info.get("op_m"); gm=info.get("gross_m")
    rg=info.get("rev_growth"); eg=info.get("earn_growth")
    de=info.get("debt_equity"); fcf=info.get("free_cf"); cr=info.get("current_ratio")
    pef=info.get("pe_fwd") or info.get("pe_trail"); peg=info.get("peg")
    short=info.get("short_pct"); rec=info.get("rec"); tm=info.get("target_mean"); px=info.get("price")

    qs=[]
    if roe is not None: qs.append(min(max(roe/0.30,0),1))
    if opm is not None: qs.append(min(max(opm/0.30,0),1))
    if gm  is not None: qs.append(min(max(gm/0.60,0),1))
    q = sum(qs)/len(qs) if qs else 0.4

    gs=[]
    if rg is not None: gs.append(min(max(rg/0.40,0),1))
    if eg is not None: gs.append(min(max(eg/0.40,-0.5),1))
    g = max(0, sum(gs)/len(gs)) if gs else 0.4

    hs=[]
    if de  is not None: hs.append(min(max(1-de/200.0,0),1))
    if fcf is not None: hs.append(1.0 if fcf>0 else 0.0)
    if cr  is not None: hs.append(min(max(cr/2.0,0),1))
    h = sum(hs)/len(hs) if hs else 0.5

    if pef and pef>0:   val = min(max(1-(pef-15)/60.0,0),1)
    elif pef is None:   val = 0.45
    else:               val = 0.2
    if peg and 0<peg<2: val = (val + min(max(1-(peg-1),0),1))/2

    mom = min(max(tech_score/10.0,0),1)
    score = q*25 + g*25 + h*20 + val*15 + mom*15
    if rec in ("strong_buy","buy"): score += 3
    if tm and px and px>0 and (tm-px)/px > 0.15: score += 2
    if short and short > 0.15: score -= 3
    return round(min(max(score,0),100)), {"q":q,"g":g,"h":h,"val":val,"mom":mom}

def _company_notes(info):
    """يستخرج نقاط القوة والمخاطر من البيانات (بأسلوب محلل)."""
    s=[]; rk=[]
    roe=info.get("roe"); opm=info.get("op_m"); rg=info.get("rev_growth"); eg=info.get("earn_growth")
    de=info.get("debt_equity"); fcf=info.get("free_cf"); pef=info.get("pe_fwd") or info.get("pe_trail")
    short=info.get("short_pct"); rec=info.get("rec"); tm=info.get("target_mean"); px=info.get("price"); mc=info.get("mktcap")
    if rg and rg>0.20:  s.append(T(f"نمو إيرادات قوي {rg*100:.0f}%", f"strong revenue growth {rg*100:.0f}%"))
    if opm and opm>0.20:s.append(T(f"هوامش تشغيل عالية {opm*100:.0f}%", f"high operating margin {opm*100:.0f}%"))
    if roe and roe>0.20:s.append(T(f"عائد ملكية ممتاز {roe*100:.0f}%", f"excellent ROE {roe*100:.0f}%"))
    if de is not None and de<40: s.append(T("ميزانية قوية / ديون منخفضة","strong balance sheet / low debt"))
    if fcf and fcf>0:   s.append(T("تدفق نقدي حر موجب","positive free cash flow"))
    if rec in ("strong_buy","buy"): s.append(T("إجماع المحللين: شراء","analyst consensus: buy"))
    if tm and px and px>0 and (tm-px)/px>0.15: s.append(T(f"مستهدف أعلى بـ {(tm-px)/px*100:.0f}%", f"target {(tm-px)/px*100:.0f}% above price"))
    if eg is not None and eg<0: rk.append(T("أرباح متراجعة","declining earnings"))
    if fcf is not None and fcf<0: rk.append(T("تدفق نقدي سالب — يحرق نقداً","negative cash flow — burning cash"))
    if pef and pef>50:  rk.append(T(f"تقييم مرتفع P/E {pef:.0f}", f"rich valuation P/E {pef:.0f}"))
    if de is not None and de>150: rk.append(T("ديون مرتفعة","high debt"))
    if rg is not None and rg<0: rk.append(T("إيرادات منكمشة","shrinking revenue"))
    if short and short>0.15: rk.append(T(f"بيع مكشوف مرتفع {short*100:.0f}%", f"high short interest {short*100:.0f}%"))
    if mc and mc<2e9:   rk.append(T("شركة صغيرة — تقلب ومخاطرة أعلى","small-cap — higher volatility/risk"))
    return s, rk

def sector_analysis(sector_key):
    key = SECTOR_ALIASES.get(sector_key.strip().lower(), sector_key.strip().lower())
    if key not in SECTORS:
        avail = " | ".join(sorted(set(SECTORS.keys())))
        console.print(f"[yellow]{T('قطاع غير معروف','Unknown sector')}. {T('القطاعات المتاحة','Available sectors')}:[/yellow]\n[dim]{avail}[/dim]")
        return
    tickers = SECTORS[key]
    console.print(Panel(
        f"[bold cyan]🏛  {T('تحليل قطاع','Sector Analysis')}: {key.upper()}[/bold cyan]\n"
        f"[dim]{T('جودة + نمو + صحة مالية + تقييم + زخم فني — بأسلوب محلل أول','Quality + growth + health + valuation + momentum — analyst style')}[/dim]",
        border_style="cyan"))

    rows=[]; missing=[]
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                  BarColumn(), TextColumn("{task.completed}/{task.total}"), console=console) as prog:
        task = prog.add_task(T("جاري تحليل القطاع...","Analyzing sector..."), total=len(tickers))
        def _one(sym):
            try:
                a = analyze(sym, silent=True); info = get_company_info(sym)
                prog.advance(task)
                if not info or info.get("error"): return None
                px = info.get("price") or a.get("entry") or 0
                if px<=0: return None
                tech = a.get("score",0)
                sc, _ = analyst_score(info, tech)
                return {"sym":sym,"info":info,"tech":tech,"score":sc}
            except Exception:
                prog.advance(task); return None
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
            futs={ex.submit(_one,s):s for s in tickers}
            for f in concurrent.futures.as_completed(futs):
                r=f.result()
                if r: rows.append(r)
                else: missing.append(futs[f])

    if not rows:
        console.print(f"[red]{T('تعذّر جلب بيانات القطاع','Could not fetch sector data')}[/red]"); return
    rows.sort(key=lambda x:x["score"], reverse=True)
    if missing:
        console.print(f"[yellow]⚠️  {T('بلا بيانات كافية','no data')}: {', '.join(missing)}[/yellow]\n")

    def _p(x,d=0): return f"{x*100:.{d}f}%" if x is not None else "—"
    tbl = Table(show_header=True, header_style="bold cyan", box=box.SQUARE, pad_edge=False, show_lines=False)
    tbl.add_column("#", justify="right")
    tbl.add_column(T("الرمز","Sym"), style="bold yellow")
    tbl.add_column(T("الشركة","Company"), style="dim", max_width=22)
    tbl.add_column(T("سوقية","Cap"), justify="right", no_wrap=True)
    tbl.add_column("P/E", justify="center", no_wrap=True)
    tbl.add_column(T("نمو","Growth"), justify="center", no_wrap=True)
    tbl.add_column("ROE", justify="center", no_wrap=True)
    tbl.add_column(T("هامش","Margin"), justify="center", no_wrap=True)
    tbl.add_column(T("فني","Tech"), justify="center", no_wrap=True)
    tbl.add_column(T("درجة المحلل","Analyst"), justify="center", no_wrap=True)
    for i,r in enumerate(rows,1):
        info=r["info"]; pef=info.get("pe_fwd") or info.get("pe_trail")
        sc=r["score"]; scc="bold green" if sc>=70 else ("yellow" if sc>=55 else "red")
        tbl.add_row(str(i), r["sym"], (info.get("name","") or "")[:22],
                    _fmt_big(info.get("mktcap")),
                    f"{pef:.0f}" if pef and pef>0 else "—",
                    _p(info.get("rev_growth")), _p(info.get("roe")), _p(info.get("op_m")),
                    f"{r['tech']}/10",
                    f"[{scc}]{sc}/100[/{scc}]")
    console.print(tbl)

    # verdict — أفضل 3 بأسلوب محلل
    console.print(f"\n[bold cyan]{'═'*78}[/bold cyan]")
    console.print(f"[bold green]🥇 {T('خلاصة المحلل — أفضل الأسماء','Analyst takeaway — top names')}:[/bold green]\n")
    for rank,r in enumerate(rows[:3],1):
        info=r["info"]; s,rk=_company_notes(info)
        medal={1:"🥇",2:"🥈",3:"🥉"}[rank]
        tm=info.get("target_mean"); px=info.get("price")
        up = f"  [dim]{T('مستهدف المحللين','analyst target')}: ${tm:.2f} ({(tm-px)/px*100:+.0f}%)[/dim]" if (tm and px and px>0) else ""
        console.print(f"{medal} [bold white]{r['sym']}[/bold white] [dim]{(info.get('name','') or '')[:34]}[/dim]  "
                      f"[bold]{r['score']}/100[/bold]{up}")
        if s:  console.print(f"   [green]✅ {T('القوة','Strengths')}:[/green] {T('، ','; ').join(s[:4])}")
        if rk: console.print(f"   [red]⚠️ {T('المخاطر','Risks')}:[/red] {T('، ','; ').join(rk[:4])}")
        console.print()
    console.print(f"[dim]{T('تنبيه: تحليل كمي للبيانات المتاحة، ليس توصية شخصية. ابحث بنفسك قبل أي قرار.','Note: quantitative screen of available data, not personal advice. Do your own research.')}[/dim]")
    console.print(f"[bold cyan]{'═'*78}[/bold cyan]\n")


def main():
    console.print(Panel(
        "[bold cyan]Sultan Technical Analyst v2.0[/bold cyan]\n"
        "[dim]شموع يابانية | نماذج شارت | داو | Wyckoff | Ichimoku | SMC | Fibonacci[/dim]\n"
        "[dim]مضارب يومي + مستثمر | معلومات الشركة | مقارنة المحافظ[/dim]\n\n"
        f"[bold yellow]{T('الأوامر:','Commands:')}[/bold yellow]\n"
        f"  [cyan]AAPL[/cyan]                  ← {T('تحليل سهم واحد','analyze one stock')}\n"
        f"  [cyan]AAPL +[/cyan]                ← {T('تحليل تفصيلي كامل','full detailed analysis')}\n"
        f"  [cyan]info AAPL[/cyan]             ← {T('معلومات الشركة المالية','full company financials')}\n"
        f"  [cyan]AAPL MSFT NVDA[/cyan]        ← {T('مقارنة محفظة (2-10 أسهم)','compare portfolio (2-10)')}\n"
        f"  [cyan]scan[/cyan]                  ← {T('مسح أعلى 200 سهم','scan top 200 stocks')}\n"
        f"  [cyan]sector ai[/cyan]             ← {T('تحليل قطاع وترتيب أفضل شركاته','analyze a sector & rank top names')}\n"
        f"  [cyan]lang[/cyan]                  ← {T('تبديل اللغة عربي/إنجليزي','toggle Arabic/English')}\n"
        f"  [cyan]{T('خروج','exit')}[/cyan]                  ← {T('إنهاء','quit')}",
        box=box.DOUBLE, border_style="cyan"
    ))

    last_result = {}

    while True:
        console.print("\n[bold yellow]>[/bold yellow] ", end="")
        try: inp = input().strip()
        except (EOFError, KeyboardInterrupt): break
        if not inp: continue
        if inp.lower() in ("خروج","exit","quit","q"): break

        # ── تبديل اللغة ──────────────────────────────────────
        low = inp.lower()
        if low in ("lang","لغة","language"):
            set_lang("ar" if LANG == "en" else "en")
            console.print(f"[green]✅ {'Language: English' if LANG=='en' else 'اللغة: العربية'}[/green]")
            continue
        if low in ("en","english","انجليزي","إنجليزي"):
            set_lang("en"); console.print("[green]✅ Language: English[/green]"); continue
        if low in ("ar","arabic","عربي","عربية"):
            set_lang("ar"); console.print("[green]✅ اللغة: العربية[/green]"); continue

        if inp.lower() in ("scan","مسح","s","sc"):
            scan_market(); continue

        # ── تحليل قطاع ───────────────────────────────────────
        low2 = inp.lower()
        if low2.startswith("sector ") or low2.startswith("قطاع ") or low2 in ("sector","قطاع","sectors","القطاعات"):
            arg = inp.split(None, 1)[1].strip() if " " in inp else ""
            if not arg:
                avail = " | ".join(sorted(set(SECTORS.keys())))
                console.print(f"[yellow]{T('اكتب: sector <اسم القطاع>','Type: sector <name>')}[/yellow]\n[dim]{avail}[/dim]")
            else:
                sector_analysis(arg)
            continue

        if inp == "+":
            if last_result: show_details(last_result)
            else: console.print("[yellow]لم يتم تحليل أي سهم بعد[/yellow]")
            continue

        if inp.lower().startswith("info "):
            sym = inp[5:].strip().upper()
            if sym: show_company(sym)
            continue

        tokens = inp.replace(",", " ").split()
        detail = "+" in tokens
        syms = [t.upper() for t in tokens
                if t.strip() and t != "+"
                and t.lower() not in ("scan","مسح","s","sc")]

        if not syms: continue

        if len(syms) > 1:
            compare_portfolio(syms)
        else:
            r = analyze(syms[0])
            if r and r.get("entry", 0) > 0:
                last_result = r
                if detail: show_details(r)

def backtest_strategy(df, commission=0.0005, slippage=0.0005, risk_per_trade=0.01,
                      rr=2.0, atr_mult=1.5, max_hold=20, oos_frac=0.30,
                      rsi_lo=40, rsi_hi=70):
    """
    اختبار تاريخي صارم (Walk-forward بعيّنة خارجية) لاستراتيجية اتجاه/زخم.
    - بلا نظر مستقبلي: الإشارة عند إغلاق الشمعة i، والتنفيذ عند افتتاح i+1.
    - يخصم العمولة والانزلاق، ويستخدم تحجيم مخاطرة ثابت (risk_per_trade).
    - يقسم النتائج لعيّنة داخلية (تطوير) وخارجية (تحقّق) منفصلتين.
    يُرجع مقاييس مؤسسية: Sharpe/Sortino/Calmar، أقصى تراجع، عامل الربح، التوقّع (R)، منحنى رأس المال.
    """
    o = df["Open"].values.astype(float); h = df["High"].values.astype(float)
    l = df["Low"].values.astype(float);  c = df["Close"].values.astype(float)
    n = len(c)
    if n < 80:
        return {"ok": False, "error": T("بيانات غير كافية (تحتاج ≥80 شمعة)", "Insufficient data (need ≥80 bars)")}

    # adaptive trend filter for young / recently-listed stocks
    long_p = 200 if n >= 300 else (100 if n >= 160 else 50)
    short_hist = long_p < 200

    def _ema(x, p):
        a = 2 / (p + 1); e = np.empty_like(x, dtype=float); e[0] = x[0]
        for k in range(1, len(x)): e[k] = a * x[k] + (1 - a) * e[k - 1]
        return e
    e9, e21, e_long = _ema(c, 9), _ema(c, 21), _ema(c, long_p)
    d = np.diff(c, prepend=c[0]); up = np.clip(d, 0, None); dn = np.clip(-d, 0, None)
    rsi = 100 - 100 / (1 + _ema(up, 14) / (_ema(dn, 14) + 1e-9))
    macd = _ema(c, 12) - _ema(c, 26); hist = macd - _ema(macd, 9)
    prev_c = np.roll(c, 1); prev_c[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - prev_c), np.abs(l - prev_c)))
    atr = _ema(tr, 14)

    split = int(n * (1 - oos_frac))
    cur_eq = 1.0; eq = []; trades = []; pos = None
    warm = min(long_p, max(40, n // 3))
    for i in range(warm, n):
        if pos is None:
            sig = (c[i] > e_long[i] and e9[i] > e21[i] and rsi_lo <= rsi[i] <= rsi_hi and hist[i] > 0)
            if sig and i + 1 < n:
                fill = o[i + 1] * (1 + slippage)
                stop = fill - atr_mult * atr[i]
                risk = fill - stop
                if risk > 0:
                    pos = {"e_i": i + 1, "fill": fill, "stop": stop,
                           "tgt": fill + rr * risk, "risk": risk, "oos": (i + 1) >= split}
        else:
            exit_px = None; reason = ""
            if l[i] <= pos["stop"]:   exit_px = pos["stop"] * (1 - slippage); reason = "stop"
            elif h[i] >= pos["tgt"]:  exit_px = pos["tgt"] * (1 - slippage); reason = "target"
            elif i - pos["e_i"] >= max_hold: exit_px = c[i] * (1 - slippage); reason = "time"
            if exit_px is not None:
                R = (exit_px - pos["fill"]) / pos["risk"]
                R -= (commission * 2) * (pos["fill"] / pos["risk"])     # العمولة بوحدات R
                cur_eq *= (1 + R * risk_per_trade)
                trades.append({"R": R, "reason": reason, "oos": pos["oos"], "exit_i": i})
                pos = None
        eq.append(cur_eq)

    if not trades:
        return {"ok": False, "error": T("لم تُولّد الاستراتيجية أي صفقة على هذا التاريخ", "No trades generated on this history")}

    eq = np.array(eq)
    rets = np.diff(eq) / eq[:-1] if len(eq) > 1 else np.array([0.0])
    ann = 252.0
    sharpe = float(rets.mean() / (rets.std() + 1e-9) * np.sqrt(ann)) if rets.std() > 0 else 0.0
    downside = rets[rets < 0]
    sortino = float(rets.mean() / (downside.std() + 1e-9) * np.sqrt(ann)) if len(downside) > 0 else 0.0
    peak = np.maximum.accumulate(eq); dd = (eq - peak) / peak
    max_dd = float(dd.min() * 100)
    years = max(len(eq) / ann, 1e-9)
    cagr = float((eq[-1]) ** (1 / years) - 1) * 100
    calmar = float(cagr / abs(max_dd)) if max_dd != 0 else 0.0

    def _stats(ts):
        if not ts: return None
        Rs = np.array([t["R"] for t in ts])
        wins = Rs[Rs > 0]; losses = Rs[Rs < 0]
        gp = wins.sum(); gl = abs(losses.sum())
        return {"trades": len(ts), "winrate": round(len(wins) / len(ts) * 100, 1),
                "avg_R": round(float(Rs.mean()), 2), "expectancy": round(float(Rs.mean()), 2),
                "profit_factor": round(float(gp / gl), 2) if gl > 0 else float("inf"),
                "best_R": round(float(Rs.max()), 2), "worst_R": round(float(Rs.min()), 2)}

    alls = _stats(trades); ins = _stats([t for t in trades if not t["oos"]]); oos = _stats([t for t in trades if t["oos"]])
    # منحنى رأس المال (مخفّض للعرض)
    step = max(1, len(eq) // 300)
    curve = [round(float(x), 4) for x in eq[::step]]
    return {"ok": True, "total_return": round(float((eq[-1] - 1) * 100), 1), "cagr": round(cagr, 1),
            "sharpe": round(sharpe, 2), "sortino": round(sortino, 2), "calmar": round(calmar, 2),
            "max_dd": round(max_dd, 1), "all": alls, "in_sample": ins, "out_sample": oos,
            "equity_curve": curve, "n_bars": int(n), "short_hist": bool(short_hist), "long_ma": int(long_p),
            "params": {"commission": commission, "slippage": slippage, "rr": rr,
                       "atr_mult": atr_mult, "max_hold": max_hold, "risk_per_trade": risk_per_trade}}


def backtest_portfolio(dfs, spy_df=None, commission=0.0005, slippage=0.0005, risk_per_trade=0.01,
                       rr=2.0, atr_mult=1.5, max_hold=20, oos_frac=0.30, rsi_lo=40, rsi_hi=70):
    """
    اختبار تاريخي على مستوى المحفظة (سلّة أسهم) بنفس منهج backtest_strategy:
    - يحاكي كل سهم باستراتيجية الاتجاه/الزخم (بلا نظر مستقبلي، عمولة، انزلاق، فلتر اتجاه تكيّفي).
    - يدمج صفقات كل الأسهم في منحنى رأس مال واحد للمحفظة (تحجيم مخاطرة ثابت لكل صفقة).
    - يُخرج Sharpe وأقصى تراجع للمحفظة، يقارنها بـ S&P 500، ويحسب مصفوفة الارتباط (لكشف التركّز).
    """
    syms = [s for s, d in dfs.items() if d is not None and len(d) >= 80]
    if len(syms) < 2:
        return {"ok": False, "error": T("تحتاج سهمين على الأقل بتاريخ كافٍ (≥80 شمعة)", "Need ≥2 names with enough history (≥80 bars)")}

    def _ema(x, p):
        a = 2 / (p + 1); e = np.empty_like(x, dtype=float); e[0] = x[0]
        for k in range(1, len(x)): e[k] = a * x[k] + (1 - a) * e[k - 1]
        return e

    def _sim(df):
        o = df["Open"].values.astype(float); h = df["High"].values.astype(float)
        l = df["Low"].values.astype(float);  c = df["Close"].values.astype(float)
        n = len(c); idx = df.index
        long_p = 200 if n >= 300 else (100 if n >= 160 else 50)
        e9, e21, el = _ema(c, 9), _ema(c, 21), _ema(c, long_p)
        d = np.diff(c, prepend=c[0]); up = np.clip(d, 0, None); dn = np.clip(-d, 0, None)
        rsi = 100 - 100 / (1 + _ema(up, 14) / (_ema(dn, 14) + 1e-9))
        macd = _ema(c, 12) - _ema(c, 26); hist = macd - _ema(macd, 9)
        pc = np.roll(c, 1); pc[0] = c[0]
        tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc))); atr = _ema(tr, 14)
        warm = min(long_p, max(40, n // 3)); pos = None; trades = []
        for i in range(warm, n):
            if pos is None:
                if c[i] > el[i] and e9[i] > e21[i] and rsi_lo <= rsi[i] <= rsi_hi and hist[i] > 0 and i + 1 < n:
                    fill = o[i + 1] * (1 + slippage); stop = fill - atr_mult * atr[i]; risk = fill - stop
                    if risk > 0: pos = {"e_i": i + 1, "fill": fill, "stop": stop, "tgt": fill + rr * risk, "risk": risk}
            else:
                ex = None
                if l[i] <= pos["stop"]:   ex = pos["stop"] * (1 - slippage)
                elif h[i] >= pos["tgt"]:  ex = pos["tgt"] * (1 - slippage)
                elif i - pos["e_i"] >= max_hold: ex = c[i] * (1 - slippage)
                if ex is not None:
                    R = (ex - pos["fill"]) / pos["risk"] - (commission * 2) * (pos["fill"] / pos["risk"])
                    trades.append({"exit_date": idx[i], "R": R}); pos = None
        return trades

    all_trades = []
    for s in syms: all_trades += _sim(dfs[s])
    if not all_trades:
        return {"ok": False, "error": T("لم تُولّد أي صفقة على هذا التاريخ", "No trades generated on this history")}

    full_idx = sorted(set().union(*[set(dfs[s].index) for s in syms]))
    split_date = full_idx[int(len(full_idx) * (1 - oos_frac))]
    by_date = {}
    for t in all_trades: by_date.setdefault(t["exit_date"], []).append(t["R"])
    eq = 1.0; curve = []
    for dte in full_idx:
        for R in by_date.get(dte, []): eq *= (1 + R * risk_per_trade)
        curve.append(eq)
    curve = np.array(curve)
    rets = np.diff(curve) / curve[:-1] if len(curve) > 1 else np.array([0.0])
    ann = 252.0
    sharpe = float(rets.mean() / (rets.std() + 1e-9) * np.sqrt(ann)) if rets.std() > 0 else 0.0
    peak = np.maximum.accumulate(curve); max_dd = float(((curve - peak) / peak).min() * 100)
    years = max(len(curve) / ann, 1e-9); cagr = float(curve[-1] ** (1 / years) - 1) * 100

    Rs = np.array([t["R"] for t in all_trades])
    Ris = np.array([t["R"] for t in all_trades if t["exit_date"] < split_date])
    Roos = np.array([t["R"] for t in all_trades if t["exit_date"] >= split_date])
    def _st(R):
        if len(R) == 0: return None
        w = R[R > 0]; lo = R[R < 0]; gl = abs(lo.sum())
        return {"trades": len(R), "winrate": round(float((R > 0).mean() * 100), 1),
                "expectancy": round(float(R.mean()), 2),
                "profit_factor": round(float(w.sum() / gl), 2) if gl > 0 else float("inf")}

    closes = pd.DataFrame({s: dfs[s]["Close"] for s in syms}).reindex(full_idx).ffill()
    corr = closes.pct_change().corr().round(2)
    tri = corr.values[np.triu_indices(len(syms), 1)]
    avg_corr = round(float(np.nanmean(tri)), 2) if len(tri) else 0.0

    bench = None
    if spy_df is not None and len(spy_df) > 2:
        sc = pd.Series(spy_df["Close"]).reindex(full_idx).ffill().values.astype(float)
        sc = sc[~np.isnan(sc)]
        if len(sc) > 2:
            sret = np.diff(sc) / sc[:-1]
            bsh = float(sret.mean() / (sret.std() + 1e-9) * np.sqrt(ann)) if sret.std() > 0 else 0.0
            spk = np.maximum.accumulate(sc)
            bench = {"total": round(float((sc[-1] / sc[0] - 1) * 100), 1), "sharpe": round(bsh, 2),
                     "max_dd": round(float(((sc - spk) / spk).min() * 100), 1)}

    step = max(1, len(curve) // 300)
    return {"ok": True, "symbols": syms, "n_names": len(syms),
            "total_return": round(float((curve[-1] - 1) * 100), 1), "cagr": round(cagr, 1),
            "sharpe": round(sharpe, 2), "max_dd": round(max_dd, 1),
            "all": _st(Rs), "in_sample": _st(Ris), "out_sample": _st(Roos),
            "equity_curve": [round(float(x), 4) for x in curve[::step]],
            "corr": corr.values.tolist(), "corr_labels": list(corr.columns), "avg_corr": avg_corr,
            "benchmark": bench}


def forward_fundamentals(sym):
    """
    يجلب المعطيات المستقبلية الموثّقة لبناء توقّع تقييم (لا تنبؤ سعري):
    السعر، الأرباح/الإيراد الحالي، نمو المحلّلين (مع مصدره)، السعر المستهدف للإجماع، ومضاعفات التقييم.
    المصادر مرتّبة بالأفضلية: تقدير المحلّلين ٥ سنوات ← نمو الأرباح ← نمو الإيراد ← CAGR تاريخي ← افتراضي.
    """
    out = {"ok": False}
    try:
        tk = yf.Ticker(sym)
        info = {}
        try: info = tk.info or {}
        except Exception: info = {}
        price = info.get("currentPrice") or info.get("regularMarketPrice") or info.get("previousClose")
        eps   = info.get("trailingEps"); feps = info.get("forwardEps")
        rev   = info.get("totalRevenue"); shares = info.get("sharesOutstanding")
        pe_f  = info.get("forwardPE");  pe_t = info.get("trailingPE")
        ps    = info.get("priceToSalesTrailing12Months")
        target = info.get("targetMeanPrice"); n_an = info.get("numberOfAnalystOpinions")
        eg = info.get("earningsGrowth"); rg = info.get("revenueGrowth")
        # تقدير النمو طويل المدى (٥ سنوات) من المحلّلين
        ltg = None
        try:
            ge = tk.growth_estimates
            if ge is not None and len(ge):
                for key in ("+5y", "+5Y", "0y", "longTermAvg"):
                    if key in list(ge.index):
                        ltg = float(ge.loc[key].iloc[0]); break
        except Exception: pass
        # CAGR تاريخي للإيراد (مصدر احتياطي موثّق من القوائم)
        hist_cagr = None
        try:
            fin = tk.income_stmt
            if fin is not None and "Total Revenue" in list(fin.index):
                revs = [float(x) for x in fin.loc["Total Revenue"].values if x == x]
                if len(revs) >= 2 and revs[-1] > 0:
                    hist_cagr = (revs[0] / revs[-1]) ** (1 / (len(revs) - 1)) - 1
        except Exception: pass
        # اختيار النمو الأساسي + مصدره
        if isinstance(ltg, (int, float)) and ltg == ltg:
            base_g, src = ltg, T("إجماع المحلّلين (٥ سنوات)", "analyst 5y consensus")
        elif isinstance(eg, (int, float)) and eg == eg:
            base_g, src = eg, T("نمو الأرباح المتوقّع (محلّلون)", "analyst earnings growth")
        elif isinstance(rg, (int, float)) and rg == rg:
            base_g, src = rg, T("نمو الإيراد المتوقّع (محلّلون)", "analyst revenue growth")
        elif isinstance(hist_cagr, (int, float)):
            base_g, src = hist_cagr, T("CAGR تاريخي للإيراد", "historical revenue CAGR")
        else:
            base_g, src = 0.08, T("افتراضي ٨٪", "default 8%")
        base_g = max(-0.20, min(0.50, float(base_g)))
        # مضاعف الخروج
        mult = next((m for m in (pe_f, pe_t) if isinstance(m, (int, float)) and 0 < m < 80), None)
        out.update({"ok": True, "price": price, "eps": eps, "forward_eps": feps, "revenue": rev,
                    "shares": shares, "pe_fwd": pe_f, "pe_trail": pe_t, "ps": ps,
                    "target": target, "n_analysts": n_an, "base_growth": base_g, "growth_src": src,
                    "hist_cagr": hist_cagr, "exit_multiple": mult})
    except Exception as e:
        out["error"] = str(e)
    return out


if __name__ == "__main__":
    main()
